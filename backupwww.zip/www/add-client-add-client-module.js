(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-client-add-client-module"],{

/***/ "4HmS":
/*!*******************************************************!*\
  !*** ./src/app/clients/add-client/add-client.page.ts ***!
  \*******************************************************/
/*! exports provided: AddClientPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddClientPage", function() { return AddClientPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_add_client_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./add-client.page.html */ "9gw7");
/* harmony import */ var _add_client_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./add-client.page.scss */ "oxu2");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var src_app_services_client_type_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/client-type.service */ "uYsA");
/* harmony import */ var _services_division_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../services/division.service */ "KWQH");
/* harmony import */ var _services_location_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../services/location.service */ "yHma");
/* harmony import */ var src_app_services_potentialnature_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/potentialnature.service */ "1VZb");
/* harmony import */ var _client_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../client.service */ "+RYs");
/* harmony import */ var src_app_utilities_validators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/utilities/validators */ "ZdSY");














let AddClientPage = class AddClientPage {
    constructor(clientService, route, loadingCtrl, divisionService, clientTypeService, potentialNatureService, locationService, toastController) {
        this.clientService = clientService;
        this.route = route;
        this.loadingCtrl = loadingCtrl;
        this.divisionService = divisionService;
        this.clientTypeService = clientTypeService;
        this.potentialNatureService = potentialNatureService;
        this.locationService = locationService;
        this.toastController = toastController;
        this.isLoading = false;
        this.isItemAvailable = false;
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
                divisionId: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: "blur",
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                name: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                typeId: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                contactPerson: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                contactNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                    validators: [src_app_utilities_validators__WEBPACK_IMPORTED_MODULE_13__["NoNegativeNumbers"]],
                }),
                email: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                }),
                potentialNatureId: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                accountOwner: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                gstNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(15)],
                }),
                employeeStrength: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                }),
                clientGroup: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                }),
                cmbClientGroup: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                }),
                ddCountry: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                }),
                ddRegion: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                }),
                ddSubRegion: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                }),
                ddState: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                }),
                ddCity: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                }),
            });
            this.divisionSub = this.divisionService.divisions.subscribe((divisions) => {
                this.divisionList = divisions;
            });
            this.clientTypeSub = this.clientTypeService.clientTypes.subscribe((clientTypes) => {
                this.clientTypeList = clientTypes;
            });
            this.potentialNatureSub = this.potentialNatureService.potentialnatures.subscribe((potentialNatures) => {
                this.potentialNatureList = potentialNatures;
            });
            this.locationSub = this.locationService.locations.subscribe((locations) => {
                this.locationList = locations;
                this.countries = locations.map(item => item.country).filter((value, index, self) => self.indexOf(value) === index);
            });
            this.clients = yield this.clientService.getClientList();
            this.clientGroup = this.clients
                .map((item) => item.group)
                .filter((value, index, self) => {
                if (value != null)
                    return self.indexOf(value) === index;
            });
        });
    }
    onAddClient() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!this.form.valid) {
                return;
            }
            var exiclientId = yield this.clientService.getClientIdByGSTNumber(this.form.value.gstNumber);
            if (exiclientId.length > 0) {
                yield this.toastController.create({
                    message: 'Client GST already exist.',
                    duration: 2000,
                    color: 'danger',
                }).then((tost) => {
                    tost.present();
                });
                return;
            }
            this.loadingCtrl.create({ keyboardClose: true }).then((loadingEl) => {
                loadingEl.present();
                let nlocId = '';
                let nlocation = this.locationList.filter((item) => item.country ==
                    (this.form.value.ddCountry == null
                        ? ''
                        : this.form.value.ddCountry) &&
                    item.region ==
                        (this.form.value.ddRegion == null
                            ? ''
                            : this.form.value.ddRegion) &&
                    item.subregion ==
                        (this.form.value.ddSubRegion == null
                            ? ''
                            : this.form.value.ddSubRegion) &&
                    item.state ==
                        (this.form.value.ddState == null ? '' : this.form.value.ddState) &&
                    item.city ==
                        (this.form.value.ddCity == null ? '' : this.form.value.ddCity));
                if (nlocation.length > 0) {
                    nlocId = nlocation[0].id;
                }
                let ndivisions = [];
                if (this.form.value.divisionId.length > 0) {
                    this.form.value.divisionId.forEach((element) => {
                        ndivisions.push(this.divisionList.filter((div) => div.id == element)[0].name);
                    });
                }
                let nclientTypes = [];
                if (this.form.value.typeId.length > 0) {
                    this.form.value.typeId.forEach((element) => {
                        nclientTypes.push(this.clientTypeList.filter((div) => div.id == element)[0].name);
                    });
                }
                this.clientService
                    .addClient(this.form.value.name, this.form.value.contactPerson, this.form.value.contactNumber, this.form.value.email, this.potentialNatureList.filter((item) => item.id == this.form.value.potentialNatureId)[0].name, this.form.value.accountOwner, (this.form.value.cmbClientGroup == null ? this.form.value.clientGroup : this.form.value.cmbClientGroup), this.form.value.gstNumber, this.form.value.employeeStrength, this.form.value.potentialNatureId, this.form.value.ddCountry == null ? '' : this.form.value.ddCountry, this.form.value.ddRegion == null ? '' : this.form.value.ddRegion, this.form.value.ddSubRegion == null
                    ? ''
                    : this.form.value.ddSubRegion, this.form.value.ddState == null ? '' : this.form.value.ddState, this.form.value.ddCity == null ? '' : this.form.value.ddCity, nlocId, new Date(), this.form.value.divisionId, ndivisions, this.form.value.typeId, nclientTypes)
                    .subscribe(() => {
                    this.isLoading = false;
                    loadingEl.dismiss();
                    this.form.reset();
                    this.route.navigate(['/clients']);
                });
            });
        });
    }
    onChangeCountry(event) {
        let country = event.target.value;
        this.form.controls['ddRegion'].reset();
        this.form.controls['ddSubRegion'].reset();
        this.form.controls['ddState'].reset();
        this.form.controls['ddCity'].reset();
        this.regions = [];
        this.subregions = [];
        this.states = [];
        this.cities = [];
        this.regions = this.locationList.filter(item => item.country === country).map(item => item.region).filter((value, index, self) => self.indexOf(value) === index);
    }
    onChangeRegion(event) {
        let region = event.target.value;
        this.form.controls['ddSubRegion'].reset();
        this.form.controls['ddState'].reset();
        this.form.controls['ddCity'].reset();
        this.subregions = null;
        this.states = null;
        this.cities = null;
        this.subregions = this.locationList.filter(item => item.region === region).map(item => item.subregion).filter((value, index, self) => self.indexOf(value) === index);
    }
    onChangeSubRegion(event) {
        let subregion = event.target.value;
        this.form.controls['ddState'].reset();
        this.form.controls['ddCity'].reset();
        this.states = [];
        this.cities = [];
        this.states = this.locationList.filter(item => item.subregion === subregion).map(item => item.state).filter((value, index, self) => self.indexOf(value) === index);
    }
    onChangeStates(event) {
        let state = event.target.value;
        this.form.controls['ddCity'].reset();
        this.cities = [];
        this.cities = this.locationList.filter(item => item.state === state).map(item => item.city).filter((value, index, self) => self.indexOf(value) === index);
    }
    updateNewGroup() {
        this.form.get('cmbClientGroup').reset();
    }
    ionViewWillEnter() {
        this.mastSub = Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["combineLatest"])([
            this.divisionService.fetchDivisions(),
            this.clientTypeService.fetchclientTypes(),
            this.potentialNatureService.fetchPotentialnatures(),
            this.locationService.fetchLocations(),
        ]).subscribe(() => {
        });
    }
    ngOnDestroy() {
        if (this.divisionSub) {
            this.divisionSub.unsubscribe();
        }
        if (this.clientTypeSub) {
            this.clientTypeSub.unsubscribe();
        }
        if (this.locationSub) {
            this.locationSub.unsubscribe();
        }
        if (this.mastSub) {
            this.mastSub.unsubscribe();
        }
    }
};
AddClientPage.ctorParameters = () => [
    { type: _client_service__WEBPACK_IMPORTED_MODULE_12__["ClientService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] },
    { type: _services_division_service__WEBPACK_IMPORTED_MODULE_9__["DivisionService"] },
    { type: src_app_services_client_type_service__WEBPACK_IMPORTED_MODULE_8__["ClientTypeService"] },
    { type: src_app_services_potentialnature_service__WEBPACK_IMPORTED_MODULE_11__["PotentialnatureService"] },
    { type: _services_location_service__WEBPACK_IMPORTED_MODULE_10__["LocationService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] }
];
AddClientPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-add-client',
        template: _raw_loader_add_client_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_add_client_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AddClientPage);



/***/ }),

/***/ "9gw7":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/clients/add-client/add-client.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref=\"/clients\">\n      </ion-back-button>\n      <ion-title>New Client</ion-title>\n      <ion-button (click)=\"onAddClient()\" [disabled]=\"!form.valid\">\n        <ion-icon name=\"checkmark\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form [formGroup]=\"form\">\n    <ion-grid>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Division <span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"divisionId\" multiple >\n              <ion-select-option *ngFor=\"let division of divisionList\" [value]=\"division.id\" multiple>{{division.name}}\n              </ion-select-option>\n            </ion-select>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"!form.get('divisionId').valid && form.get('divisionId').touched\">\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <p style=\"font-size: small;color:#FF6347\">Division must not be empty.</p>\n        </ion-col>\n      </ion-row>\n\n\n\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Client Name <span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-input type=\"text\" autocomplete autocorrect formControlName=\"name\"></ion-input>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"!form.get('name').valid && form.get('name').touched\">\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <p style=\"font-size: small;color:#FF6347\">Client Name must not be empty.</p>\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >GST Number <span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-input type=\"text\" autocomplete autocorrect formControlName=\"gstNumber\"></ion-input>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"!form.get('gstNumber').valid && form.get('gstNumber').touched\">\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <p style=\"font-size: small;color:#FF6347\">GST number must not be empty & It should be 15-digit number</p>\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Existing Group</ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"cmbClientGroup\">\n              <ion-select-option *ngFor=\"let clgrp of clientGroup\" [value]=\"clgrp\">{{clgrp}}\n              </ion-select-option>\n            </ion-select>\n      </ion-item>\n      </ion-col>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" style=\"font-size: 12px;\">New Group</ion-label>\n          <ion-input type=\"text\" formControlName=\"clientGroup\" (ionChange)=\"updateNewGroup()\" ></ion-input>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n\n\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Client Type <span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"typeId\" multiple>\n              <ion-select-option *ngFor=\"let clientType of clientTypeList\" [value]=\"clientType.id\">{{clientType.name}}\n              </ion-select-option>\n            </ion-select>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"!form.get('typeId').valid && form.get('typeId').touched\">\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <p style=\"font-size: small;color:#FF6347\">Client Type must not be empty.</p>\n        </ion-col>\n      </ion-row>\n\n\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Contact Person <span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-input type=\"text\" autocomplete autocorrect formControlName=\"contactPerson\"></ion-input>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"!form.get('contactPerson').valid && form.get('contactPerson').touched\">\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <p style=\"font-size: small;color:#FF6347\">Contact Person must not be empty.</p>\n        </ion-col>\n      </ion-row>\n\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Contact Number <span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-input type=\"number\" formControlName=\"contactNumber\"></ion-input>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"form.get('contactNumber').errors?.negativeNumber && form.get('contactNumber').touched\">\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <p style=\"font-size: small;color:#FF6347\">Contact Number should not be negative number.</p>\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Email <span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-input type=\"text\" autocomplete autocorrect formControlName=\"email\"></ion-input>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n      <!-- <ion-row *ngIf=\"!form.errors?.contactDetail &&  form.get('email').touched &&  form.get('contactNumber').touched\">\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <p style=\"font-size: small;color:#FF6347\">Please enter email address/Contact number.</p>\n        </ion-col>\n      </ion-row> -->\n\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Potential Nature <span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"potentialNatureId\">\n              <ion-select-option *ngFor=\"let pn of potentialNatureList\" [value]=\"pn.id\">{{pn.name}}\n              </ion-select-option>\n            </ion-select>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"!form.get('potentialNatureId').valid && form.get('potentialNatureId').touched\">\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <p style=\"font-size: small;color:#FF6347\">Potential Nature must not be empty.</p>\n        </ion-col>\n      </ion-row>\n\n\n\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" >Employee Strength</ion-label>\n              <ion-input type=\"number\" formControlName=\"employeeStrength\"></ion-input>\n        </ion-item>\n        </ion-col>\n        </ion-row>\n      <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Account Owner <span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-input type=\"text\" autocomplete autocorrect formControlName=\"accountOwner\"></ion-input>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"!form.get('accountOwner').valid && form.get('accountOwner').touched\">\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <p style=\"font-size: small;color:#FF6347\">Account Owner Nature must not be empty.</p>\n        </ion-col>\n      </ion-row>\n\n\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Country</ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\" (ionChange)=\"onChangeCountry($event)\" formControlName=\"ddCountry\">\n              <ion-select-option *ngFor=\"let country of countries\" [value]=\"country\">{{country}}\n              </ion-select-option>\n            </ion-select>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Region</ion-label>\n            <ion-select  placeholder=\"Select One\"  interface=\"popover\" (ionChange)=\"onChangeRegion($event)\" formControlName=\"ddRegion\">\n              <ion-select-option *ngFor=\"let region of regions\" [value]=\"region\">{{region}}\n              </ion-select-option>\n            </ion-select>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Sub Region</ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\" (ionChange)=\"onChangeSubRegion($event)\" formControlName=\"ddSubRegion\">\n              <ion-select-option *ngFor=\"let subregion of subregions\" [value]=\"subregion\">{{subregion}}\n              </ion-select-option>\n            </ion-select>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >State</ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\" (ionChange)=\"onChangeStates($event)\"  formControlName=\"ddState\">\n              <ion-select-option *ngFor=\"let state of states\" [value]=\"state\">{{state}}\n              </ion-select-option>\n            </ion-select>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >City</ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\"   formControlName=\"ddCity\">\n              <ion-select-option *ngFor=\"let city of cities\" [value]=\"city\">{{city}}\n              </ion-select-option>\n            </ion-select>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n\n\n    </ion-grid>\n</form>\n</ion-content>\n");

/***/ }),

/***/ "P3Dl":
/*!*****************************************************************!*\
  !*** ./src/app/clients/add-client/add-client-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: AddClientPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddClientPageRoutingModule", function() { return AddClientPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _add_client_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./add-client.page */ "4HmS");




const routes = [
    {
        path: '',
        component: _add_client_page__WEBPACK_IMPORTED_MODULE_3__["AddClientPage"]
    }
];
let AddClientPageRoutingModule = class AddClientPageRoutingModule {
};
AddClientPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AddClientPageRoutingModule);



/***/ }),

/***/ "U+ep":
/*!*********************************************************!*\
  !*** ./src/app/clients/add-client/add-client.module.ts ***!
  \*********************************************************/
/*! exports provided: AddClientPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddClientPageModule", function() { return AddClientPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _add_client_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./add-client-routing.module */ "P3Dl");
/* harmony import */ var _add_client_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-client.page */ "4HmS");








let AddClientPageModule = class AddClientPageModule {
};
AddClientPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _add_client_routing_module__WEBPACK_IMPORTED_MODULE_5__["AddClientPageRoutingModule"]
        ],
        declarations: [_add_client_page__WEBPACK_IMPORTED_MODULE_6__["AddClientPage"]]
    })
], AddClientPageModule);



/***/ }),

/***/ "ZdSY":
/*!*****************************************!*\
  !*** ./src/app/utilities/validators.ts ***!
  \*****************************************/
/*! exports provided: NoNegativeNumbers, atLeastOne */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoNegativeNumbers", function() { return NoNegativeNumbers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "atLeastOne", function() { return atLeastOne; });
function NoNegativeNumbers(control) {
    return control.value < 0 ? { negativeNumber: true } : null;
}
function atLeastOne() {
    return (formGroup) => {
        const emailControl = formGroup.get('email');
        const contactNumberControl = formGroup.get('contactNumber');
        if (!emailControl || !contactNumberControl) {
            return null;
        }
        if ((emailControl.value == null || emailControl.value == '') &&
            (contactNumberControl.value == null || contactNumberControl.value == '')) {
            return null;
        }
        else {
            return { contactDetail: true };
        }
    };
}


/***/ }),

/***/ "oxu2":
/*!*********************************************************!*\
  !*** ./src/app/clients/add-client/add-client.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".searchbar-search-icon {\n  display: none;\n  width: 0;\n  height: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxhZGQtY2xpZW50LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFBYyxRQUFBO0VBQVMsU0FBQTtBQUd6QiIsImZpbGUiOiJhZGQtY2xpZW50LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zZWFyY2hiYXItc2VhcmNoLWljb24ge1xyXG4gIGRpc3BsYXk6bm9uZTsgd2lkdGg6MDsgaGVpZ2h0OjA7XHJcbn1cclxuIl19 */");

/***/ })

}]);
//# sourceMappingURL=add-client-add-client-module.js.map