(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-sales-add-sales-module"],{

/***/ "3L6M":
/*!*********************************************************************!*\
  !*** ./src/app/salespipeline/add-sales/add-sales-routing.module.ts ***!
  \*********************************************************************/
/*! exports provided: AddSalesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddSalesPageRoutingModule", function() { return AddSalesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _add_sales_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./add-sales.page */ "HJbM");




const routes = [
    {
        path: '',
        component: _add_sales_page__WEBPACK_IMPORTED_MODULE_3__["AddSalesPage"]
    }
];
let AddSalesPageRoutingModule = class AddSalesPageRoutingModule {
};
AddSalesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AddSalesPageRoutingModule);



/***/ }),

/***/ "HJbM":
/*!***********************************************************!*\
  !*** ./src/app/salespipeline/add-sales/add-sales.page.ts ***!
  \***********************************************************/
/*! exports provided: AddSalesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddSalesPage", function() { return AddSalesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_add_sales_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./add-sales.page.html */ "u9B/");
/* harmony import */ var _add_sales_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./add-sales.page.scss */ "mfiJ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_clients_client_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/clients/client.service */ "+RYs");
/* harmony import */ var src_app_services_division_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/division.service */ "KWQH");
/* harmony import */ var src_app_utilities_dataconverters__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/utilities/dataconverters */ "igNZ");
/* harmony import */ var _salespipeline_model__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../salespipeline.model */ "ZSGM");
/* harmony import */ var _salespipeline_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../salespipeline.service */ "bL0d");












let AddSalesPage = class AddSalesPage {
    constructor(route, loadingCtrl, clientService, salesPipelineService, divisionService, toastController) {
        this.route = route;
        this.loadingCtrl = loadingCtrl;
        this.clientService = clientService;
        this.salesPipelineService = salesPipelineService;
        this.divisionService = divisionService;
        this.toastController = toastController;
        this.isLoading = false;
    }
    get locations() {
        return this.form.get('dataEntry');
    }
    addLocations() {
        this.locations.push(this.buildDataEntryForm());
    }
    deleteLocatios(index) {
        this.locations.removeAt(index);
    }
    getMachineDetails(fg) {
        let test = fg.get('machineDetails');
        return fg.get('machineDetails');
    }
    addMachineDetails(fg) {
        this.getMachineDetails(fg).push(this.buildMachineDetailForm());
    }
    deleteMachineDetails(fg, index) {
        this.getMachineDetails(fg).removeAt(index);
    }
    buildDataEntryForm() {
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            machineDetails: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormArray"]([this.buildMachineDetailForm()]),
            city: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            }),
            branchcity: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            }),
            isConsumable: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            isRental: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            renLimit: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            accowner: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            }),
            address: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            }),
            installAt: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            installAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            currentStatus: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            }),
            closureDate: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            }),
            amount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: 'blur',
            }),
            billingAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: 'blur',
            }),
            machineCount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: 'blur',
            }),
            branch: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: 'blur',
            }),
        });
    }
    buildMachineDetailForm() {
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            machineName: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            machineType: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            volumeType: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            machineCount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            machineSrNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            machinehsncode: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            rate: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            amount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: 'blur',
            }),
            conflevel: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: 'blur',
            }),
            billingAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: 'blur',
            }),
            mchRent: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: 'blur',
            }),
            consumableCap: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: 'blur',
            }),
            mchInstCharges: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: 'blur',
            }),
            isInstChargesConsider: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: 'blur',
            }),
            mchSecDeposite: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: 'blur',
            }),
            pulloutDate: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: 'blur',
            }),
            pulloutreason: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: 'blur',
            }),
        });
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
                dataEntry: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormArray"]([this.buildDataEntryForm()]),
                group: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: "blur",
                }),
                client: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: "blur",
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                comments: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: "blur",
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].maxLength(180)],
                }),
                amount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                }),
                billingAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                }),
                machineCount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                }),
            });
            this.form.valueChanges.subscribe(val => {
                if (val.client == null)
                    return;
                let clientamount = 0;
                let clientbillamt = 0;
                let clientmachinecount = 0;
                this.form.get('dataEntry')['controls'].forEach((location, i) => {
                    let locamount = 0;
                    let locmachinecount = 0;
                    let locbillamt = 0;
                    this.form.get('dataEntry')['controls'][i].get('machineDetails')['controls'].forEach((machine, j) => {
                        let rate = this.form.get('dataEntry')['controls'][i].get('machineDetails')['controls'][j].get('rate').value;
                        let mccount = this.form.get('dataEntry')['controls'][i].get('machineDetails')['controls'][j].get('machineCount').value;
                        let conflevel = this.form.get('dataEntry')['controls'][i].get('machineDetails')['controls'][j].get('conflevel').value;
                        let amt = rate * Math.round(mccount * conflevel / 100);
                        let closureDate = new Date(this.form.get('dataEntry')['controls'][i].get('closureDate').value);
                        let closureamt = this.financialYearCalculation(closureDate, amt);
                        locamount = locamount + amt;
                        clientamount = clientamount + amt;
                        locbillamt = locbillamt + closureamt;
                        clientbillamt = clientbillamt + closureamt;
                        locmachinecount = locmachinecount + mccount;
                        clientmachinecount = clientmachinecount + mccount;
                        this.form.get('dataEntry')['controls'][i].get('machineDetails')['controls'][j].get('amount').patchValue(amt, { emitEvent: false });
                        this.form.get('dataEntry')['controls'][i].get('machineDetails')['controls'][j].get('billingAmount').patchValue(closureamt, { emitEvent: false });
                    });
                    this.form.get('dataEntry')['controls'][i].get('amount').patchValue(locamount, { emitEvent: false });
                    this.form.get('dataEntry')['controls'][i].get('billingAmount').patchValue(locbillamt, { emitEvent: false });
                    this.form.get('dataEntry')['controls'][i].get('machineCount').patchValue(locmachinecount, { emitEvent: false });
                });
                this.form.get('amount').patchValue(clientamount, { emitEvent: false });
                this.form.get('billingAmount').patchValue(clientbillamt, { emitEvent: false });
                this.form.get('machineCount').patchValue(clientmachinecount, { emitEvent: false });
            });
            this.clients = yield this.clientService.getClientList();
            console.log(this.clients);
            this.clientGroup = this.clients
                .map((item) => item.group)
                .filter((value, index, self) => {
                if (value != null)
                    return self.indexOf(value) === index;
            }).sort();
            this.loadedClients = this.clients;
            this.clientsStatus = yield this.divisionService.getClientStatusList();
            this.machineDetail = yield this.divisionService.getMachineDetailList();
            this.machines = this.machineDetail.filter(item => item.group == 0).sort((a, b) => a.srno - b.srno).map(item => item.name);
            this.machineType = this.machineDetail.filter(item => item.group == 1).sort((a, b) => a.srno - b.srno).map(item => item.name);
        });
    }
    ionViewWillEnter() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.loadBranches();
            yield this.loadAccOwners();
            // this.clientService.fetchClients().subscribe(() => {
            // });
        });
    }
    onAddSalespipeline() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!this.form.valid) {
                return;
            }
            var exiclientId = yield this.salesPipelineService.getClientById(this.form.value.client);
            if (exiclientId.length > 0) {
                yield this.toastController.create({
                    message: 'Client data is already exist.',
                    duration: 2000,
                    color: 'danger',
                }).then((tost) => {
                    tost.present();
                });
                return;
            }
            let salesPipeline = this.AddSalesPipeline();
            this.loadingCtrl.create({ keyboardClose: true }).then((loadingEl) => {
                loadingEl.present();
                // Tree Structue Input
                this.AddClientSalesPipeLine(loadingEl);
                // let arrayLength=salesPipeline.length-1;
                // salesPipeline.forEach((item,index)=>{
                //   this.salesPipelineService.addSalesPipeline(item).subscribe((response)=>{
                //    if (arrayLength == index) {
                //      this.removeLoading(loadingEl);
                //     }
                //   })
                // })
            });
        });
    }
    removeLoading(loadingEl) {
        this.isLoading = false;
        loadingEl.dismiss();
        this.form.reset();
        this.route.navigate(["/salespipeline"]);
    }
    AddClientSalesPipeLine(loadingEl) {
        let locations = [];
        for (let i = 0; i < this.form.value.dataEntry.length; i++) {
            let location = this.form.value.dataEntry[i];
            let machines = [];
            for (let j = 0; j < location.machineDetails.length; j++) {
                let machine = location.machineDetails[j];
                machines.push(new _salespipeline_model__WEBPACK_IMPORTED_MODULE_10__["Machine"](machine.machineName, machine.machineType, machine.volumeType, machine.machineCount, machine.machineSrNo, machine.rate, machine.amount, machine.conflevel, machine.billingAmount, machine.mchRent, machine.consumableCap, machine.mchInstCharges, machine.mchSecDeposite, false, machine.machinehsncode, machine.pulloutDate, machine.pulloutreason));
            }
            locations.push(new _salespipeline_model__WEBPACK_IMPORTED_MODULE_10__["Location"](location.city, location.address, location.installAt, location.installAddress, location.currentStatus, new Date(location.closureDate), location.amount, machines.map((obj) => { return Object.assign({}, obj); }), location.billingAmount, location.machineCount, Object(src_app_utilities_dataconverters__WEBPACK_IMPORTED_MODULE_9__["GetNewId"])(), location.branch, location.accowner, location.branchcity, location.isConsumable, location.isRental, location.renLimit));
        }
        let clientSalesPipeline = new _salespipeline_model__WEBPACK_IMPORTED_MODULE_10__["ClientSalesPipeline"]('', this.form.value.group, this.form.value.client, this.clients.filter((item) => item.id == this.form.value.client)[0].name, this.form.value.comments, '', new Date(), this.form.value.amount, locations.map((obj) => { return Object.assign({}, obj); }), 'add', this.form.value.billingAmount, this.form.value.machineCount);
        this.salesPipelineService.addClientSalesPipeline(clientSalesPipeline).subscribe((response) => {
            this.removeLoading(loadingEl);
        });
    }
    AddSalesPipeline() {
        let salesPipeline = [];
        for (let i = 0; i < this.form.value.dataEntry.length; i++) {
            let location = this.form.value.dataEntry[i];
            for (let j = 0; j < location.machineDetails.length; j++) {
                let machine = location.machineDetails[j];
                salesPipeline.push(new _salespipeline_model__WEBPACK_IMPORTED_MODULE_10__["SalesPipeline"]("", this.form.value.group, this.form.value.client, this.clients.filter((item) => item.id == this.form.value.client)[0].name, this.form.value.comments, location.city, location.address, location.installAt, location.installAddress, location.currentStatus, new Date(location.closureDate), machine.machineName, machine.machineType, machine.volumeType, machine.machineCount, machine.machineSrNo, machine.rate, machine.amount, location.amount, this.form.value.amount, "", new Date(), machine.conflevel, machine.machinehsncode));
            }
        }
        return salesPipeline;
    }
    ngOnDestroy() {
        if (this.clientSub) {
            this.clientSub.unsubscribe();
        }
    }
    onChangeGroup(event) {
        let grp = event.target.value;
        this.form.controls['client'].reset();
        this.loadedClients = [];
        this.loadedClients = this.clients.filter(item => item.group === grp);
    }
    financialYearCalculation(closureDate, amount) {
        let extraday = 7;
        let startDate = new Date(closureDate.getFullYear(), closureDate.getMonth(), closureDate.getDate());
        startDate.setDate(startDate.getDate() + extraday);
        let endDate = new Date(startDate.getMonth() > 2 ? startDate.getFullYear() + 1 : startDate.getFullYear(), 2, 31);
        let diff = new Date(endDate.valueOf() - startDate.valueOf());
        let days = diff.valueOf() / 1000 / 60 / 60 / 24;
        return ((amount * 12) / 264) * days;
    }
    onMachineChange(event, element) {
        if (!event.target.value)
            return;
        let ref = this.machineDetail.filter(item => item.name == event.target.value)[0].name;
        element.controls['volumeType'].reset();
        this.machineCategory = [];
        this.machineCategory = this.machineDetail.filter(item => item.ref == ref && item.group == 2).sort((a, b) => a.srno - b.srno).map(item => item.name);
        if (ref == "FM" || ref == "Mtl(kg/mth)") {
            element.controls['volumeType'].patchValue("Not Applicable", { emitEvent: false });
        }
    }
    loadAccOwners() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.accowners = yield this.divisionService.getAccOwners();
            return true;
        });
    }
    loadBranches() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.branches = yield this.divisionService.getBranches();
            return true;
        });
    }
};
AddSalesPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] },
    { type: src_app_clients_client_service__WEBPACK_IMPORTED_MODULE_7__["ClientService"] },
    { type: _salespipeline_service__WEBPACK_IMPORTED_MODULE_11__["SalespipelineService"] },
    { type: src_app_services_division_service__WEBPACK_IMPORTED_MODULE_8__["DivisionService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] }
];
AddSalesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-add-sales',
        template: _raw_loader_add_sales_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_add_sales_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AddSalesPage);



/***/ }),

/***/ "jHGr":
/*!*************************************************************!*\
  !*** ./src/app/salespipeline/add-sales/add-sales.module.ts ***!
  \*************************************************************/
/*! exports provided: AddSalesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddSalesPageModule", function() { return AddSalesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _add_sales_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./add-sales-routing.module */ "3L6M");
/* harmony import */ var _add_sales_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-sales.page */ "HJbM");







let AddSalesPageModule = class AddSalesPageModule {
};
AddSalesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _add_sales_routing_module__WEBPACK_IMPORTED_MODULE_5__["AddSalesPageRoutingModule"]
        ],
        declarations: [_add_sales_page__WEBPACK_IMPORTED_MODULE_6__["AddSalesPage"]]
    })
], AddSalesPageModule);



/***/ }),

/***/ "mfiJ":
/*!*************************************************************!*\
  !*** ./src/app/salespipeline/add-sales/add-sales.page.scss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".componentWrapper {\n  border: solid cadetblue;\n  border-radius: 40px;\n  padding: 15px 10px 10px 10px;\n  margin-top: 20px;\n  width: 95%;\n}\n\n.componentWrapper .header {\n  position: absolute;\n  margin-top: -25px;\n  margin-left: 10px;\n  color: white;\n  background: cadetblue;\n  border-radius: 10px;\n  padding: 2px 10px;\n}\n\n.cardclose {\n  position: absolute;\n  margin-top: -5px;\n  margin-left: 250px;\n  background: white;\n  border-radius: 5px;\n  margin-bottom: 30px;\n}\n\n.close-icon-info {\n  display: block;\n  box-sizing: border-box;\n  width: 20px;\n  height: 20px;\n  border-width: 3px;\n  border-style: solid;\n  border-color: #3F51B5;\n  border-radius: 100%;\n  background: -webkit-linear-gradient(-45deg, transparent 0%, transparent 46%, white 46%, white 56%, transparent 56%, transparent 100%), -webkit-linear-gradient(45deg, transparent 0%, transparent 46%, white 46%, white 56%, transparent 56%, transparent 100%);\n  background-color: #3F51B5;\n  box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.5);\n  transition: all 0.3s ease;\n  margin: 8px;\n}\n\n.close-icon-accent {\n  display: block;\n  box-sizing: border-box;\n  width: 20px;\n  height: 20px;\n  border-width: 3px;\n  border-style: solid;\n  border-color: #e91e63;\n  border-radius: 100%;\n  background: -webkit-linear-gradient(-45deg, transparent 0%, transparent 46%, white 46%, white 56%, transparent 56%, transparent 100%), -webkit-linear-gradient(45deg, transparent 0%, transparent 46%, white 46%, white 56%, transparent 56%, transparent 100%);\n  background-color: #e91e63;\n  box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.5);\n  transition: all 0.3s ease;\n}\n\n.card-tab {\n  margin-inline: 0px;\n}\n\n.card-content {\n  padding: 0px;\n}\n\n.ionitem1 {\n  background: #3F51B5;\n}\n\n.error-label {\n  font-size: small;\n  color: #fff;\n}\n\n.container {\n  width: 100%;\n  text-align: center;\n}\n\n.left {\n  float: left;\n  height: 30px;\n  margin: 5px;\n}\n\n.center {\n  display: inline-block;\n  height: 30px;\n  margin: 5px;\n}\n\n.right {\n  float: right;\n  height: 30px;\n  margin: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxhZGQtc2FsZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLDRCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUFFRjs7QUFBQTtFQUVFLGNBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSwrUEFBQTtFQUNBLHlCQUFBO0VBQ0EsOENBQUE7RUFDQSx5QkFBQTtFQUNBLFdBQUE7QUFFRjs7QUFBQTtFQUVFLGNBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSwrUEFBQTtFQUNBLHlCQUFBO0VBQ0EsOENBQUE7RUFDQSx5QkFBQTtBQUVGOztBQUVDO0VBQ0Msa0JBQUE7QUFDRjs7QUFDQztFQUNDLFlBQUE7QUFFRjs7QUFBQztFQUNELG1CQUFBO0FBR0E7O0FBQUE7RUFDRSxnQkFBQTtFQUFpQixXQUFBO0FBSW5COztBQURBO0VBQ0UsV0FBQTtFQUNBLGtCQUFBO0FBSUY7O0FBREE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFJRjs7QUFEQTtFQUNFLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFJRjs7QUFEQTtFQUNFLFlBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQUlGIiwiZmlsZSI6ImFkZC1zYWxlcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29tcG9uZW50V3JhcHBlciB7XHJcbiAgYm9yZGVyOiBzb2xpZCBjYWRldGJsdWU7XHJcbiAgYm9yZGVyLXJhZGl1czogNDBweDtcclxuICBwYWRkaW5nOiAxNXB4IDEwcHggMTBweCAxMHB4O1xyXG4gIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgd2lkdGg6IDk1JTtcclxufVxyXG5cclxuLmNvbXBvbmVudFdyYXBwZXIgLmhlYWRlciB7XHJcbiAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgbWFyZ2luLXRvcDotMjVweDtcclxuICBtYXJnaW4tbGVmdDoxMHB4O1xyXG4gIGNvbG9yOndoaXRlO1xyXG4gIGJhY2tncm91bmQ6Y2FkZXRibHVlO1xyXG4gIGJvcmRlci1yYWRpdXM6MTBweDtcclxuICBwYWRkaW5nOjJweCAxMHB4O1xyXG59XHJcbi5jYXJkY2xvc2Uge1xyXG4gIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gIG1hcmdpbi10b3A6LTVweDtcclxuICBtYXJnaW4tbGVmdDoyNTBweDtcclxuICBiYWNrZ3JvdW5kOndoaXRlO1xyXG4gIGJvcmRlci1yYWRpdXM6NXB4O1xyXG4gIG1hcmdpbi1ib3R0b206MzBweDtcclxufVxyXG4uY2xvc2UtaWNvbi1pbmZvXHJcbntcclxuICBkaXNwbGF5OmJsb2NrO1xyXG4gIGJveC1zaXppbmc6Ym9yZGVyLWJveDtcclxuICB3aWR0aDoyMHB4O1xyXG4gIGhlaWdodDoyMHB4O1xyXG4gIGJvcmRlci13aWR0aDozcHg7XHJcbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICBib3JkZXItY29sb3I6IzNGNTFCNTtcclxuICBib3JkZXItcmFkaXVzOjEwMCU7XHJcbiAgYmFja2dyb3VuZDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQoLTQ1ZGVnLCB0cmFuc3BhcmVudCAwJSwgdHJhbnNwYXJlbnQgNDYlLCB3aGl0ZSA0NiUsICB3aGl0ZSA1NiUsdHJhbnNwYXJlbnQgNTYlLCB0cmFuc3BhcmVudCAxMDAlKSwgLXdlYmtpdC1saW5lYXItZ3JhZGllbnQoNDVkZWcsIHRyYW5zcGFyZW50IDAlLCB0cmFuc3BhcmVudCA0NiUsIHdoaXRlIDQ2JSwgIHdoaXRlIDU2JSx0cmFuc3BhcmVudCA1NiUsIHRyYW5zcGFyZW50IDEwMCUpO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IzNGNTFCNTtcclxuICBib3gtc2hhZG93OjBweCAwcHggNXB4IDJweCByZ2JhKDAsMCwwLDAuNSk7XHJcbiAgdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZTtcclxuICBtYXJnaW46IDhweDtcclxufVxyXG4uY2xvc2UtaWNvbi1hY2NlbnRcclxue1xyXG4gIGRpc3BsYXk6YmxvY2s7XHJcbiAgYm94LXNpemluZzpib3JkZXItYm94O1xyXG4gIHdpZHRoOjIwcHg7XHJcbiAgaGVpZ2h0OjIwcHg7XHJcbiAgYm9yZGVyLXdpZHRoOjNweDtcclxuICBib3JkZXItc3R5bGU6IHNvbGlkO1xyXG4gIGJvcmRlci1jb2xvcjojZTkxZTYzO1xyXG4gIGJvcmRlci1yYWRpdXM6MTAwJTtcclxuICBiYWNrZ3JvdW5kOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudCgtNDVkZWcsIHRyYW5zcGFyZW50IDAlLCB0cmFuc3BhcmVudCA0NiUsIHdoaXRlIDQ2JSwgIHdoaXRlIDU2JSx0cmFuc3BhcmVudCA1NiUsIHRyYW5zcGFyZW50IDEwMCUpLCAtd2Via2l0LWxpbmVhci1ncmFkaWVudCg0NWRlZywgdHJhbnNwYXJlbnQgMCUsIHRyYW5zcGFyZW50IDQ2JSwgd2hpdGUgNDYlLCAgd2hpdGUgNTYlLHRyYW5zcGFyZW50IDU2JSwgdHJhbnNwYXJlbnQgMTAwJSk7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjojZTkxZTYzO1xyXG4gIGJveC1zaGFkb3c6MHB4IDBweCA1cHggMnB4IHJnYmEoMCwwLDAsMC41KTtcclxuICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlO1xyXG59XHJcblxyXG5cclxuIC5jYXJkLXRhYntcclxuICBtYXJnaW4taW5saW5lOiAwcHg7XHJcbiB9XHJcbiAuY2FyZC1jb250ZW50e1xyXG4gIHBhZGRpbmc6IDBweDtcclxuIH1cclxuIC5pb25pdGVtMXtcclxuYmFja2dyb3VuZDogIzNGNTFCNTtcclxuIH1cclxuXHJcbi5lcnJvci1sYWJlbHtcclxuICBmb250LXNpemU6IHNtYWxsO2NvbG9yOiNmZmZcclxufVxyXG5cclxuLmNvbnRhaW5lciB7XHJcbiAgd2lkdGg6MTAwJTtcclxuICB0ZXh0LWFsaWduOmNlbnRlcjtcclxufVxyXG5cclxuLmxlZnQge1xyXG4gIGZsb2F0OmxlZnQ7XHJcbiAgaGVpZ2h0OiAzMHB4O1xyXG4gIG1hcmdpbjogNXB4O1xyXG59XHJcblxyXG4uY2VudGVyIHtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgaGVpZ2h0OiAzMHB4O1xyXG4gIG1hcmdpbjogNXB4O1xyXG59XHJcblxyXG4ucmlnaHQge1xyXG4gIGZsb2F0OnJpZ2h0O1xyXG4gIGhlaWdodDogMzBweDtcclxuICBtYXJnaW46IDVweDtcclxufVxyXG5cclxuIl19 */");

/***/ }),

/***/ "u9B/":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/salespipeline/add-sales/add-sales.page.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref=\"/clients\">\n      </ion-back-button>\n      <ion-title>Salespipeline Entry</ion-title>\n      <!-- <ion-button (click)=\"onAddSalespipeline()\" [disabled]=\"!form.valid\"> -->\n        <ion-button (click)=\"onAddSalespipeline()\" [disabled]=\"!form.valid\">\n        <ion-icon name=\"checkmark\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <form [formGroup]=\"form\">\n    <ion-grid>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label>Client Group</ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"group\"  (ionChange)=\"onChangeGroup($event)\">\n              <ion-select-option *ngFor=\"let grp of clientGroup\" [value]=\"grp\">{{grp}}\n              </ion-select-option>\n            </ion-select>\n          </ion-item>\n          <ion-item>\n            <ion-label>Client <span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-label></ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"client\">\n              <ion-select-option *ngFor=\"let client of loadedClients\" [value]=\"client.id\" >\n                {{client.name}}\n              </ion-select-option>\n            </ion-select>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"!form.get('client').valid && form.get('client').touched\">\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <p>Client must not be empty.</p>\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Comment<span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-textarea row=\"3\" formControlName=\"comments\"></ion-textarea>\n          </ion-item>\n          <ion-item color=\"success\">\n            <p>Amount : </p>\n            <ion-input type=\"number\" formControlName=\"amount\" readonly></ion-input>\n          </ion-item>\n          <ion-item style=\"display: none;\">\n            <ion-input type=\"number\" formControlName=\"billingAmount\" readonly></ion-input>\n            <ion-input type=\"number\" formControlName=\"machineCount\" readonly></ion-input>\n          </ion-item>\n\n      </ion-col>\n      </ion-row>\n\n\n<!-- <div class='componentWrapper'>\n  <p class='header'>Data Entry </p><p class=\"close\"> <ion-icon name=\"close\" color=\"warning\" slot=\"icon-only\" color=\"danger\"(click)=\"deleteAlternetEmail(i)\" ></ion-icon>\n  </p> -->\n\n  <ion-card class=\"card-tab\" style=\"background:#3F51B5\" *ngFor=\"let item of form.get('dataEntry')['controls']; let i = index;\">\n  <ion-card-content class=\"card-content\">\n  <ion-row  formArrayName=\"dataEntry\">\n    <ion-col size-sm=\"6\" offset-sm=\"3\" style=\"margin-inline:0px\">\n      <div [formGroupName]=\"i\">\n\n        <div id=\"container\">\n          <div class=\"center\"><ion-label style=\"color: #fff;padding-right: 70px;\">Location Detail</ion-label></div>\n          <div class=\"right\"><button class=\"close-icon-info\" (click)=\"deleteLocatios(i)\"></button></div>\n        </div>\n\n\n\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" >City <span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-input formControlName=\"city\"></ion-input>\n            </ion-item>\n        </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" >Branch <span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"branchcity\">\n                <ion-select-option *ngFor=\"let branch of branches\" [value]=\"branch.name\">{{branch.name}}\n                </ion-select-option>\n              </ion-select>\n            </ion-item>\n        </ion-col>\n        </ion-row>\n\n        <ion-row *ngIf=\"!form.get('dataEntry')['controls'][i].get('city').valid && form.get('dataEntry')['controls'][i].get('city').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p class=\"error-label\">City should not be empty.</p>\n          </ion-col>\n        </ion-row>\n\n\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label>Consumable Invoice Applicable</ion-label>\n              <ion-checkbox color=\"primary\" slot=\"start\" formControlName=\"isConsumable\"></ion-checkbox>\n            </ion-item>\n        </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label>Rental Invoice Applicable</ion-label>\n              <ion-checkbox color=\"primary\" slot=\"start\" formControlName=\"isRental\"></ion-checkbox>\n            </ion-item>\n        </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label  position=\"floating\">Cap for Rental Invoice</ion-label>\n              <ion-input type=\"number\" formControlName=\"renLimit\"></ion-input>\n            </ion-item>\n        </ion-col>\n        </ion-row>\n\n\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" >Account Managed By <span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"accowner\">\n                <ion-select-option *ngFor=\"let accname of accowners\" [value]=\"accname.name\">{{accname.name}}\n                </ion-select-option>\n              </ion-select>\n\n            </ion-item>\n        </ion-col>\n        </ion-row>\n\n        <ion-row *ngIf=\"!form.get('dataEntry')['controls'][i].get('accowner').valid && form.get('dataEntry')['controls'][i].get('accowner').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p class=\"error-label\">Account Managed By should not be empty.</p>\n          </ion-col>\n        </ion-row>\n\n\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" >Billing Address <span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-textarea rows=\"3\"  formControlName=\"address\"></ion-textarea>\n            </ion-item>\n        </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" >Installed At <span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-input type=\"text\" formControlName=\"installAt\"></ion-input>\n            </ion-item>\n        </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" >Installation Address <span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-textarea rows=\"3\"  formControlName=\"installAddress\"></ion-textarea>\n            </ion-item>\n        </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\"> Deliver From Branch\n              </ion-label>\n              <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"branch\">\n                <ion-select-option *ngFor=\"let branch of branches\" [value]=\"branch.name\">{{branch.name}}\n                </ion-select-option>\n              </ion-select>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\">Current Status <span style=\"color: #FF6347;\">*</span></ion-label>\n          <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"currentStatus\">\n            <ion-select-option *ngFor=\"let cstatus of clientsStatus\" [value]=\"cstatus.status\">{{cstatus.status}}\n            </ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" >Closure Date <span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-datetime\n              formControlName=\"closureDate\"\n              display-format=\"MMM DD YYYY\"\n              picker-format=\"YY MMM DD\"\n              ></ion-datetime>\n            </ion-item>\n            <ion-item  color=\"success\" >\n              <p>Amount : </p>\n              <ion-input type=\"number\" formControlName=\"amount\" readonly></ion-input>\n            </ion-item>\n            <ion-item style=\"display: none;\">\n              <ion-input type=\"number\" formControlName=\"billingAmount\" readonly></ion-input>\n              <ion-input type=\"number\" formControlName=\"machineCount\" readonly></ion-input>\n            </ion-item>\n        </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('dataEntry')['controls'][i].get('address').valid && form.get('dataEntry')['controls'][i].get('address').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p class=\"error-label\">Address should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <div style=\"background: #e91e63;margin: 5px;\"  *ngFor=\"let item of form.get('dataEntry')['controls'][i].get('machineDetails')['controls']; let j = index;\">\n          <ion-row  formArrayName=\"machineDetails\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <div [formGroupName]=\"j\">\n                <div id=\"container\">\n                  <div class=\"center\"><ion-label style=\"color: #fff;padding-right: 70px;\"> <ion-icon name=\"chevron-forward\"></ion-icon> Machine Detail</ion-label></div>\n                  <div class=\"right\"><button class=\"close-icon-accent\" (click)=\"deleteMachineDetails(form.get('dataEntry')['controls'][i],j)\"></button></div>\n                </div>\n                <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Machine/Material <span style=\"color: #FF6347;\">*</span></ion-label>\n                    <!-- <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineName\">\n                      <ion-select-option value='Brewer'>Brewer</ion-select-option>\n                      <ion-select-option value='FM'>FM</ion-select-option>\n                      <ion-select-option value='B2C'>B2C</ion-select-option>\n                      <ion-select-option value='PreMix'>PreMix</ion-select-option>\n                      <ion-select-option value='Mtl(kg/mth)'>Mtl(kg/mth)</ion-select-option>\n                    </ion-select> -->\n\n                    <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineName\" (ionChange)=\"onMachineChange($event,form.get('dataEntry')['controls'][i].get('machineDetails')['controls'][j])\">\n                      <ion-select-option *ngFor=\"let machine of machines\" [value]=\"machine\">{{machine}}\n                      </ion-select-option>\n                      </ion-select>\n\n\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Type <span style=\"color: #FF6347;\">*</span></ion-label>\n                    <!-- <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineType\">\n                      <ion-select-option value='Manual'>Manual</ion-select-option>\n                      <ion-select-option value='Automatic'>Automatic</ion-select-option>\n                    </ion-select> -->\n\n                    <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineType\">\n                      <ion-select-option *ngFor=\"let machine of machineType\" [value]=\"machine\">{{machine}}\n                      </ion-select-option>\n                      </ion-select>\n\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Category <span style=\"color: #FF6347;\">*</span></ion-label>\n                    <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"volumeType\">\n                      <ion-select-option *ngFor=\"let machine of machineCategory\" [value]=\"machine\">{{machine}}\n                      </ion-select-option>\n                      </ion-select>\n\n                    <!-- <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"volumeType\">\n                      <ion-select-option value='Not Applicable'>Not Applicable</ion-select-option>\n                      <ion-select-option value='2-Chamber'>2-Chamber</ion-select-option>\n                      <ion-select-option value='3-Chamber'>3-Chamber</ion-select-option>\n                      <ion-select-option value='4-Chamber'>4-Chamber</ion-select-option>\n                      <ion-select-option value='Tea'>Tea</ion-select-option>\n                      <ion-select-option value='Coffee'>Coffee</ion-select-option>\n                      <ion-select-option value='Beans'>Beans</ion-select-option>\n                      <ion-select-option value='5 ltr'>5 ltr</ion-select-option>\n                      <ion-select-option value='10 ltr'>10 ltr</ion-select-option>\n                      <ion-select-option value='20 ltr'>20 ltr</ion-select-option>\n                    </ion-select> -->\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Machine Count <span style=\"color: #FF6347;\">*</span></ion-label>\n                    <ion-input type=\"text\" formControlName=\"machineCount\"></ion-input>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Machine HSNCode <span style=\"color: #FF6347;\">*</span></ion-label>\n                    <ion-input type=\"text\" formControlName=\"machinehsncode\"></ion-input>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Machine Serial No <span style=\"color: #FF6347;\">*</span></ion-label>\n                    <ion-input type=\"text\" formControlName=\"machineSrNo\"></ion-input>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Rate <span style=\"color: #FF6347;\">*</span></ion-label>\n                    <ion-input type=\"number\" formControlName=\"rate\"></ion-input>\n                  </ion-item>\n\n                  <ion-item>\n                    <ion-label position=\"floating\" >Confidance Level % <span style=\"color: #FF6347;\">*</span></ion-label>\n                    <ion-input type=\"number\" formControlName=\"conflevel\"></ion-input>\n                  </ion-item>\n\n\n                  <ion-item color=\"success\">\n                    <p>Amount : </p>\n                    <ion-input type=\"number\" formControlName=\"amount\"  readonly></ion-input>\n\n                  </ion-item>\n                  <ion-item style=\"display: none;\">\n                    <ion-input type=\"number\" formControlName=\"billingAmount\" readonly></ion-input>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Machine Rent <span style=\"color: #FF6347;\">(if Applicable)*</span></ion-label>\n                    <ion-input type=\"text\" formControlName=\"mchRent\"></ion-input>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Consumable CAP <span style=\"color: #FF6347;\">(if Applicable)*</span></ion-label>\n                    <ion-input type=\"text\" formControlName=\"consumableCap\"></ion-input>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Installation Charges<span style=\"color: #FF6347;\">(if Applicable)*</span></ion-label>\n                    <ion-input type=\"text\" formControlName=\"mchInstCharges\"></ion-input>\n                  </ion-item>\n                  <ion-item style=\"display: none;\">\n                    <ion-input type=\"text\" formControlName=\"isInstChargesConsider\" readonly></ion-input>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Security Deposite<span style=\"color: #FF6347;\">(if Applicable)*</span></ion-label>\n                    <ion-input type=\"text\" formControlName=\"mchSecDeposite\"></ion-input>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n              <ion-item>\n                <ion-label position=\"floating\" >Pullout Date<span style=\"color: #FF6347;\">*</span></ion-label>\n                <ion-datetime\n                formControlName=\"pulloutDate\"\n                display-format=\"MMM DD YYYY\"\n                picker-format=\"YY MMM DD\"\n                ></ion-datetime>\n              </ion-item>\n            </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Pullout Reason <span style=\"color: #FF6347;\"></span></ion-label>\n                    <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"pulloutreason\">\n                      <ion-select-option value='none'>None</ion-select-option>\n                      <ion-select-option value='Return'>Return </ion-select-option>\n                          <ion-select-option value='Replacement'>Replacement</ion-select-option>\n                          <ion-select-option value='Ignore'>Ignore from pullout Month</ion-select-option>\n                        </ion-select>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n\n            </div>\n            </ion-col>\n        </ion-row>\n        </div>\n\n\n\n\n\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-button (click)=\"addMachineDetails(form.get('dataEntry')['controls'][i])\" color=\"warning\"><ion-icon name=\"add\" slot=\"icon-only\"></ion-icon> Add Machine </ion-button>\n          </ion-col>\n        </ion-row>\n      </div>\n    </ion-col>\n  </ion-row>\n</ion-card-content>\n</ion-card>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-button (click)=\"addLocations()\">  <ion-icon name=\"add\" slot=\"icon-only\"></ion-icon> Add Location</ion-button>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n</form>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=add-sales-add-sales-module.js.map