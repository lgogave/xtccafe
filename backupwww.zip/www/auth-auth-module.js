(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["auth-auth-module"],{

/***/ "6epW":
/*!*********************************************!*\
  !*** ./src/app/auth/auth-routing.module.ts ***!
  \*********************************************/
/*! exports provided: AuthPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthPageRoutingModule", function() { return AuthPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _auth_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth.page */ "kV0F");




const routes = [
    {
        path: '',
        component: _auth_page__WEBPACK_IMPORTED_MODULE_3__["AuthPage"]
    }
];
let AuthPageRoutingModule = class AuthPageRoutingModule {
};
AuthPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AuthPageRoutingModule);



/***/ }),

/***/ "Buvn":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<ion-content>\n  <!-- <div class=\"ion-text-center\">\n    <ion-spinner color=\"primary\" *ngIf=\"isLoading\"></ion-spinner>\n  </div> -->\n  <form #f=\"ngForm\" (ngSubmit)=\"onSubmit(f)\">\n  <ion-grid>\n\n    <ion-row>\n      <ion-col  size-sm=\"6\" offset-sm=\"3\">\n        <div class=\"login-wrap\">\n          <div class=\"login-html\">\n\n\n            <ion-icon name=\"lock-closed\" style=\"font-size:35px;color: #e55d87;padding-right: 10px;\"></ion-icon>\n          <input id=\"tab-1\" type=\"radio\" name=\"tab\" class=\"sign-in\" checked><label for=\"tab-1\" class=\"tab\"> Sign In</label>\n\n            <input id=\"tab-2\" type=\"radio\" name=\"tab\" class=\"sign-up\"><label for=\"tab-2\" class=\"tab\" style=\"display: none;\">Sign Up</label>\n            <div class=\"login-form\">\n              <div class=\"sign-in-htm\">\n                <div class=\"group\">\n                  <label for=\"user\" class=\"label\">Email</label>\n                  <ion-input id=\"user\" type=\"text\" class=\"input\" ngModel name=\"email\" required email #emailCtrl=\"ngModel\"></ion-input>\n                </div>\n\n                <div class=\"group\" *ngIf=\"!emailCtrl.valid && emailCtrl.touched\" lines=\"none\">\n                  <label for=\"user\" class=\"label-error\">Should be a valid email address.</label>\n                </div>\n\n                <div class=\"group\">\n                  <label for=\"pass\" class=\"label\">Password</label>\n                  <ion-input id=\"pass\" type=\"password\" class=\"input\" data-type=\"password\" ngModel name=\"password\" required minlength=\"6\" #passCtrl=\"ngModel\"></ion-input>\n                </div>\n\n                <div class=\"group\" *ngIf=\"!passCtrl.valid && passCtrl.touched\" lines=\"none\">\n                  <label for=\"user\" class=\"label-error\">Should be a valid password</label>\n                </div>\n\n                <div class=\"group\">\n                  <input type=\"submit\"   [ngClass]=\"['button', !f.valid?'button-deactive':'button-active']\" value=\"Sign In\" [disabled]=\"!f.valid\">\n                </div>\n              </div>\n\n            </div>\n          </div>\n        </div>\n      </ion-col>\n\n\n    </ion-row>\n\n\n\n  </ion-grid>\n</form>\n</ion-content>\n");

/***/ }),

/***/ "Yj9t":
/*!*************************************!*\
  !*** ./src/app/auth/auth.module.ts ***!
  \*************************************/
/*! exports provided: AuthPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthPageModule", function() { return AuthPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _auth_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./auth-routing.module */ "6epW");
/* harmony import */ var _auth_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./auth.page */ "kV0F");







let AuthPageModule = class AuthPageModule {
};
AuthPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _auth_routing_module__WEBPACK_IMPORTED_MODULE_5__["AuthPageRoutingModule"]
        ],
        declarations: [_auth_page__WEBPACK_IMPORTED_MODULE_6__["AuthPage"]]
    })
], AuthPageModule);



/***/ }),

/***/ "jMPm":
/*!*************************************!*\
  !*** ./src/app/auth/auth.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("*, :after, :before {\n  box-sizing: border-box;\n}\n\n.clearfix:after, .clearfix:before {\n  content: \"\";\n  display: table;\n}\n\n.clearfix:after {\n  clear: both;\n  display: block;\n}\n\na {\n  color: inherit;\n  text-decoration: none;\n}\n\n.login-wrap {\n  width: 100%;\n  margin: auto;\n  max-width: 525px;\n  min-height: 670px;\n  position: relative;\n  background: url('splash.png') no-repeat center;\n  box-shadow: 0 12px 15px 0 rgba(0, 0, 0, 0.24), 0 17px 50px 0 rgba(0, 0, 0, 0.19);\n}\n\n.login-html {\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  padding: 90px 30px 50px 30px;\n  background: rgba(8, 80, 120, 0.5);\n}\n\n.login-html .sign-in-htm,\n.login-html .sign-up-htm {\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  position: absolute;\n  transform: rotateY(180deg);\n  -webkit-backface-visibility: hidden;\n          backface-visibility: hidden;\n  transition: all 0.4s linear;\n}\n\n.login-html .sign-in,\n.login-html .sign-up,\n.login-form .group .check {\n  display: none;\n}\n\n.login-html .tab,\n.login-form .group .label,\n.login-form .group .button {\n  text-transform: uppercase;\n}\n\n.login-html .tab {\n  font-size: 22px;\n  margin-right: 15px;\n  padding-bottom: 5px;\n  margin: 0 15px 10px 0;\n  display: inline-block;\n  border-bottom: 2px solid transparent;\n}\n\n.login-html .sign-in:checked + .tab,\n.login-html .sign-up:checked + .tab {\n  color: #fff;\n  border-color: #1161ee;\n}\n\n.login-form {\n  min-height: 345px;\n  position: relative;\n  perspective: 1000px;\n  transform-style: preserve-3d;\n}\n\n.login-form .group {\n  margin-bottom: 15px;\n}\n\n.login-form .group .label,\n.login-form .group .input,\n.login-form .group .button {\n  width: 100%;\n  color: #3e4444;\n  display: block;\n}\n\n.login-form .group .input,\n.login-form .group .button {\n  border: none;\n  padding: 15px 20px;\n  border-radius: 25px;\n  background: rgba(213, 225, 223, 0.9);\n}\n\n.login-form .group input[data-type=password] {\n  -webkit-text-security: circle;\n}\n\n.login-form .group .label {\n  color: #ccff33;\n  font-size: 14px;\n  font-weight: 700;\n  padding: 10px;\n}\n\n.login-form .group .label-error {\n  color: #FF0000;\n  font-size: 14px;\n  font-weight: 700;\n}\n\n.login-form .group .button-active {\n  background: #ccff33;\n  font-weight: 700;\n}\n\n.login-form .group .button-deactive {\n  background-color: rgba(8, 80, 120, 0.9);\n  color: #B0C4DE;\n  font-weight: 700;\n}\n\n.login-form .group label .icon {\n  width: 15px;\n  height: 15px;\n  border-radius: 2px;\n  position: relative;\n  display: inline-block;\n  background: rgba(255, 255, 255, 0.1);\n}\n\n.login-form .group label .icon:before,\n.login-form .group label .icon:after {\n  content: \"\";\n  width: 10px;\n  height: 2px;\n  background: #fff;\n  position: absolute;\n  transition: all 0.2s ease-in-out 0s;\n}\n\n.login-form .group label .icon:before {\n  left: 3px;\n  width: 5px;\n  bottom: 6px;\n  transform: scale(0) rotate(0);\n}\n\n.login-form .group label .icon:after {\n  top: 6px;\n  right: 0;\n  transform: scale(0) rotate(0);\n}\n\n.login-form .group .check:checked + label {\n  color: #fff;\n}\n\n.login-form .group .check:checked + label .icon {\n  background: #1161ee;\n}\n\n.login-form .group .check:checked + label .icon:before {\n  transform: scale(1) rotate(45deg);\n}\n\n.login-form .group .check:checked + label .icon:after {\n  transform: scale(1) rotate(-45deg);\n}\n\n.login-html .sign-in:checked + .tab + .sign-up + .tab + .login-form .sign-in-htm {\n  transform: rotate(0);\n}\n\n.login-html .sign-up:checked + .tab + .login-form .sign-up-htm {\n  transform: rotate(0);\n}\n\n.hr {\n  height: 2px;\n  margin: 60px 0 50px 0;\n  background: rgba(255, 255, 255, 0.2);\n}\n\n.foot-lnk {\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGF1dGgucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQWlCLHNCQUFBO0FBQ2pCOztBQUFBO0VBQWlDLFdBQUE7RUFBVyxjQUFBO0FBSzVDOztBQUpBO0VBQWdCLFdBQUE7RUFBVyxjQUFBO0FBUzNCOztBQVJBO0VBQUUsY0FBQTtFQUFjLHFCQUFBO0FBYWhCOztBQVhBO0VBQ0MsV0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSw4Q0FBQTtFQUNBLGdGQUFBO0FBY0Q7O0FBWkE7RUFDQyxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsNEJBQUE7RUFDQSxpQ0FBQTtBQWVEOztBQWJBOztFQUVDLE1BQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxrQkFBQTtFQUNBLDBCQUFBO0VBQ0EsbUNBQUE7VUFBQSwyQkFBQTtFQUNBLDJCQUFBO0FBZ0JEOztBQWRBOzs7RUFHQyxhQUFBO0FBaUJEOztBQWZBOzs7RUFHQyx5QkFBQTtBQWtCRDs7QUFoQkE7RUFDQyxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0EscUJBQUE7RUFDQSxvQ0FBQTtBQW1CRDs7QUFqQkE7O0VBRUMsV0FBQTtFQUNBLHFCQUFBO0FBb0JEOztBQWxCQTtFQUNDLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLDRCQUFBO0FBcUJEOztBQW5CQTtFQUNDLG1CQUFBO0FBc0JEOztBQXBCQTs7O0VBR0MsV0FBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0FBdUJEOztBQXJCQTs7RUFFQyxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLG9DQUFBO0FBd0JEOztBQXRCQTtFQUNDLDZCQUFBO0FBeUJEOztBQXZCQTtFQUNDLGNBQUE7RUFDQSxlQUFBO0VBQ0MsZ0JBQUE7RUFDQSxhQUFBO0FBMEJGOztBQXZCQTtFQUNFLGNBQUE7RUFDRCxlQUFBO0VBQ0MsZ0JBQUE7QUEwQkY7O0FBdkJBO0VBQ0MsbUJBQUE7RUFDQyxnQkFBQTtBQTBCRjs7QUF4QkE7RUFDRSx1Q0FBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQTJCRjs7QUF4QkE7RUFDQyxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLG9DQUFBO0FBMkJEOztBQXpCQTs7RUFFQyxXQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUNBQUE7QUE0QkQ7O0FBMUJBO0VBQ0MsU0FBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsNkJBQUE7QUE2QkQ7O0FBM0JBO0VBQ0MsUUFBQTtFQUNBLFFBQUE7RUFDQSw2QkFBQTtBQThCRDs7QUE1QkE7RUFDQyxXQUFBO0FBK0JEOztBQTdCQTtFQUNDLG1CQUFBO0FBZ0NEOztBQTlCQTtFQUNDLGlDQUFBO0FBaUNEOztBQS9CQTtFQUNDLGtDQUFBO0FBa0NEOztBQWhDQTtFQUNDLG9CQUFBO0FBbUNEOztBQWpDQTtFQUNDLG9CQUFBO0FBb0NEOztBQWpDQTtFQUNDLFdBQUE7RUFDQSxxQkFBQTtFQUNBLG9DQUFBO0FBb0NEOztBQWxDQTtFQUNDLGtCQUFBO0FBcUNEIiwiZmlsZSI6ImF1dGgucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiosOmFmdGVyLDpiZWZvcmV7Ym94LXNpemluZzpib3JkZXItYm94fVxyXG4uY2xlYXJmaXg6YWZ0ZXIsLmNsZWFyZml4OmJlZm9yZXtjb250ZW50OicnO2Rpc3BsYXk6dGFibGV9XHJcbi5jbGVhcmZpeDphZnRlcntjbGVhcjpib3RoO2Rpc3BsYXk6YmxvY2t9XHJcbmF7Y29sb3I6aW5oZXJpdDt0ZXh0LWRlY29yYXRpb246bm9uZX1cclxuXHJcbi5sb2dpbi13cmFwe1xyXG5cdHdpZHRoOjEwMCU7XHJcblx0bWFyZ2luOmF1dG87XHJcblx0bWF4LXdpZHRoOjUyNXB4O1xyXG5cdG1pbi1oZWlnaHQ6NjcwcHg7XHJcblx0cG9zaXRpb246cmVsYXRpdmU7XHJcblx0YmFja2dyb3VuZDp1cmwoJy4uLy4uL2Fzc2V0cy9pY29uL3NwbGFzaC5wbmcnKSBuby1yZXBlYXQgY2VudGVyO1xyXG5cdGJveC1zaGFkb3c6MCAxMnB4IDE1cHggMCByZ2JhKDAsMCwwLC4yNCksMCAxN3B4IDUwcHggMCByZ2JhKDAsMCwwLC4xOSk7XHJcbn1cclxuLmxvZ2luLWh0bWx7XHJcblx0d2lkdGg6MTAwJTtcclxuXHRoZWlnaHQ6MTAwJTtcclxuXHRwb3NpdGlvbjphYnNvbHV0ZTtcclxuXHRwYWRkaW5nOjkwcHggMzBweCA1MHB4IDMwcHg7XHJcblx0YmFja2dyb3VuZDpyZ2JhKDgsIDgwLCAxMjAsLjUpO1xyXG59XHJcbi5sb2dpbi1odG1sIC5zaWduLWluLWh0bSxcclxuLmxvZ2luLWh0bWwgLnNpZ24tdXAtaHRte1xyXG5cdHRvcDowO1xyXG5cdGxlZnQ6MDtcclxuXHRyaWdodDowO1xyXG5cdGJvdHRvbTowO1xyXG5cdHBvc2l0aW9uOmFic29sdXRlO1xyXG5cdHRyYW5zZm9ybTpyb3RhdGVZKDE4MGRlZyk7XHJcblx0YmFja2ZhY2UtdmlzaWJpbGl0eTpoaWRkZW47XHJcblx0dHJhbnNpdGlvbjphbGwgLjRzIGxpbmVhcjtcclxufVxyXG4ubG9naW4taHRtbCAuc2lnbi1pbixcclxuLmxvZ2luLWh0bWwgLnNpZ24tdXAsXHJcbi5sb2dpbi1mb3JtIC5ncm91cCAuY2hlY2t7XHJcblx0ZGlzcGxheTpub25lO1xyXG59XHJcbi5sb2dpbi1odG1sIC50YWIsXHJcbi5sb2dpbi1mb3JtIC5ncm91cCAubGFiZWwsXHJcbi5sb2dpbi1mb3JtIC5ncm91cCAuYnV0dG9ue1xyXG5cdHRleHQtdHJhbnNmb3JtOnVwcGVyY2FzZTtcclxufVxyXG4ubG9naW4taHRtbCAudGFie1xyXG5cdGZvbnQtc2l6ZToyMnB4O1xyXG5cdG1hcmdpbi1yaWdodDoxNXB4O1xyXG5cdHBhZGRpbmctYm90dG9tOjVweDtcclxuXHRtYXJnaW46MCAxNXB4IDEwcHggMDtcclxuXHRkaXNwbGF5OmlubGluZS1ibG9jaztcclxuXHRib3JkZXItYm90dG9tOjJweCBzb2xpZCB0cmFuc3BhcmVudDtcclxufVxyXG4ubG9naW4taHRtbCAuc2lnbi1pbjpjaGVja2VkICsgLnRhYixcclxuLmxvZ2luLWh0bWwgLnNpZ24tdXA6Y2hlY2tlZCArIC50YWJ7XHJcblx0Y29sb3I6I2ZmZjtcclxuXHRib3JkZXItY29sb3I6IzExNjFlZTtcclxufVxyXG4ubG9naW4tZm9ybXtcclxuXHRtaW4taGVpZ2h0OjM0NXB4O1xyXG5cdHBvc2l0aW9uOnJlbGF0aXZlO1xyXG5cdHBlcnNwZWN0aXZlOjEwMDBweDtcclxuXHR0cmFuc2Zvcm0tc3R5bGU6cHJlc2VydmUtM2Q7XHJcbn1cclxuLmxvZ2luLWZvcm0gLmdyb3Vwe1xyXG5cdG1hcmdpbi1ib3R0b206MTVweDtcclxufVxyXG4ubG9naW4tZm9ybSAuZ3JvdXAgLmxhYmVsLFxyXG4ubG9naW4tZm9ybSAuZ3JvdXAgLmlucHV0LFxyXG4ubG9naW4tZm9ybSAuZ3JvdXAgLmJ1dHRvbntcclxuXHR3aWR0aDoxMDAlO1xyXG5cdGNvbG9yOnJnYig2MiwgNjgsIDY4KTtcclxuXHRkaXNwbGF5OmJsb2NrO1xyXG59XHJcbi5sb2dpbi1mb3JtIC5ncm91cCAuaW5wdXQsXHJcbi5sb2dpbi1mb3JtIC5ncm91cCAuYnV0dG9ue1xyXG5cdGJvcmRlcjpub25lO1xyXG5cdHBhZGRpbmc6MTVweCAyMHB4O1xyXG5cdGJvcmRlci1yYWRpdXM6MjVweDtcclxuXHRiYWNrZ3JvdW5kOnJnYmEoMjEzLCAyMjUsIDIyMywuOSk7XHJcbn1cclxuLmxvZ2luLWZvcm0gLmdyb3VwIGlucHV0W2RhdGEtdHlwZT1cInBhc3N3b3JkXCJde1xyXG5cdC13ZWJraXQtdGV4dC1zZWN1cml0eTpjaXJjbGU7XHJcbn1cclxuLmxvZ2luLWZvcm0gLmdyb3VwIC5sYWJlbHtcclxuXHRjb2xvcjojY2NmZjMzO1xyXG5cdGZvbnQtc2l6ZToxNHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgcGFkZGluZzogMTBweDtcclxufVxyXG5cclxuLmxvZ2luLWZvcm0gLmdyb3VwIC5sYWJlbC1lcnJvcntcclxuICBjb2xvcjojRkYwMDAwO1xyXG5cdGZvbnQtc2l6ZToxNHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbn1cclxuXHJcbi5sb2dpbi1mb3JtIC5ncm91cCAuYnV0dG9uLWFjdGl2ZXtcclxuXHRiYWNrZ3JvdW5kOiNjY2ZmMzM7XHJcbiAgZm9udC13ZWlnaHQ6IDcwMDtcclxufVxyXG4ubG9naW4tZm9ybSAuZ3JvdXAgLmJ1dHRvbi1kZWFjdGl2ZXtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDgsIDgwLCAxMjAsLjkpO1xyXG4gIGNvbG9yOiNCMEM0REU7XHJcbiAgZm9udC13ZWlnaHQ6IDcwMDtcclxufVxyXG5cclxuLmxvZ2luLWZvcm0gLmdyb3VwIGxhYmVsIC5pY29ue1xyXG5cdHdpZHRoOjE1cHg7XHJcblx0aGVpZ2h0OjE1cHg7XHJcblx0Ym9yZGVyLXJhZGl1czoycHg7XHJcblx0cG9zaXRpb246cmVsYXRpdmU7XHJcblx0ZGlzcGxheTppbmxpbmUtYmxvY2s7XHJcblx0YmFja2dyb3VuZDpyZ2JhKDI1NSwyNTUsMjU1LC4xKTtcclxufVxyXG4ubG9naW4tZm9ybSAuZ3JvdXAgbGFiZWwgLmljb246YmVmb3JlLFxyXG4ubG9naW4tZm9ybSAuZ3JvdXAgbGFiZWwgLmljb246YWZ0ZXJ7XHJcblx0Y29udGVudDonJztcclxuXHR3aWR0aDoxMHB4O1xyXG5cdGhlaWdodDoycHg7XHJcblx0YmFja2dyb3VuZDojZmZmO1xyXG5cdHBvc2l0aW9uOmFic29sdXRlO1xyXG5cdHRyYW5zaXRpb246YWxsIC4ycyBlYXNlLWluLW91dCAwcztcclxufVxyXG4ubG9naW4tZm9ybSAuZ3JvdXAgbGFiZWwgLmljb246YmVmb3Jle1xyXG5cdGxlZnQ6M3B4O1xyXG5cdHdpZHRoOjVweDtcclxuXHRib3R0b206NnB4O1xyXG5cdHRyYW5zZm9ybTpzY2FsZSgwKSByb3RhdGUoMCk7XHJcbn1cclxuLmxvZ2luLWZvcm0gLmdyb3VwIGxhYmVsIC5pY29uOmFmdGVye1xyXG5cdHRvcDo2cHg7XHJcblx0cmlnaHQ6MDtcclxuXHR0cmFuc2Zvcm06c2NhbGUoMCkgcm90YXRlKDApO1xyXG59XHJcbi5sb2dpbi1mb3JtIC5ncm91cCAuY2hlY2s6Y2hlY2tlZCArIGxhYmVse1xyXG5cdGNvbG9yOiNmZmY7XHJcbn1cclxuLmxvZ2luLWZvcm0gLmdyb3VwIC5jaGVjazpjaGVja2VkICsgbGFiZWwgLmljb257XHJcblx0YmFja2dyb3VuZDojMTE2MWVlO1xyXG59XHJcbi5sb2dpbi1mb3JtIC5ncm91cCAuY2hlY2s6Y2hlY2tlZCArIGxhYmVsIC5pY29uOmJlZm9yZXtcclxuXHR0cmFuc2Zvcm06c2NhbGUoMSkgcm90YXRlKDQ1ZGVnKTtcclxufVxyXG4ubG9naW4tZm9ybSAuZ3JvdXAgLmNoZWNrOmNoZWNrZWQgKyBsYWJlbCAuaWNvbjphZnRlcntcclxuXHR0cmFuc2Zvcm06c2NhbGUoMSkgcm90YXRlKC00NWRlZyk7XHJcbn1cclxuLmxvZ2luLWh0bWwgLnNpZ24taW46Y2hlY2tlZCArIC50YWIgKyAuc2lnbi11cCArIC50YWIgKyAubG9naW4tZm9ybSAuc2lnbi1pbi1odG17XHJcblx0dHJhbnNmb3JtOnJvdGF0ZSgwKTtcclxufVxyXG4ubG9naW4taHRtbCAuc2lnbi11cDpjaGVja2VkICsgLnRhYiArIC5sb2dpbi1mb3JtIC5zaWduLXVwLWh0bXtcclxuXHR0cmFuc2Zvcm06cm90YXRlKDApO1xyXG59XHJcblxyXG4uaHJ7XHJcblx0aGVpZ2h0OjJweDtcclxuXHRtYXJnaW46NjBweCAwIDUwcHggMDtcclxuXHRiYWNrZ3JvdW5kOnJnYmEoMjU1LDI1NSwyNTUsLjIpO1xyXG59XHJcbi5mb290LWxua3tcclxuXHR0ZXh0LWFsaWduOmNlbnRlcjtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "kV0F":
/*!***********************************!*\
  !*** ./src/app/auth/auth.page.ts ***!
  \***********************************/
/*! exports provided: AuthPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthPage", function() { return AuthPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_auth_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./auth.page.html */ "Buvn");
/* harmony import */ var _auth_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auth.page.scss */ "jMPm");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./auth.service */ "qXBG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");







let AuthPage = class AuthPage {
    constructor(authService, router, loadingCtrl, alertCtrl) {
        this.authService = authService;
        this.router = router;
        this.loadingCtrl = loadingCtrl;
        this.alertCtrl = alertCtrl;
        this.isLogin = true;
        this.isLoading = false;
    }
    ngOnInit() { }
    authenticate(email, password) {
        this.loadingCtrl.create({ keyboardClose: true }).then((loadingEl) => {
            loadingEl.present();
            let authObs;
            if (this.isLogin) {
                authObs = this.authService.login(email, password);
            }
            else {
                authObs = this.authService.signup(email, password);
            }
            authObs.subscribe((resData) => {
                this.isLoading = false;
                loadingEl.dismiss();
                this.router.navigateByUrl("/home");
            }, (errorRes) => {
                loadingEl.dismiss();
                const code = errorRes.message;
                let message = "Could not signup you up, please try again";
                if (code === "EMAIL_EXISTS") {
                    message = "This Email address exist already.";
                }
                else if (code === "EMAIL_NOT_FOUND") {
                    message = "Email addresscould not be found.";
                }
                else if (code === "INVALID_PASSWORD") {
                    message = "Password is not valid.";
                }
                else if (code === "USER_DISABLED") {
                    message = "User has been disabled. Kindly contact administrator.";
                }
                this.showAlert(message);
            });
        });
        this.isLoading = true;
    }
    onSubmit(form) {
        if (!form.valid)
            return;
        const email = form.value.email;
        const password = form.value.password;
        this.authenticate(email, password);
        form.reset();
    }
    onSwithAuthMode() {
        this.isLogin = !this.isLogin;
    }
    showAlert(msg) {
        this.alertCtrl
            .create({
            header: "Authentication failed",
            message: msg,
            buttons: ["Okay"],
        })
            .then((alertEl) => {
            alertEl.present();
        });
    }
};
AuthPage.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] }
];
AuthPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-auth",
        template: _raw_loader_auth_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_auth_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AuthPage);



/***/ })

}]);
//# sourceMappingURL=auth-auth-module.js.map