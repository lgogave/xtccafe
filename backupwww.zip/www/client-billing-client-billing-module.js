(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["client-billing-client-billing-module"],{

/***/ "2fvU":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/salespipeline/client-billing/client-billing.page.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref=\"/salespipeline\">\n      </ion-back-button>\n      <ion-title>Billing Rates</ion-title>\n      <ion-button (click)=\"addBillingDetail()\" [disabled]=\"!isLoading && !form.valid\">\n        <ion-icon name=\"checkmark\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n<form [formGroup]=\"form\"  *ngIf=\"!isLoading\">\n<ion-grid>\n<ion-row>\n    <ion-col>\n      <ion-item>\n        <ion-label position=\"floating\" >Billing Name <span style=\"color: #FF6347;\">*</span></ion-label>\n        <ion-input type=\"text\" formControlName=\"billName\"></ion-input>\n      </ion-item>\n  </ion-col>\n</ion-row>\n<ion-row>\n  <ion-col>\n    <ion-item class=\"item-readonly\">\n      <ion-label position=\"floating\" >Billing Address <span style=\"color: #FF6347;\">*</span></ion-label>\n      <ion-textarea  Readonly rows=\"3\" formControlName=\"billAddress\"></ion-textarea>\n    </ion-item>\n</ion-col>\n</ion-row>\n<ion-row>\n  <ion-col>\n    <ion-item class=\"item-readonly\">\n      <ion-label position=\"floating\" >Client Location<span style=\"color: #FF6347;\">*</span></ion-label>\n      <ion-input   Readonly type=\"text\" formControlName=\"location\"></ion-input>\n    </ion-item>\n</ion-col>\n</ion-row>\n<ion-row>\n  <ion-col>\n    <ion-item>\n      <ion-label position=\"floating\" >Pincode<span style=\"color: #FF6347;\">*</span></ion-label>\n      <ion-input type=\"number\" formControlName=\"pincode\"></ion-input>\n    </ion-item>\n</ion-col>\n</ion-row>\n\n\n\n<ion-row>\n  <ion-col>\n    <ion-item class=\"item-readonly\">\n      <ion-label position=\"floating\" >Installation At (Client Name)<span style=\"color: #FF6347;\">*</span></ion-label>\n      <ion-input  Readonly type=\"text\" formControlName=\"installAt\" ></ion-input>\n    </ion-item>\n</ion-col>\n</ion-row>\n\n<ion-row>\n  <ion-col>\n    <ion-item class=\"item-readonly\">\n      <ion-label position=\"floating\" >Installation Address<span style=\"color: #FF6347;\">*</span></ion-label>\n      <ion-textarea   Readonly  rows=\"3\" formControlName=\"installAddress\"></ion-textarea>\n    </ion-item>\n</ion-col>\n</ion-row>\n<ion-row>\n  <ion-col>\n    <ion-item>\n      <ion-label position=\"floating\" >GST No.<span style=\"color: #FF6347;\">*</span></ion-label>\n      <ion-input type=\"text\" formControlName=\"gstno\"></ion-input>\n    </ion-item>\n</ion-col>\n</ion-row>\n\n<ion-row>\n  <ion-col size-sm=\"6\" offset-sm=\"3\">\n    <ion-item>\n      <ion-label position=\"floating\" class=\"label\"> Billing From Branch\n      </ion-label>\n      <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"branch\">\n        <ion-select-option *ngFor=\"let branch of branches\" [value]=\"branch.name\">{{branch.name}}\n        </ion-select-option>\n      </ion-select>\n    </ion-item>\n  </ion-col>\n</ion-row>\n\n<ion-row>\n  <ion-col size=\"12\">\n    <ion-item>\n      <ion-label position=\"floating\" class=\"label\">Tax Type\n      </ion-label>\n      <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"taxType\">\n        <ion-select-option [value]=\"CGSTSGST\">CGST/SGST</ion-select-option>\n          <ion-select-option [value]=\"IGST\">IGST\n        </ion-select-option>\n        </ion-select>\n    </ion-item>\n  </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\n      <ion-item>\n        <ion-label position=\"floating\" class=\"label\">Bank\n        </ion-label>\n        <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"bank\">\n          <ion-select-option *ngFor=\"let bank of banks\" [value]=\"bank.name\">{{bank.name}}\n          </ion-select-option>\n        </ion-select>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n\n\n\n\n<div class=\"section\">\n  <ion-row>\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\n      <span style=\"font-size:13px\">Details of Material</span>\n    </ion-col>\n  </ion-row>\n  <div *ngFor=\"let item of form.get('materialDetails')['controls']; let i = index;\"\n    formArrayName=\"materialDetails\">\n    <div [formGroupName]=\"i\">\n      <ion-row>\n        <ion-col size=\"10\">\n          <ion-row>\n            <ion-col size=\"12\">\n              <ion-item>\n                <ion-label position=\"floating\" class=\"label\">Material\n                </ion-label>\n                <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"category\" (ionChange)=\"onMaterialChange($event,form.get('materialDetails')['controls'][i],i)\">\n                  <ion-select-option *ngFor=\"let stock of stockCategory\" [value]=\"stock\">{{stock}}\n                  </ion-select-option>\n                  </ion-select>\n              </ion-item>\n            </ion-col>\n            <ion-col  size=\"12\">\n              <ion-item>\n                <ion-label position=\"floating\" class=\"label\">Type\n                </ion-label>\n                <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"item\" (ionChange)=\"onMaterialTypeChange($event,form.get('materialDetails')['controls'][i])\">\n                  <ion-select-option *ngFor=\"let stock of this.materialstockType[i].stockType\" [value]=\"stock\">{{stock}}\n                  </ion-select-option>\n                  </ion-select>\n              </ion-item>\n            </ion-col>\n            <ion-col size=\"12\">\n              <ion-item color=\"success\">\n                <ion-label position=\"floating\" class=\"label\"  style=\"color: #fff;\">UOM\n                </ion-label>\n                <ion-input type=\"text\" autocomplete autocorrect formControlName=\"uom\" readonly></ion-input>\n              </ion-item>\n            </ion-col>\n            <ion-col size=\"12\">\n              <ion-item  color=\"success\">\n                <ion-label position=\"floating\" class=\"label\"  style=\"color: #fff;\">HSNCode\n                </ion-label>\n                <ion-input type=\"text\" autocomplete autocorrect formControlName=\"hsnNo\" readonly></ion-input>\n              </ion-item>\n            </ion-col>\n            <ion-col size=\"12\">\n              <ion-item  color=\"success\">\n                <ion-label position=\"floating\" class=\"label\" style=\"color: #fff;\">GST\n                </ion-label>\n                <ion-input type=\"text\" autocomplete autocorrect formControlName=\"gst\"\n                [value]=\"item.get('gst').value\"\n                readonly></ion-input>\n              </ion-item>\n            </ion-col>\n            <ion-col  size=\"12\">\n              <ion-item>\n                <ion-label position=\"floating\" class=\"label\">Price\n                </ion-label>\n                <ion-input type=\"number\" autocomplete autocorrect formControlName=\"price\"></ion-input>\n              </ion-item>\n            </ion-col>\n          </ion-row>\n        </ion-col>\n        <ion-col size=\"2\">\n          <div style=\"height: 95%; border-left:2px solid #FF69B4;\">\n            <ion-button size=\"small\" class=\" button-assertive button-clear\" style=\"margin-top: 75px;\"\n              (click)=\"deleteMaterial(i)\">\n              <ion-icon name=\"trash\" slot=\"icon-only\"></ion-icon>\n            </ion-button>\n          </div>\n        </ion-col>\n      </ion-row>\n    </div>\n  </div>\n  <ion-row>\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\n      <ion-button size=\"small\" (click)=\"addMaterial()\">\n        <ion-icon name=\"add-circle\"></ion-icon> Add Material\n      </ion-button>\n    </ion-col>\n  </ion-row>\n</div>\n\n\n\n\n\n</ion-grid>\n</form>\n</ion-content>\n");

/***/ }),

/***/ "8/XM":
/*!*********************************************************************!*\
  !*** ./src/app/salespipeline/client-billing/client-billing.page.ts ***!
  \*********************************************************************/
/*! exports provided: ClientBillingPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientBillingPage", function() { return ClientBillingPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_client_billing_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./client-billing.page.html */ "2fvU");
/* harmony import */ var _client_billing_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./client-billing.page.scss */ "XOv7");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_services_division_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/division.service */ "KWQH");
/* harmony import */ var _salespipeline_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../salespipeline.service */ "bL0d");










let ClientBillingPage = class ClientBillingPage {
    constructor(route, navCtrl, divisionService, loadingCtrl, router, salespiplineService, toastController) {
        this.route = route;
        this.navCtrl = navCtrl;
        this.divisionService = divisionService;
        this.loadingCtrl = loadingCtrl;
        this.router = router;
        this.salespiplineService = salespiplineService;
        this.toastController = toastController;
        this.isLoading = true;
        this.materialstockType = [];
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.route.paramMap.subscribe((paramMap) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                if (!paramMap.has('salesId')) {
                    this.navCtrl.navigateBack('/salespipeline');
                }
                if (!paramMap.has('locId')) {
                    this.navCtrl.navigateBack('/salespipeline');
                }
                this.saleId = paramMap.get('salesId');
                this.locationId = paramMap.get('locId');
                this.perPipe = new _angular_common__WEBPACK_IMPORTED_MODULE_3__["PercentPipe"]('en-US');
                this.billingDetail = yield this.salespiplineService.getBillingDetail(this.saleId, this.locationId);
                yield this.loadStockDetails();
                yield this.loadBankDetails();
                yield this.loadBranches();
                this.loadingCtrl.create({ keyboardClose: true }).then((loadingEl) => {
                    loadingEl.present();
                    this.salespiplineService
                        .getSalesPipelineById(this.saleId)
                        .subscribe((res) => {
                        this.clientSales = res;
                        this.clientSales.clientsale.locations.forEach(location => {
                            if (location.id == this.locationId) {
                                this.clientLocation = location;
                            }
                        });
                        var result = this.initializeForm();
                        loadingEl.dismiss();
                        this.isLoading = false;
                    });
                });
            }));
        });
    }
    initializeForm() {
        this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            billName: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.billingDetail != null ? this.billingDetail.billName : this.clientSales.client.name, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            billAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.clientLocation.address, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            location: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.clientLocation.city, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            installAt: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.clientLocation.installAt, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            installAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.clientLocation.installAddress, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            gstno: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.billingDetail != null ? this.billingDetail.gstno : this.clientSales.client.gstNumber, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            taxType: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.billingDetail != null ? this.billingDetail.taxType : null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            materialDetails: this.billingDetail != null ? this.buildMaterialDetail(this.billingDetail) : new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormArray"]([this.createMaterialDetail()]),
            pincode: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.billingDetail != null ? this.billingDetail.pincode : null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            bank: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.billingDetail != null ? this.billingDetail.bank.name : null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            branch: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.billingDetail != null ? this.billingDetail.branch : null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
        });
        return true;
    }
    buildMaterialDetail(billDetail) {
        let fmarray = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormArray"]([]);
        billDetail.materialDetails.forEach((material, index) => {
            fmarray.push(this.createMaterialDetail(material));
            let ref = this.stockDetail.filter(item => item.category == material.category)[0].category;
            this.materialstockType[index].stockType = this.stockDetail.filter(item => item.category == ref).map(item => item.item).sort();
        });
        return fmarray;
    }
    createMaterialDetail(materialRate) {
        this.materialstockType.push({ stockType: [] });
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            category: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](materialRate != null ? materialRate.category : null, {
                updateOn: "blur",
            }),
            item: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](materialRate != null ? materialRate.item : null, {
                updateOn: "blur",
            }),
            uom: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](materialRate != null ? materialRate.uom : null, {
                updateOn: "blur",
            }),
            hsnNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](materialRate != null ? materialRate.hsnNo : null, {
                updateOn: "blur",
            }),
            gst: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](materialRate != null ? materialRate.gst : null, {
                updateOn: "blur",
            }),
            price: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](materialRate != null ? materialRate.price : null, {
                updateOn: "blur",
            }),
        });
    }
    loadStockDetails() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.stockDetail = yield this.divisionService.getStock();
            this.stockCategory = this.stockDetail.map(item => item.category).filter((value, index, self) => self.indexOf(value) === index).sort();
            return true;
        });
    }
    loadBankDetails() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.banks = yield this.divisionService.getBanks();
            this.banknames = this.banks.map(item => item.name).filter((value, index, self) => self.indexOf(value) === index).sort();
            return true;
        });
    }
    loadBranches() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.branches = yield this.divisionService.getBranches();
            return true;
        });
    }
    addMaterial() {
        let matdetails = this.form.get('materialDetails');
        matdetails.push(this.createMaterialDetail());
    }
    deleteMaterial(index) {
        let matdetails = this.form.get('materialDetails');
        matdetails.removeAt(index);
        this.materialstockType.splice(index, 1);
    }
    onMaterialChange(event, element, index) {
        if (!event.target.value)
            return;
        let ref = this.stockDetail.filter(item => item.category == event.target.value)[0].category;
        element.controls['item'].reset();
        element.controls['uom'].patchValue(null, { emitEvent: false });
        element.controls['hsnNo'].patchValue(null, { emitEvent: false });
        element.controls['gst'].patchValue(null, { emitEvent: false });
        this.materialstockType[index].stockType = this.stockDetail.filter(item => item.category == ref).map(item => item.item).sort();
    }
    onMaterialTypeChange(event, element) {
        if (!event.target.value)
            return;
        let ref = this.stockDetail.filter(item => item.item == event.target.value)[0];
        element.controls['uom'].patchValue(ref.uom, { emitEvent: false });
        element.controls['hsnNo'].patchValue(ref.hsnNo, { emitEvent: false });
        element.controls['gst'].patchValue(this.perPipe.transform(ref.gst), { emitEvent: false });
    }
    addBillingDetail() {
        if (!this.form.valid) {
            return;
        }
        let fmbillingDetail = this.form.value;
        fmbillingDetail.salesId = this.saleId;
        fmbillingDetail.clientId = this.clientSales.clientsale.clientId;
        fmbillingDetail.locationId = this.locationId;
        fmbillingDetail.bank = this.banks.filter(x => x.name == fmbillingDetail.bank)[0];
        // let nbranchs=this.branches.filter(x=>x.name==fmbillingDetail.branch);
        // let branch='';
        // if(nbranchs.length>0){
        //   branch=nbranchs[0].name;
        // }
        if (this.billingDetail != null) {
            fmbillingDetail.id = this.billingDetail.id;
        }
        if (fmbillingDetail.materialDetails.length == 0) {
            return;
        }
        //delete Empty elements
        let delData = fmbillingDetail.materialDetails.filter(item => item.item === null);
        delData.forEach(element => {
            const index = fmbillingDetail.materialDetails.indexOf(element);
            if (index !== -1) {
                fmbillingDetail.materialDetails.splice(index, 1);
            }
        });
        this.salespiplineService
            .addupdateBillingDetail(fmbillingDetail, this.billingDetail != null ? true : false)
            .subscribe((res) => {
            this.toastController
                .create({
                message: 'Data updated',
                duration: 2000,
                color: 'success',
            })
                .then((tost) => {
                tost.present();
                this.router.navigate(['/salespipeline']);
            });
        });
    }
};
ClientBillingPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavController"] },
    { type: src_app_services_division_service__WEBPACK_IMPORTED_MODULE_8__["DivisionService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["LoadingController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _salespipeline_service__WEBPACK_IMPORTED_MODULE_9__["SalespipelineService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"] }
];
ClientBillingPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-client-billing',
        template: _raw_loader_client_billing_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_client_billing_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ClientBillingPage);



/***/ }),

/***/ "QCKg":
/*!*******************************************************************************!*\
  !*** ./src/app/salespipeline/client-billing/client-billing-routing.module.ts ***!
  \*******************************************************************************/
/*! exports provided: ClientBillingPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientBillingPageRoutingModule", function() { return ClientBillingPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _client_billing_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./client-billing.page */ "8/XM");




const routes = [
    {
        path: '',
        component: _client_billing_page__WEBPACK_IMPORTED_MODULE_3__["ClientBillingPage"]
    }
];
let ClientBillingPageRoutingModule = class ClientBillingPageRoutingModule {
};
ClientBillingPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ClientBillingPageRoutingModule);



/***/ }),

/***/ "XOv7":
/*!***********************************************************************!*\
  !*** ./src/app/salespipeline/client-billing/client-billing.page.scss ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".item-readonly {\n  --ion-item-background:#D0D0D0;\n  --ion-item-color:#000;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjbGllbnQtYmlsbGluZy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSw2QkFBQTtFQUNBLHFCQUFBO0FBQ0YiLCJmaWxlIjoiY2xpZW50LWJpbGxpbmcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLml0ZW0tcmVhZG9ubHkge1xyXG4gIC0taW9uLWl0ZW0tYmFja2dyb3VuZDojRDBEMEQwO1xyXG4gIC0taW9uLWl0ZW0tY29sb3I6IzAwMDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "wXGh":
/*!***********************************************************************!*\
  !*** ./src/app/salespipeline/client-billing/client-billing.module.ts ***!
  \***********************************************************************/
/*! exports provided: ClientBillingPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientBillingPageModule", function() { return ClientBillingPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _client_billing_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./client-billing-routing.module */ "QCKg");
/* harmony import */ var _client_billing_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./client-billing.page */ "8/XM");







let ClientBillingPageModule = class ClientBillingPageModule {
};
ClientBillingPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _client_billing_routing_module__WEBPACK_IMPORTED_MODULE_5__["ClientBillingPageRoutingModule"]
        ],
        declarations: [_client_billing_page__WEBPACK_IMPORTED_MODULE_6__["ClientBillingPage"]]
    })
], ClientBillingPageModule);



/***/ })

}]);
//# sourceMappingURL=client-billing-client-billing-module.js.map