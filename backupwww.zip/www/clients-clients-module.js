(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["clients-clients-module"],{

/***/ "9bfK":
/*!*****************************************!*\
  !*** ./src/app/clients/clients.page.ts ***!
  \*****************************************/
/*! exports provided: ClientsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientsPage", function() { return ClientsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_clients_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./clients.page.html */ "NXgi");
/* harmony import */ var _clients_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./clients.page.scss */ "NfJl");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _client_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./client.service */ "+RYs");






let ClientsPage = class ClientsPage {
    constructor(clientService, loadingCtrl, alertCtrl) {
        this.clientService = clientService;
        this.loadingCtrl = loadingCtrl;
        this.alertCtrl = alertCtrl;
        this.isLoading = false;
    }
    ngOnInit() {
        //   this.clientService.getLocations().subscribe(location=>{
        // console.log(location);
        //  });
        this.clientSub = this.clientService.clients.subscribe((clients) => {
            this.loadedClients = clients;
            this.applyFilter('');
        });
    }
    ionViewWillEnter() {
        this.isLoading = true;
        this.clientSub2 = this.clientService.fetchClients().subscribe(() => {
            this.isLoading = false;
        });
    }
    doRefresh(event) {
        this.clientSub1 = this.clientService.fetchClients().subscribe(() => {
            event.target.complete();
        });
    }
    search(event) {
        const searchTerm = event.srcElement.value;
        this.applyFilter(searchTerm);
    }
    applyFilter(searchTerm) {
        searchTerm = this.searchElement == undefined ? '' : this.searchElement.value;
        if (!searchTerm) {
            this.filterloadedClients = this.loadedClients;
            return;
        }
        this.filterloadedClients = this.loadedClients.filter(client => {
            var _a;
            if (client.name && searchTerm) {
                return (client.name.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1 || ((_a = client.group) === null || _a === void 0 ? void 0 : _a.toLowerCase().indexOf(searchTerm.toLowerCase())) > -1);
            }
        });
    }
    ngOnDestroy() {
        if (this.clientSub) {
            this.clientSub.unsubscribe();
        }
        if (this.clientSub1) {
            this.clientSub1.unsubscribe();
        }
        if (this.clientSub2) {
            this.clientSub2.unsubscribe();
        }
    }
    onDeleteClient(clientName, clientId, slidingEl) {
        this.alertCtrl
            .create({
            header: 'Delete!',
            message: '<strong>Are you sure you want to delete the ' +
                clientName +
                '?</strong>',
            buttons: [
                {
                    text: 'Cancel',
                    role: 'cancel',
                    handler: () => {
                        slidingEl.close();
                    },
                },
                {
                    text: 'Okay',
                    handler: () => {
                        slidingEl.close();
                        this.loadingCtrl
                            .create({ keyboardClose: true, message: 'Deleteing...' })
                            .then((loadingEl) => {
                            loadingEl.present();
                            this.clientService.deleteClient(clientId).subscribe(() => {
                                loadingEl.dismiss();
                            });
                        });
                    },
                },
            ],
        })
            .then((alertEl) => {
            alertEl.present();
        });
    }
};
ClientsPage.ctorParameters = () => [
    { type: _client_service__WEBPACK_IMPORTED_MODULE_5__["ClientService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] }
];
ClientsPage.propDecorators = {
    searchElement: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['searchElement',] }]
};
ClientsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-clients',
        template: _raw_loader_clients_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_clients_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ClientsPage);



/***/ }),

/***/ "9iw0":
/*!*******************************************!*\
  !*** ./src/app/clients/clients.module.ts ***!
  \*******************************************/
/*! exports provided: ClientsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientsPageModule", function() { return ClientsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _clients_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./clients-routing.module */ "f2Yv");
/* harmony import */ var _clients_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./clients.page */ "9bfK");







let ClientsPageModule = class ClientsPageModule {
};
ClientsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _clients_routing_module__WEBPACK_IMPORTED_MODULE_5__["ClientsPageRoutingModule"]
        ],
        declarations: [_clients_page__WEBPACK_IMPORTED_MODULE_6__["ClientsPage"]]
    })
], ClientsPageModule);



/***/ }),

/***/ "NXgi":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/clients/clients.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-button>\n        <ion-menu-button slot=\"start\"></ion-menu-button>\n\n      </ion-button>\n      <ion-icon name=\"people\" slot=\"end\"></ion-icon>\n      <ion-title>Clients</ion-title>\n      <ion-buttons slot=\"primary\">\n        <ion-button [routerLink]=\"['/','clients','new']\">\n          <ion-icon name=\"add\" slot=\"icon-only\"></ion-icon>\n        </ion-button>\n      </ion-buttons>\n    </ion-buttons>\n    <ion-searchbar placeholder=\"Filter Clients\" (ionInput)=\"search($event)\" #searchElement></ion-searchbar>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n<ion-grid>\n  <ion-row>\n    <ion-col>\n      <div *ngIf=\"isLoading\" class=\"ion-text-center\">\n        <ion-spinner color=\"primary\" ></ion-spinner>\n      </div>\n      <div *ngIf=\"!isLoading && filterloadedClients.length<=0\" class=\"ion-text-center\">\n        <p>No Clients found! please create one first!</p>\n        <ion-button color=\"primary\" routerLink=\"/clients/new\">Add Client</ion-button>\n      </div>\n\n      <ion-list *ngIf=\"!isLoading && filterloadedClients.length>0\">\n        <ion-item-sliding *ngFor=\"let client of filterloadedClients\" #slidingClients>\n        <ion-item detail  [routerLink]=\"['/','clients','detail',client.id]\" >\n          <ion-icon name=\"person\" slot=\"start\"></ion-icon>\n         <div>\n           <h5>{{client.name}}</h5>\n           <h6><ion-icon name=\"call\" slot=\"start\"></ion-icon> {{client.contactNumber}}</h6>\n         </div>\n        </ion-item>\n        <ion-item-options>\n          <ion-item-option color=\"secondary\">\n            <ion-icon name=\"create\" slot=\"icon-only\"  [routerLink]=\"['/','clients','edit',client.id]\"></ion-icon>\n          </ion-item-option>\n          <ion-item-option color=\"danger\"  (click)=\"onDeleteClient(client.name,client.id,slidingClients)\">\n            <ion-icon name=\"trash\" slot=\"icon-only\"></ion-icon>\n          </ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n      </ion-list>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n\n</ion-content>\n");

/***/ }),

/***/ "NfJl":
/*!*******************************************!*\
  !*** ./src/app/clients/clients.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjbGllbnRzLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "f2Yv":
/*!***************************************************!*\
  !*** ./src/app/clients/clients-routing.module.ts ***!
  \***************************************************/
/*! exports provided: ClientsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientsPageRoutingModule", function() { return ClientsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _clients_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./clients.page */ "9bfK");




const routes = [
    {
        path: '',
        component: _clients_page__WEBPACK_IMPORTED_MODULE_3__["ClientsPage"]
    },
    {
        path: 'new',
        loadChildren: () => Promise.all(/*! import() | add-client-add-client-module */[__webpack_require__.e("common"), __webpack_require__.e("add-client-add-client-module")]).then(__webpack_require__.bind(null, /*! ./add-client/add-client.module */ "U+ep")).then(m => m.AddClientPageModule)
    },
    {
        path: 'edit/:clientId',
        loadChildren: () => Promise.all(/*! import() | edit-client-edit-client-module */[__webpack_require__.e("common"), __webpack_require__.e("edit-client-edit-client-module")]).then(__webpack_require__.bind(null, /*! ./edit-client/edit-client.module */ "JCj0")).then(m => m.EditClientPageModule)
    },
    {
        path: 'detail/:clientId',
        loadChildren: () => __webpack_require__.e(/*! import() | detail-client-detail-client-module */ "detail-client-detail-client-module").then(__webpack_require__.bind(null, /*! ./detail-client/detail-client.module */ "eZdo")).then(m => m.DetailClientPageModule)
    }
];
let ClientsPageRoutingModule = class ClientsPageRoutingModule {
};
ClientsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ClientsPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=clients-clients-module.js.map