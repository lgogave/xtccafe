(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["comments-sales-comments-sales-module"],{

/***/ "1H6N":
/*!***********************************************************************!*\
  !*** ./src/app/salespipeline/comments-sales/comments-sales.page.scss ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".list-group {\n  padding-left: 0;\n  margin: 0px;\n  width: 100%;\n}\n\n.list-group-item:first-child {\n  border-top-left-radius: 4px;\n  border-top-right-radius: 4px;\n}\n\nspan.list-group-item {\n  color: #555;\n}\n\n.list-group-item {\n  position: relative;\n  display: block;\n  padding: 10px 15px;\n  margin-bottom: -1px;\n  background-color: #fff;\n}\n\n#contact_ul {\n  list-style: none;\n  -webkit-padding-start: 0px;\n}\n\n#li_phone ion-icon {\n  font-size: 1em;\n  vertical-align: middle;\n  margin-right: 10px;\n  padding-top: 9px;\n}\n\n#li_email ion-icon {\n  font-size: 1em;\n  vertical-align: middle;\n  margin-right: 10px;\n  padding-top: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb21tZW50cy1zYWxlcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7QUFDRjs7QUFHQTtFQUNJLDJCQUFBO0VBQ0EsNEJBQUE7QUFBSjs7QUFHQTtFQUNJLFdBQUE7QUFBSjs7QUFHQTtFQUNFLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtBQUFGOztBQUdBO0VBQ0UsZ0JBQUE7RUFDQSwwQkFBQTtBQUFGOztBQUdFO0VBQ0EsY0FBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQUFGOztBQUVFO0VBQ0EsY0FBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQUNGIiwiZmlsZSI6ImNvbW1lbnRzLXNhbGVzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5saXN0LWdyb3VwIHtcclxuICBwYWRkaW5nLWxlZnQ6IDA7XHJcbiAgbWFyZ2luOiAwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgLy8gbWFyZ2luLWJvdHRvbTogMjBweDtcclxufVxyXG5cclxuLmxpc3QtZ3JvdXAtaXRlbTpmaXJzdC1jaGlsZCB7XHJcbiAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA0cHg7XHJcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogNHB4O1xyXG59XHJcblxyXG5zcGFuLmxpc3QtZ3JvdXAtaXRlbSB7XHJcbiAgICBjb2xvcjogIzU1NTtcclxufVxyXG5cclxuLmxpc3QtZ3JvdXAtaXRlbSB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIHBhZGRpbmc6IDEwcHggMTVweDtcclxuICBtYXJnaW4tYm90dG9tOiAtMXB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcblxyXG59XHJcbiNjb250YWN0X3Vse1xyXG4gIGxpc3Qtc3R5bGU6IG5vbmU7XHJcbiAgLXdlYmtpdC1wYWRkaW5nLXN0YXJ0OiAwcHg7XHJcbiAgfVxyXG5cclxuICAjbGlfcGhvbmUgaW9uLWljb257XHJcbiAgZm9udC1zaXplOiAxLjBlbTtcclxuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG4gIG1hcmdpbi1yaWdodDogMTBweDtcclxuICBwYWRkaW5nLXRvcDogOXB4O1xyXG4gIH1cclxuICAjbGlfZW1haWwgaW9uLWljb257XHJcbiAgZm9udC1zaXplOiAxLjBlbTtcclxuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG4gIG1hcmdpbi1yaWdodDogMTBweDtcclxuICBwYWRkaW5nLXRvcDogMXB4O1xyXG4gIH1cclxuIl19 */");

/***/ }),

/***/ "f0ej":
/*!***********************************************************************!*\
  !*** ./src/app/salespipeline/comments-sales/comments-sales.module.ts ***!
  \***********************************************************************/
/*! exports provided: CommentsSalesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommentsSalesPageModule", function() { return CommentsSalesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _comments_sales_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./comments-sales-routing.module */ "v3IT");
/* harmony import */ var _comments_sales_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./comments-sales.page */ "xR6O");







let CommentsSalesPageModule = class CommentsSalesPageModule {
};
CommentsSalesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _comments_sales_routing_module__WEBPACK_IMPORTED_MODULE_5__["CommentsSalesPageRoutingModule"]
        ],
        declarations: [_comments_sales_page__WEBPACK_IMPORTED_MODULE_6__["CommentsSalesPage"]]
    })
], CommentsSalesPageModule);



/***/ }),

/***/ "fz6I":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/salespipeline/comments-sales/comments-sales.page.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref=\"/salespipeline\">\n      </ion-back-button>\n      <ion-title>{{isLoading?'Loading...':client}}</ion-title>\n\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <div *ngIf=\"!isLoading && comments.length<=0\" class=\"ion-text-center\">\n    <p>Comments are not found!</p>\n  </div>\n\n<div *ngIf=\"isLoading\" class=\"ion-text-center\">\n<ion-spinner color=\"primary\"></ion-spinner>\n  </div>\n  <ion-grid class=\"ion-no-padding\" *ngIf=\"!isLoading\">\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n<ion-item  *ngFor=\"let client of comments\">\n  <div class=\"list-group\">\n    <!-- <span class=\"list-group-item\">\n      <ion-icon name=\"person-circle-outline\" size=\"large\"></ion-icon> Admin</span> -->\n      <ul id=\"contact_ul\">\n         <li id=\"li_email\"><ion-icon name=\"person-circle\" size=\"large\" color=\"success\"></ion-icon><a>{{client.user.name}}</a></li>\n        </ul>\n      <h6 style=\"padding-left: 35px;margin: 0px;\">{{client.comment}}</h6>\n      <h6 style=\"text-align: right;font-size: 14px;\">\n        <ul id=\"contact_ul\">\n          <li id=\"li_email\"><ion-icon name=\"time-outline\" size=\"small\" style=\"color: #787878;\"></ion-icon><a style=\"color: #787878\"> {{convertTimestampToDate(client.undatedOn) | date:'medium'}}</a></li>\n         </ul>\n       </h6>\n</div>\n</ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n</ion-content>\n");

/***/ }),

/***/ "v3IT":
/*!*******************************************************************************!*\
  !*** ./src/app/salespipeline/comments-sales/comments-sales-routing.module.ts ***!
  \*******************************************************************************/
/*! exports provided: CommentsSalesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommentsSalesPageRoutingModule", function() { return CommentsSalesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _comments_sales_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./comments-sales.page */ "xR6O");




const routes = [
    {
        path: '',
        component: _comments_sales_page__WEBPACK_IMPORTED_MODULE_3__["CommentsSalesPage"]
    }
];
let CommentsSalesPageRoutingModule = class CommentsSalesPageRoutingModule {
};
CommentsSalesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CommentsSalesPageRoutingModule);



/***/ }),

/***/ "xR6O":
/*!*********************************************************************!*\
  !*** ./src/app/salespipeline/comments-sales/comments-sales.page.ts ***!
  \*********************************************************************/
/*! exports provided: CommentsSalesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommentsSalesPage", function() { return CommentsSalesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_comments_sales_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./comments-sales.page.html */ "fz6I");
/* harmony import */ var _comments_sales_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./comments-sales.page.scss */ "1H6N");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var _salespipeline_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../salespipeline.service */ "bL0d");








let CommentsSalesPage = class CommentsSalesPage {
    constructor(router, navCtrl, modelCtrl, salespipelineService, route, actionSheetCtrl, loadingCtrl, alertCtrl, authService) {
        this.router = router;
        this.navCtrl = navCtrl;
        this.modelCtrl = modelCtrl;
        this.salespipelineService = salespipelineService;
        this.route = route;
        this.actionSheetCtrl = actionSheetCtrl;
        this.loadingCtrl = loadingCtrl;
        this.alertCtrl = alertCtrl;
        this.authService = authService;
        this.isLoading = false;
    }
    ngOnInit() {
        this.route.paramMap.subscribe((paramMap) => {
            if (!paramMap.has('salesId')) {
                this.navCtrl.navigateBack('/salespipeline');
                return;
            }
            this.salesId = paramMap.get('salesId');
            this.client = paramMap.get('client');
            console.log(this.client);
            this.commentsSub = this.salespipelineService.clientComments.subscribe((comments) => {
                this.comments = comments;
            });
        }, (error) => {
            this.alertCtrl
                .create({
                header: 'An error occured',
                message: 'Salespipeline could not be load. Please try that later.',
                buttons: [
                    {
                        text: 'Okay',
                        handler: () => {
                            this.router.navigate(['/salespipeline']);
                        },
                    },
                ],
            })
                .then((alerEl) => {
                alerEl.present();
            });
        });
    }
    ionViewWillEnter() {
        this.isLoading = true;
        this.salespipelineService.fetchClientCommets(this.salesId).subscribe((respones) => {
            console.log(respones);
            this.isLoading = false;
        });
    }
    ngOnDestroy() {
        if (this.commentsSub) {
            this.commentsSub.unsubscribe();
        }
    }
    convertTimestampToDate(date) {
        return this.salespipelineService.convertTimeStampToDate(date);
    }
};
CommentsSalesPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _salespipeline_service__WEBPACK_IMPORTED_MODULE_7__["SalespipelineService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ActionSheetController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"] }
];
CommentsSalesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-comments-sales',
        template: _raw_loader_comments_sales_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_comments_sales_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CommentsSalesPage);



/***/ })

}]);
//# sourceMappingURL=comments-sales-comments-sales-module.js.map