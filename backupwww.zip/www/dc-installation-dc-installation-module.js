(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["dc-installation-dc-installation-module"],{

/***/ "AczF":
/*!*************************************************************************!*\
  !*** ./src/app/salespipeline/dc-installation/dc-installation.module.ts ***!
  \*************************************************************************/
/*! exports provided: DcInstallationPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DcInstallationPageModule", function() { return DcInstallationPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _dc_installation_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./dc-installation-routing.module */ "FplX");
/* harmony import */ var _dc_installation_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dc-installation.page */ "sqtI");







let DcInstallationPageModule = class DcInstallationPageModule {
};
DcInstallationPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _dc_installation_routing_module__WEBPACK_IMPORTED_MODULE_5__["DcInstallationPageRoutingModule"]
        ],
        declarations: [_dc_installation_page__WEBPACK_IMPORTED_MODULE_6__["DcInstallationPage"]]
    })
], DcInstallationPageModule);



/***/ }),

/***/ "FplX":
/*!*********************************************************************************!*\
  !*** ./src/app/salespipeline/dc-installation/dc-installation-routing.module.ts ***!
  \*********************************************************************************/
/*! exports provided: DcInstallationPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DcInstallationPageRoutingModule", function() { return DcInstallationPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _dc_installation_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./dc-installation.page */ "sqtI");




const routes = [
    {
        path: '',
        component: _dc_installation_page__WEBPACK_IMPORTED_MODULE_3__["DcInstallationPage"]
    }
];
let DcInstallationPageRoutingModule = class DcInstallationPageRoutingModule {
};
DcInstallationPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], DcInstallationPageRoutingModule);



/***/ }),

/***/ "G0ov":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/salespipeline/dc-installation/dc-installation.page.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref=\"/salespipeline\">\n      </ion-back-button>\n      <ion-title>Installation DC</ion-title>\n      <ion-button (click)=\"addDC()\" [disabled]=\"!isLoading && !form.valid\" [style.visibility]=\"(!isLoading && (dcDetail==null  || (!dcDetail.isDelete))) ? 'visible' : 'hidden'\">\n        <ion-icon name=\"checkmark\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form  [formGroup]=\"form\"  *ngIf=\"!isLoading\">\n  <ion-grid>\n  <ion-row>\n      <ion-col>\n        <ion-item>\n          <ion-label position=\"floating\" >Client Name <span style=\"color: #FF6347;\">*</span></ion-label>\n          <ion-input type=\"text\"  formControlName=\"billName\"></ion-input>\n        </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col>\n      <ion-item class=\"item-readonly\">\n        <ion-label position=\"floating\" >Billing Address <span style=\"color: #FF6347;\">*</span></ion-label>\n        <ion-textarea  rows=\"4\"  formControlName=\"billAddress\"></ion-textarea>\n      </ion-item>\n  </ion-col>\n  </ion-row>\n  <ion-col size-sm=\"6\">\n    <ion-item class=\"item-readonly\">\n      <ion-label position=\"floating\" >Install At<span style=\"color: #FF6347;\">*</span></ion-label>\n      <ion-input  type=\"text\" formControlName=\"location\"></ion-input>\n    </ion-item>\n</ion-col>\n  <ion-row>\n    <ion-col>\n      <ion-item class=\"item-readonly\">\n        <ion-label position=\"floating\" >Delivery address<span style=\"color: #FF6347;\">*</span></ion-label>\n        <ion-textarea  rows=\"4\"  type=\"text\" formControlName=\"address\"></ion-textarea>\n      </ion-item>\n  </ion-col>\n  </ion-row>\n  <ion-row>\n  <ion-col>\n    <ion-item>\n      <ion-label position=\"floating\" >Delivery pincode<span style=\"color: #FF6347;\">*</span></ion-label>\n      <ion-input type=\"text\" formControlName=\"pincode\"></ion-input>\n    </ion-item>\n</ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\n      <ion-item>\n        <ion-label position=\"floating\" class=\"label\"> Deliver From Branch\n        </ion-label>\n        <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"branch\">\n          <ion-select-option *ngFor=\"let branch of branches\" [value]=\"branch.name\">{{branch.name}}\n          </ion-select-option>\n        </ion-select>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n\n  <ion-row>\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\n      <ion-item>\n        <ion-label position=\"floating\" >DC Date <span style=\"color: #FF6347;\">*</span></ion-label>\n        <ion-datetime\n        formControlName=\"date\"\n        display-format=\"MMM DD YYYY\"\n        picker-format=\"YY MMM DD\"\n        ></ion-datetime>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n\n\n  <div class=\"section\">\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <span style=\"font-size:13px\">Machine detail</span><span style=\"color: #FF6347;\">*</span>\n      </ion-col>\n    </ion-row>\n    <div *ngFor=\"let item of form.get('machineDetails')['controls']; let i = index;\" formArrayName=\"machineDetails\">\n      <div [formGroupName]=\"i\">\n        <ion-row>\n          <ion-col size=\"10\">\n            <ion-row>\n              <ion-col size=\"12\">\n                <ion-item>\n                  <ion-label position=\"floating\" class=\"label\">Machine\n                  </ion-label>\n                  <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineName\" (ionChange)=\"onMachineChange($event,form.get('machineDetails')['controls'][i])\">\n                    <ion-select-option *ngFor=\"let machine of machines\" [value]=\"machine\">{{machine}}\n                    </ion-select-option>\n                    </ion-select>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"12\">\n                <ion-item>\n                  <ion-label position=\"floating\" class=\"label\">Type\n                  </ion-label>\n                  <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineType\">\n                    <ion-select-option *ngFor=\"let machine of machineType\" [value]=\"machine\">{{machine}}\n                    </ion-select-option>\n                    </ion-select>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"12\">\n                <ion-item>\n                  <ion-label position=\"floating\" class=\"label\">Category\n                  </ion-label>\n                  <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineCategory\">\n                    <ion-select-option *ngFor=\"let machine of machineCategory\" [value]=\"machine\">{{machine}}\n                    </ion-select-option>\n                    </ion-select>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"12\">\n                <ion-item>\n                  <ion-label position=\"floating\" class=\"label\">No.of Machine\n                  </ion-label>\n                  <ion-input type=\"text\" autocomplete autocorrect formControlName=\"machineCount\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"12\">\n                <ion-item>\n                  <ion-label position=\"floating\" class=\"label\">Machine Serial Number\n                  </ion-label>\n                  <ion-input type=\"text\" autocomplete autocorrect formControlName=\"machineSrNo\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"12\">\n                <ion-item>\n                  <ion-label position=\"floating\" class=\"label\">HSN Number\n                  </ion-label>\n                  <ion-input type=\"text\" autocomplete autocorrect formControlName=\"machinehsncode\"></ion-input>\n                </ion-item>\n              </ion-col>\n\n              <ion-col size=\"12\">\n                <ion-item>\n                  <ion-label position=\"floating\" class=\"label\">Installation Charges\n                  </ion-label>\n                  <ion-input type=\"Number\" autocomplete autocorrect formControlName=\"mchInstCharges\"></ion-input>\n                </ion-item>\n              </ion-col>\n\n            </ion-row>\n          </ion-col>\n          <ion-col size=\"2\">\n            <div style=\"height: 95%; border-left:2px solid #FF69B4\">\n              <ion-button size=\"small\" class=\" button-assertive button-clear\" style=\"margin-top: 75px;\"\n                (click)=\"deleteMachine(i)\">\n                <ion-icon name=\"trash\" slot=\"icon-only\"></ion-icon>\n              </ion-button>\n            </div>\n          </ion-col>\n        </ion-row>\n      </div>\n    </div>\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-button size=\"small\" (click)=\"addMachine()\">\n          <ion-icon name=\"add-circle\"></ion-icon> Add Machine\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </div>\n\n\n\n  </ion-grid>\n  </form>\n  </ion-content>\n");

/***/ }),

/***/ "alp0":
/*!*************************************************************************!*\
  !*** ./src/app/salespipeline/dc-installation/dc-installation.page.scss ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".item-readonly {\n  --ion-item-background:#D0D0D0;\n  --ion-item-color:#000;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxkYy1pbnN0YWxsYXRpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsNkJBQUE7RUFDQSxxQkFBQTtBQUNGIiwiZmlsZSI6ImRjLWluc3RhbGxhdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaXRlbS1yZWFkb25seSB7XHJcbiAgLS1pb24taXRlbS1iYWNrZ3JvdW5kOiNEMEQwRDA7XHJcbiAgLS1pb24taXRlbS1jb2xvcjojMDAwO1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "sqtI":
/*!***********************************************************************!*\
  !*** ./src/app/salespipeline/dc-installation/dc-installation.page.ts ***!
  \***********************************************************************/
/*! exports provided: DcInstallationPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DcInstallationPage", function() { return DcInstallationPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_dc_installation_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./dc-installation.page.html */ "G0ov");
/* harmony import */ var _dc_installation_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dc-installation.page.scss */ "alp0");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_services_division_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/division.service */ "KWQH");
/* harmony import */ var _salespipeline_model__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../salespipeline.model */ "ZSGM");
/* harmony import */ var _salespipeline_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../salespipeline.service */ "bL0d");











let DcInstallationPage = class DcInstallationPage {
    constructor(route, navCtrl, divisionService, loadingCtrl, router, salespiplineService, toastController) {
        this.route = route;
        this.navCtrl = navCtrl;
        this.divisionService = divisionService;
        this.loadingCtrl = loadingCtrl;
        this.router = router;
        this.salespiplineService = salespiplineService;
        this.toastController = toastController;
        this.isLoading = true;
        this.materialstockType = [];
        this.dcId = null;
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.route.paramMap.subscribe((paramMap) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                if (!paramMap.has('salesId')) {
                    this.navCtrl.navigateBack('/salespipeline');
                }
                if (!paramMap.has('locId')) {
                    this.navCtrl.navigateBack('/salespipeline');
                }
                if (paramMap.has('dcId')) {
                    this.dcId = paramMap.get('dcId');
                }
                this.saleId = paramMap.get('salesId');
                this.locationId = paramMap.get('locId');
                this.perPipe = new _angular_common__WEBPACK_IMPORTED_MODULE_3__["PercentPipe"]('en-US');
                if (this.dcId != null) {
                    this.dcDetail = yield this.salespiplineService.getDCDetail(this.dcId, 1);
                }
                this.billingDetail = yield this.salespiplineService.getBillingDetail(this.saleId, this.locationId);
                yield this.loadBranches();
                yield this.loadMachineDetails();
                this.loadingCtrl.create({ keyboardClose: true }).then((loadingEl) => {
                    loadingEl.present();
                    this.salespiplineService
                        .getSalesPipelineById(this.saleId)
                        .subscribe((res) => {
                        this.clientSales = res;
                        this.clientSales.clientsale.locations.forEach(location => {
                            if (location.id == this.locationId) {
                                this.clientLocation = location;
                            }
                        });
                        if (this.dcDetail == null)
                            var result = this.initializeForm();
                        else
                            var result = this.initializeUpdateForm();
                        loadingEl.dismiss();
                        this.isLoading = false;
                    });
                });
            }));
        });
    }
    initializeForm() {
        this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            billName: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.billingDetail != null ? this.billingDetail.billName : this.clientSales.client.name, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            billAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.clientLocation.address, { updateOn: 'blur' }),
            location: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.clientLocation.installAt, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            address: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.clientLocation.installAddress, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            pincode: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.billingDetail != null ? this.billingDetail.pincode : null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            branch: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            date: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            machineDetails: this.buildMachineDetail(),
        });
        return true;
    }
    initializeUpdateForm() {
        this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            billName: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.dcDetail.billName, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            billAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.dcDetail.billAddress, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            location: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.dcDetail.location, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            address: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.dcDetail.address, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            pincode: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.dcDetail.pincode, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            branch: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.dcDetail.branch, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            date: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.dcDetail.date, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            machineDetails: this.updateMachineDetail(),
        });
        return true;
    }
    buildMachineDetail() {
        console.log(this.clientLocation);
        let machines = [];
        this.clientLocation.machines.forEach(element => {
            machines.push(new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
                machineName: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](element.machineName, {
                    updateOn: "blur",
                }),
                machineType: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](element.machineType, {
                    updateOn: "blur",
                }),
                machineCategory: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](element.machineCategory, {
                    updateOn: "blur",
                }),
                machineCount: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](element.machineCount, {
                    updateOn: "blur",
                }),
                machineSrNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](element.machineSrNo, {
                    updateOn: "blur",
                }),
                machinehsncode: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](element.machinehsncode ? element.machinehsncode : '', {
                    updateOn: "blur",
                }),
                mchInstCharges: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](element.mchInstCharges, {
                    updateOn: "blur",
                })
            }));
        });
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormArray"](machines);
    }
    updateMachineDetail() {
        let machines = [];
        this.dcDetail.machineDetails.forEach(element => {
            machines.push(new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
                machineName: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](element.machineName, {
                    updateOn: "blur",
                }),
                machineType: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](element.machineType, {
                    updateOn: "blur",
                }),
                machineCategory: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](element.machineCategory, {
                    updateOn: "blur",
                }),
                machineCount: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](element.machineCount, {
                    updateOn: "blur",
                }),
                machineSrNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](element.machineSrNo, {
                    updateOn: "blur",
                }),
                machinehsncode: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](element.machinehsncode ? element.machinehsncode : '', {
                    updateOn: "blur",
                }),
                mchInstCharges: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](element.mchInstCharges, {
                    updateOn: "blur",
                })
            }));
        });
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormArray"](machines);
    }
    createMachineDetail() {
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            machineName: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](null, {
                updateOn: "blur",
            }),
            machineType: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](null, {
                updateOn: "blur",
            }),
            machineCategory: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](null, {
                updateOn: "blur",
            }),
            machineCount: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](null, {
                updateOn: "blur",
            }),
            machineSrNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](null, {
                updateOn: "blur",
            }),
            machinehsncode: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](null, {
                updateOn: "blur",
            }),
            mchInstCharges: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](null, {
                updateOn: "blur",
            })
        });
    }
    addMachine() {
        let mchdetails = this.form.get('machineDetails');
        mchdetails.push(this.createMachineDetail());
    }
    deleteMachine(index) {
        let mchdetails = this.form.get('machineDetails');
        mchdetails.removeAt(index);
    }
    loadBranches() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.branches = yield this.divisionService.getBranches();
            return true;
        });
    }
    loadMachineDetails() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.machineDetail = yield this.divisionService.getMachineDetailList();
            this.machines = this.machineDetail.filter(item => item.group == 0).sort((a, b) => a.srno - b.srno).map(item => item.name);
            this.machineType = this.machineDetail.filter(item => item.group == 1).sort((a, b) => a.srno - b.srno).map(item => item.name);
            this.machineCategory = this.machineDetail.filter(item => item.group == 2).sort((a, b) => a.srno - b.srno).map(item => item.name);
            return true;
        });
    }
    onMachineChange(event, element) {
        if (!event.target.value)
            return;
        let ref = this.machineDetail.filter(item => item.name == event.target.value)[0].name;
        element.controls['machineCategory'].reset();
        this.machineCategory = [];
        this.machineCategory = this.machineDetail.filter(item => item.ref == ref && item.group == 2).sort((a, b) => a.srno - b.srno).map(item => item.name);
        if (ref == "FM" || ref == "Mtl(kg/mth)") {
            element.controls['machineCategory'].patchValue("Not Applicable", { emitEvent: false });
        }
    }
    padLeadingZeros(num, size) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            var s = num + '';
            while (s.length < size)
                s = '0' + s;
            return yield s;
        });
    }
    updateReceiptBook(receipt) {
        this.salespiplineService.addupdateReceiptBook(receipt, receipt.id == null ? false : true).subscribe();
    }
    addDC() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!this.form.valid) {
                return;
            }
            if (this.dcId != null)
                this.dcDetail = yield this.salespiplineService.getDCDetail(this.dcId, 1);
            let fmbillingDetail = this.form.value;
            let branch = this.branches.filter(x => x.name == fmbillingDetail.branch)[0];
            fmbillingDetail.salesId = this.saleId;
            fmbillingDetail.clientId = this.clientSales.clientsale.clientId;
            fmbillingDetail.site = this.clientSales.clientsale.locations.filter(x => x.id == this.locationId)[0].city;
            fmbillingDetail.locationId = this.locationId;
            fmbillingDetail.isDelete = false;
            if (this.billingDetail != null) {
                fmbillingDetail.id = this.billingDetail.id;
            }
            if (fmbillingDetail.machineDetails.length == 0) {
                return;
            }
            if (this.dcDetail == null) {
                let receiptBook = new _salespipeline_model__WEBPACK_IMPORTED_MODULE_9__["ReceiptBook"]();
                receiptBook.category = 'D';
                receiptBook.type = 'M';
                receiptBook.branch = branch.initials;
                receiptBook.year = 2021;
                let receiptNo = yield this.salespiplineService.getlastReceiptNumber(receiptBook);
                if (receiptNo != null) {
                    receiptBook.id = receiptNo.id;
                    receiptBook.srnumber = receiptNo.srnumber + 1;
                }
                else {
                    receiptBook.srnumber = 1;
                    receiptBook.id = null;
                }
                let srNo = yield this.padLeadingZeros(receiptBook.srnumber, 5);
                fmbillingDetail.srNo = `${receiptBook.category}/${receiptBook.type}/${branch.initials}/${receiptBook.year}/${srNo}`;
                fmbillingDetail.isUsed = false;
                fmbillingDetail.type = 1;
                this.salespiplineService
                    .addupdateDC(fmbillingDetail, false)
                    .subscribe((res) => {
                    this.toastController
                        .create({
                        message: 'Data updated',
                        duration: 2000,
                        color: 'success',
                    })
                        .then((tost) => {
                        this.updateReceiptBook(receiptBook);
                        tost.present();
                        this.router.navigate([
                            '/salespipeline/deliverychallanlist/' +
                                fmbillingDetail.clientId,
                        ]);
                    });
                });
            }
            else {
                fmbillingDetail.srNo = this.dcDetail.srNo;
                fmbillingDetail.isUsed = this.dcDetail.isUsed;
                fmbillingDetail.id = this.dcId;
                let invoice = yield this.salespiplineService.getInvoiceByDCId(this.dcDetail.id);
                this.updateInvoice(invoice, fmbillingDetail);
                this.salespiplineService
                    .addupdateDC(fmbillingDetail, true)
                    .subscribe((res) => {
                    this.toastController
                        .create({
                        message: 'Data updated',
                        duration: 2000,
                        color: 'success',
                    })
                        .then((tost) => {
                        tost.present();
                        this.router.navigate(['/salespipeline/deliverychallanlist/' + fmbillingDetail.clientId]);
                    });
                });
            }
        });
    }
    updateInvoice(invoice, dc) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (invoice == null)
                return;
            let inx = 0;
            invoice.dc.forEach((element, index) => {
                if (element.id === dc.id) {
                    inx = index;
                }
            });
            invoice.dc[inx] = dc;
            let totamount = 0;
            let tax = 0;
            let amount = 0;
            invoice.dc.forEach(dcelement => {
                dcelement['machineDetails'].forEach((material) => {
                    amount = amount + material.amount;
                    tax = tax + material.tax;
                    totamount = totamount + amount + tax;
                });
            });
            invoice.amount = amount;
            invoice.tax = tax;
            invoice.totamount = totamount;
            this.salespiplineService.addupdateInvoice(invoice, true).subscribe();
        });
    }
};
DcInstallationPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavController"] },
    { type: src_app_services_division_service__WEBPACK_IMPORTED_MODULE_8__["DivisionService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["LoadingController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _salespipeline_service__WEBPACK_IMPORTED_MODULE_10__["SalespipelineService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"] }
];
DcInstallationPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-dc-installation',
        template: _raw_loader_dc_installation_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_dc_installation_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], DcInstallationPage);



/***/ })

}]);
//# sourceMappingURL=dc-installation-dc-installation-module.js.map