(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~add-sales-add-sales-module~clients-clients-module~edit-sales-edit-sales-module~settings-clie~97d3b640"],{

/***/ "+RYs":
/*!*******************************************!*\
  !*** ./src/app/clients/client.service.ts ***!
  \*******************************************/
/*! exports provided: ClientService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientService", function() { return ClientService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../auth/auth.service */ "qXBG");
/* harmony import */ var _client_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./client.model */ "1btp");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! firebase/firestore */ "5x/H");









let ClientService = class ClientService {
    constructor(authService, http, firebaseService) {
        this.authService = authService;
        this.http = http;
        this.firebaseService = firebaseService;
        this._clients = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
    }
    get clients() {
        return this._clients.asObservable();
    }
    getClient(id) {
        return this.authService.token.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((token) => {
            return this.firebaseService
                .collection('clients')
                .doc(id)
                .valueChanges();
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])((resData) => {
            return new _client_model__WEBPACK_IMPORTED_MODULE_6__["Client"](id, resData.name, resData.contactPerson, resData.contactNumber, resData.email, resData.potentialNature, resData.accountOwner, resData.userId, resData.group, resData.gstNumber, resData.employeeStrength, resData.potentialNatureId, resData.country, resData.region, resData.subRegion, resData.state, resData.city, resData.locationId, resData.updatedOn, resData.divisionIds, resData.divisions, resData.clientTypeIds, resData.clientTypes, resData.id);
        }));
    }
    getClientList_O() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const userId = yield this.authService.userId
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])((userId) => {
                if (!userId) {
                    throw new Error('User not found!');
                }
                return userId;
            }))
                .toPromise();
            const users = yield this.firebaseService
                .collection('client-user-access', (ref) => ref.where('userId', '==', userId))
                .valueChanges()
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["first"])())
                .toPromise();
            const clientList = yield this.firebaseService
                .collection('clients', (ref) => ref.where('isActive', '==', true))
                .valueChanges()
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["first"])())
                .toPromise();
            let result = clientList;
            let clients = [];
            result.forEach((client) => {
                if (users.filter((c) => c['clientId'] == client.id).length > 0 ||
                    this.authService.isAdmin) {
                    clients.push(client);
                }
            });
            return clients;
        });
    }
    getClientList() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const clientList = yield this.firebaseService
                .collection('clients', (ref) => ref.where('isActive', '==', true).orderBy('name', "asc"))
                .valueChanges()
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1))
                .toPromise();
            let result = clientList;
            return result;
        });
    }
    getClientIdByGSTNumber(gstNumber) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const clientList = yield this.firebaseService
                .collection('clients', (ref) => ref.where('gstNumber', '==', gstNumber))
                .snapshotChanges()
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["first"])())
                .toPromise();
            return clientList.map((cl) => cl.payload.doc.id);
        });
    }
    fetchClients() {
        let fetchedUserId;
        return this.authService.userId.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((userId) => {
            if (!userId) {
                throw new Error('User not found!');
            }
            fetchedUserId = userId;
            return userId;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((userId) => {
            return this.firebaseService
                .collection('client-user-access', (ref) => ref.where('userId', '==', fetchedUserId))
                .valueChanges();
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((users) => {
            let useraccess = users;
            return this.firebaseService
                .collection('clients', (ref) => ref.where('isActive', '==', true).orderBy("name", "asc"))
                .snapshotChanges()
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])((clients) => {
                return clients.map((client) => {
                    var cl = Object.assign({}, client.payload.doc.data());
                    if (useraccess.filter((c) => c['clientId'] == cl.id).length > 0 ||
                        this.authService.isAdmin) {
                        cl.clientId = cl.id;
                        cl.id = client.payload.doc.id;
                        return cl;
                    }
                    return null;
                });
            }));
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])((clients) => {
            this._clients.next(clients.filter((c) => c != null));
        }));
    }
    addClient(name, contactPerson, contactNumber, email, potentialNature, accountOwner, group, gstNumber, employeeStrength, potentialNatureId, country, region, subRegion, state, city, locationId, updatedOn, divisionIds, divisions, typeIds, types) {
        let generatedId;
        let newClient;
        let fetchedUserId;
        return this.authService.userId.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((userId) => {
            fetchedUserId = userId;
            return this.authService.token;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((token) => {
            if (!fetchedUserId) {
                throw new Error('No User Id Found!');
            }
            newClient = new _client_model__WEBPACK_IMPORTED_MODULE_6__["Client"](Math.random().toString(), name, contactPerson, contactNumber, email, potentialNature, accountOwner, fetchedUserId, group, gstNumber, employeeStrength, potentialNatureId, country, region, subRegion, state, city, locationId, updatedOn, divisionIds, divisions, typeIds, types, '', true);
            return this.firebaseService
                .collection('clients')
                .add(Object.assign({}, newClient));
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((client) => {
            return client.id;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((resData) => {
            generatedId = resData;
            return this.clients;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])((clients) => {
            newClient.id = generatedId;
            this._clients.next(clients.concat(newClient));
        }));
    }
    editClient(clientId, name, contactPerson, contactNumber, email, potentialNature, accountOwner, group, gstNumber, employeeStrength, potentialNatureId, country, region, subRegion, state, city, locationId, updatedOn, divisionIds, divisions, typeIds, types, actclientId) {
        let updatedClients;
        let fetchedToken;
        return this.authService.token.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((token) => {
            fetchedToken = token;
            return this.clients;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((clients) => {
            if (!clients || clients.length <= 0) {
                return this.fetchClients();
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(clients);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((clients) => {
            const updatedClientIndex = clients.findIndex((pl) => pl.id === clientId);
            updatedClients = [...clients];
            const oldClient = updatedClients[updatedClientIndex];
            updatedClients[updatedClientIndex] = new _client_model__WEBPACK_IMPORTED_MODULE_6__["Client"](actclientId, name, contactPerson, contactNumber, email, potentialNature, accountOwner, oldClient.userId, group, gstNumber, employeeStrength, potentialNatureId, country, region, subRegion, state, city, locationId, updatedOn, divisionIds, divisions, typeIds, types, clientId, true);
            return this.firebaseService
                .collection('clients')
                .doc(clientId)
                .update(Object.assign({}, updatedClients[updatedClientIndex]));
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(() => {
            this._clients.next(updatedClients);
        }));
    }
    deleteClient(clientId) {
        return this.authService.token.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((token) => {
            return this.firebaseService
                .collection('clients')
                .doc(clientId)
                .update({ isActive: false });
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(() => {
            return this.clients;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])((clients) => {
            this._clients.next(clients.filter((b) => b.id !== clientId));
        }));
    }
    getLocations() {
        return this.firebaseService
            .collection('location')
            .valueChanges()
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((locs) => {
            const cityIds = locs.map((l) => l['cityId']);
            const countryIds = locs.map((l) => l['countryId']);
            const regionIds = locs.map((l) => l['regionId']);
            const subregionIds = locs.map((l) => l['subregionId']);
            const stateIds = locs.map((l) => l['stateId']);
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["combineLatest"])([
                Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(locs),
                Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["combineLatest"])(cityIds.map((cityId) => {
                    return this.firebaseService
                        .collection('city', (ref) => ref.where('id', '==', cityId))
                        .valueChanges()
                        .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])((cities) => cities[0]));
                })),
                Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["combineLatest"])(countryIds.map((contryId) => {
                    return this.firebaseService
                        .collection('country', (ref) => ref.where('id', '==', contryId))
                        .valueChanges()
                        .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])((countries) => countries[0]));
                })),
                Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["combineLatest"])(regionIds.map((regionId) => {
                    return this.firebaseService
                        .collection('region', (ref) => ref.where('id', '==', regionId))
                        .valueChanges()
                        .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])((regions) => regions[0]));
                })),
                Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["combineLatest"])(subregionIds.map((subregionId) => {
                    return this.firebaseService
                        .collection('subregion', (ref) => ref.where('id', '==', subregionId))
                        .valueChanges()
                        .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])((subregion) => subregion[0]));
                })),
                Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["combineLatest"])(stateIds.map((stateId) => {
                    return this.firebaseService
                        .collection('state', (ref) => ref.where('id', '==', stateId))
                        .valueChanges()
                        .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])((states) => states[0]));
                })),
            ]);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(([locs, cities, countries, regions, subregions, states]) => {
            return locs.map((loc) => {
                return Object.assign(Object.assign({}, loc), { cityId: cities.find((a) => a['id'] === loc['cityId']), countryId: countries.find((a) => a['id'] === loc['countryId']), regionId: regions.find((a) => a['id'] === loc['regionId']), subregionId: subregions.find((a) => a['id'] === loc['subregionId']), stateId: states.find((a) => a['id'] === loc['stateId']) });
            });
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    sendEmail() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            var emailobj = {
                to: 'jyoti.gogave@dwijafoods.com',
                from: 'jyoti.gogave@dwijafoods.com',
                subject: 'Demo request raised by Jyoti',
                location: [
                    {
                        city: 'Pune',
                        address: 'Magarppta City',
                        stDate: '01 Apr 2021',
                        contact: 'Facility Team',
                        machines: [{
                                name: 'Brewer',
                                type: 'Manual',
                                category: '5 ltr',
                                mchCount: '2'
                            }]
                    },
                ],
            };
            return yield this.http
                .post('https://us-central1-db-xtc-cafe-dev.cloudfunctions.net/emailMessage', emailobj)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])((res) => res))
                .toPromise();
        });
    }
};
ClientService.ctorParameters = () => [
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_7__["AngularFirestore"] }
];
ClientService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root',
    })
], ClientService);



/***/ }),

/***/ "1btp":
/*!*****************************************!*\
  !*** ./src/app/clients/client.model.ts ***!
  \*****************************************/
/*! exports provided: Client */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Client", function() { return Client; });
class Client {
    constructor(id, name, contactPerson, contactNumber, email, potentialNature, accountOwner, userId, group, gstNumber, employeeStrength, potentialNatureId, country, region, subRegion, state, city, locationId, updatedOn, divisionIds, divisions, clientTypeIds, clientTypes, clientId, isActive) {
        this.id = id;
        this.name = name;
        this.contactPerson = contactPerson;
        this.contactNumber = contactNumber;
        this.email = email;
        this.potentialNature = potentialNature;
        this.accountOwner = accountOwner;
        this.userId = userId;
        this.group = group;
        this.gstNumber = gstNumber;
        this.employeeStrength = employeeStrength;
        this.potentialNatureId = potentialNatureId;
        this.country = country;
        this.region = region;
        this.subRegion = subRegion;
        this.state = state;
        this.city = city;
        this.locationId = locationId;
        this.updatedOn = updatedOn;
        this.divisionIds = divisionIds;
        this.divisions = divisions;
        this.clientTypeIds = clientTypeIds;
        this.clientTypes = clientTypes;
        this.clientId = clientId;
        this.isActive = isActive;
    }
}


/***/ })

}]);
//# sourceMappingURL=default~add-sales-add-sales-module~clients-clients-module~edit-sales-edit-sales-module~settings-clie~97d3b640.js.map