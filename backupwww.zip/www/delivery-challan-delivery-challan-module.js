(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["delivery-challan-delivery-challan-module"],{

/***/ "73KF":
/*!***************************************************************************!*\
  !*** ./src/app/salespipeline/delivery-challan/delivery-challan.page.scss ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".item-readonly {\n  --ion-item-background:#D0D0D0;\n  --ion-item-color:#000;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxkZWxpdmVyeS1jaGFsbGFuLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDZCQUFBO0VBQ0EscUJBQUE7QUFDRiIsImZpbGUiOiJkZWxpdmVyeS1jaGFsbGFuLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5pdGVtLXJlYWRvbmx5IHtcclxuICAtLWlvbi1pdGVtLWJhY2tncm91bmQ6I0QwRDBEMDtcclxuICAtLWlvbi1pdGVtLWNvbG9yOiMwMDA7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "Fs/o":
/*!***************************************************************************!*\
  !*** ./src/app/salespipeline/delivery-challan/delivery-challan.module.ts ***!
  \***************************************************************************/
/*! exports provided: DeliveryChallanPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryChallanPageModule", function() { return DeliveryChallanPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _delivery_challan_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./delivery-challan-routing.module */ "d1ER");
/* harmony import */ var _delivery_challan_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./delivery-challan.page */ "bOmo");







let DeliveryChallanPageModule = class DeliveryChallanPageModule {
};
DeliveryChallanPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _delivery_challan_routing_module__WEBPACK_IMPORTED_MODULE_5__["DeliveryChallanPageRoutingModule"]
        ],
        declarations: [_delivery_challan_page__WEBPACK_IMPORTED_MODULE_6__["DeliveryChallanPage"]]
    })
], DeliveryChallanPageModule);



/***/ }),

/***/ "OIAM":
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/salespipeline/delivery-challan/delivery-challan.page.html ***!
  \*****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref=\"/salespipeline\">\n      </ion-back-button>\n      <ion-title>Delivery Challan</ion-title>\n      <ion-button (click)=\"addDC()\" [disabled]=\"!isLoading && !form.valid\" [style.visibility]=\"(!isLoading && (dcDetail==null  || (!dcDetail.isDelete))) ? 'visible' : 'hidden'\">\n        <ion-icon name=\"checkmark\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form  [formGroup]=\"form\"  *ngIf=\"!isLoading\">\n  <ion-grid>\n  <ion-row>\n      <ion-col>\n        <ion-item>\n          <ion-label position=\"floating\" >Client Name <span style=\"color: #FF6347;\">*</span></ion-label>\n          <ion-input type=\"text\"  formControlName=\"billName\"></ion-input>\n        </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col>\n      <ion-item class=\"item-readonly\">\n        <ion-label position=\"floating\" >Billing Address <span style=\"color: #FF6347;\">*</span></ion-label>\n        <ion-textarea  rows=\"4\"  formControlName=\"billAddress\"></ion-textarea>\n      </ion-item>\n  </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col>\n      <ion-item class=\"item-readonly\">\n        <ion-label position=\"floating\" >Install At<span style=\"color: #FF6347;\">*</span></ion-label>\n        <ion-input  type=\"text\" formControlName=\"location\"></ion-input>\n      </ion-item>\n  </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col>\n      <ion-item class=\"item-readonly\">\n        <ion-label position=\"floating\" >Delivery address<span style=\"color: #FF6347;\">*</span></ion-label>\n        <ion-textarea  rows=\"4\"  type=\"text\" formControlName=\"address\"></ion-textarea>\n      </ion-item>\n  </ion-col>\n  </ion-row>\n  <ion-row>\n  <ion-col>\n    <ion-item>\n      <ion-label position=\"floating\" >Delivery pincode<span style=\"color: #FF6347;\">*</span></ion-label>\n      <ion-input type=\"text\" formControlName=\"pincode\"></ion-input>\n    </ion-item>\n</ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\n      <ion-item>\n        <ion-label position=\"floating\" class=\"label\"> Deliver From Branch\n        </ion-label>\n        <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"branch\">\n          <ion-select-option *ngFor=\"let branch of branches\" [value]=\"branch.name\">{{branch.name}}\n          </ion-select-option>\n        </ion-select>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n\n  <ion-row>\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\n      <ion-item>\n        <ion-label position=\"floating\" >DC Date <span style=\"color: #FF6347;\">*</span></ion-label>\n        <ion-datetime\n        formControlName=\"date\"\n        display-format=\"MMM DD YYYY\"\n        picker-format=\"YY MMM DD\"\n        ></ion-datetime>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n\n\n  <div class=\"section\">\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <span style=\"font-size:13px\">Details of Material</span>\n      </ion-col>\n    </ion-row>\n    <div *ngFor=\"let item of form.get('materialDetails')['controls']; let i = index;\"\n      formArrayName=\"materialDetails\">\n      <div [formGroupName]=\"i\">\n        <ion-row>\n          <ion-col size=\"10\">\n            <ion-row>\n              <ion-col size=\"12\">\n                <ion-item>\n                  <ion-label position=\"floating\" class=\"label\">Material\n                  </ion-label>\n                  <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"category\" (ionChange)=\"onMaterialChange($event,form.get('materialDetails')['controls'][i],i)\">\n                    <ion-select-option *ngFor=\"let stock of stockCategory\" [value]=\"stock\">{{stock}}\n                    </ion-select-option>\n                    </ion-select>\n                </ion-item>\n              </ion-col>\n              <ion-col  size=\"12\">\n                <ion-item>\n                  <ion-label position=\"floating\" class=\"label\">Type\n                  </ion-label>\n                  <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"item\" (ionChange)=\"onMaterialTypeChange($event,form.get('materialDetails')['controls'][i])\">\n                    <ion-select-option *ngFor=\"let stock of this.materialstockType[i].stockType\" [value]=\"stock\">{{stock}}\n                    </ion-select-option>\n                    </ion-select>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"12\">\n                <ion-item color=\"success\">\n                  <ion-label position=\"floating\" class=\"label\"  style=\"color: #fff;\">UOM\n                  </ion-label>\n                  <ion-input type=\"text\" autocomplete autocorrect formControlName=\"uom\" readonly></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"12\">\n                <ion-item  color=\"success\">\n                  <ion-label position=\"floating\" class=\"label\"  style=\"color: #fff;\">HSNCode\n                  </ion-label>\n                  <ion-input type=\"text\" autocomplete autocorrect formControlName=\"hsnNo\" readonly></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"12\">\n                <ion-item  color=\"success\">\n                  <ion-label position=\"floating\" class=\"label\" style=\"color: #fff;\">GST\n                  </ion-label>\n                  <ion-input type=\"text\" autocomplete autocorrect formControlName=\"gst\"\n                  [value]=\"item.get('gst').value\"\n                  readonly></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col  size=\"12\">\n                <ion-item>\n                  <ion-label position=\"floating\" class=\"label\">Quantity\n                  </ion-label>\n                  <ion-input type=\"number\" autocomplete autocorrect formControlName=\"qty\"></ion-input>\n                </ion-item>\n              </ion-col>\n            </ion-row>\n          </ion-col>\n          <ion-col size=\"2\">\n            <div style=\"height: 95%; border-left:2px solid #FF69B4;\">\n              <ion-button size=\"small\" class=\" button-assertive button-clear\" style=\"margin-top: 75px;\"\n                (click)=\"deleteMaterial(i)\">\n                <ion-icon name=\"trash\" slot=\"icon-only\"></ion-icon>\n              </ion-button>\n            </div>\n          </ion-col>\n        </ion-row>\n      </div>\n    </div>\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-button size=\"small\" (click)=\"addMaterial()\">\n          <ion-icon name=\"add-circle\"></ion-icon> Add Material\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </div>\n\n\n  <div class=\"section\" style=\"display: none;\">\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <span style=\"font-size:13px\">Addhoc Material</span>\n      </ion-col>\n    </ion-row>\n    <div *ngFor=\"let item of form.get('materialAddhoc')['controls']; let i = index;\"\n      formArrayName=\"materialAddhoc\">\n      <div [formGroupName]=\"i\">\n        <ion-row>\n          <ion-col size=\"10\">\n            <ion-row>\n              <ion-col size=\"12\">\n                <ion-item>\n                  <ion-label position=\"floating\" class=\"label\">Material\n                  </ion-label>\n                 <ion-input type=\"text\" formControlName=\"item\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col  size=\"12\">\n                <ion-item>\n                  <ion-label position=\"floating\" class=\"label\">Price\n                  </ion-label>\n                  <ion-input type=\"number\" autocomplete autocorrect formControlName=\"price\"></ion-input>\n                </ion-item>\n              </ion-col>\n            </ion-row>\n          </ion-col>\n          <ion-col size=\"2\">\n            <div style=\"height: 95%; border-left:2px solid #FF69B4;\">\n              <ion-button size=\"small\" class=\" button-assertive button-clear\" style=\"margin-top: 75px;\"\n                (click)=\"deleteMaterialAddhoc(i)\">\n                <ion-icon name=\"trash\" slot=\"icon-only\"></ion-icon>\n              </ion-button>\n            </div>\n          </ion-col>\n        </ion-row>\n      </div>\n    </div>\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-button size=\"small\" (click)=\"addMaterialAddhoc()\">\n          <ion-icon name=\"add-circle\"></ion-icon> Add Material\n        </ion-button>\n      </ion-col>\n    </ion-row>\n\n  </div>\n\n  </ion-grid>\n  </form>\n  </ion-content>\n");

/***/ }),

/***/ "bOmo":
/*!*************************************************************************!*\
  !*** ./src/app/salespipeline/delivery-challan/delivery-challan.page.ts ***!
  \*************************************************************************/
/*! exports provided: DeliveryChallanPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryChallanPage", function() { return DeliveryChallanPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_delivery_challan_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./delivery-challan.page.html */ "OIAM");
/* harmony import */ var _delivery_challan_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./delivery-challan.page.scss */ "73KF");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_services_division_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/division.service */ "KWQH");
/* harmony import */ var _salespipeline_model__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../salespipeline.model */ "ZSGM");
/* harmony import */ var _salespipeline_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../salespipeline.service */ "bL0d");











let DeliveryChallanPage = class DeliveryChallanPage {
    constructor(route, navCtrl, divisionService, loadingCtrl, router, salespiplineService, toastController) {
        this.route = route;
        this.navCtrl = navCtrl;
        this.divisionService = divisionService;
        this.loadingCtrl = loadingCtrl;
        this.router = router;
        this.salespiplineService = salespiplineService;
        this.toastController = toastController;
        this.isLoading = true;
        this.materialstockType = [];
        this.dcId = null;
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.route.paramMap.subscribe((paramMap) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                if (!paramMap.has('salesId')) {
                    this.navCtrl.navigateBack('/salespipeline');
                }
                if (!paramMap.has('locId')) {
                    this.navCtrl.navigateBack('/salespipeline');
                }
                if (paramMap.has('dcId')) {
                    this.dcId = paramMap.get('dcId');
                }
                this.saleId = paramMap.get('salesId');
                this.locationId = paramMap.get('locId');
                this.perPipe = new _angular_common__WEBPACK_IMPORTED_MODULE_3__["PercentPipe"]('en-US');
                if (this.dcId != null) {
                    this.dcDetail = yield this.salespiplineService.getDCDetail(this.dcId);
                }
                this.billingDetail = yield this.salespiplineService.getBillingDetail(this.saleId, this.locationId);
                yield this.loadStockDetails();
                yield this.loadBranches();
                console.log(this.stockDetail);
                this.loadingCtrl.create({ keyboardClose: true }).then((loadingEl) => {
                    loadingEl.present();
                    this.salespiplineService
                        .getSalesPipelineById(this.saleId)
                        .subscribe((res) => {
                        this.clientSales = res;
                        this.clientSales.clientsale.locations.forEach(location => {
                            if (location.id == this.locationId) {
                                this.clientLocation = location;
                            }
                        });
                        if (this.dcDetail == null)
                            var result = this.initializeForm();
                        else
                            var result = this.initializeUpdateForm();
                        console.log(this.form);
                        loadingEl.dismiss();
                        this.isLoading = false;
                    });
                });
            }));
        });
    }
    initializeForm() {
        this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            billName: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.billingDetail != null ? this.billingDetail.billName : this.clientSales.client.name, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            billAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.clientLocation.address, { updateOn: 'blur' }),
            location: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.clientLocation.installAt, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            address: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.clientLocation.installAddress, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            pincode: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.billingDetail != null ? this.billingDetail.pincode : null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            branch: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            date: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            materialDetails: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormArray"]([this.createMaterialDetail()]),
            materialAddhoc: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormArray"]([this.createaddhocDetail()]),
        });
        return true;
    }
    initializeUpdateForm() {
        this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            billName: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.dcDetail.billName, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            billAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.dcDetail.billAddress, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            location: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.dcDetail.location, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            address: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.dcDetail.address, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            pincode: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.dcDetail.pincode, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            branch: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.dcDetail.branch, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            date: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.dcDetail.date, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            materialDetails: this.buildMaterialDetail(this.dcDetail),
            materialAddhoc: this.buildAddHocMaterialDetail(this.dcDetail),
        });
        return true;
    }
    buildMaterialDetail(dcdetail) {
        console.log(dcdetail.materialDetails);
        let fmarray = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormArray"]([]);
        dcdetail.materialDetails.forEach((material, index) => {
            fmarray.push(this.createMaterialDetail(material));
            let ref = this.stockDetail.filter(item => item.category == material.category)[0].category;
            this.materialstockType[index].stockType = this.stockDetail.filter(item => item.category == ref).map(item => item.item).sort();
        });
        return fmarray;
    }
    buildAddHocMaterialDetail(dcdetail) {
        let fmarray = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormArray"]([]);
        dcdetail.materialAddhoc.forEach((material, index) => {
            fmarray.push(this.createaddhocDetail(material));
        });
        return fmarray;
    }
    createMaterialDetail(materialRate) {
        this.materialstockType.push({ stockType: [] });
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            category: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](materialRate != null ? materialRate.category : null, {
                updateOn: "blur",
            }),
            item: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](materialRate != null ? materialRate.item : null, {
                updateOn: "blur",
            }),
            uom: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](materialRate != null ? materialRate.uom : null, {
                updateOn: "blur",
            }),
            hsnNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](materialRate != null ? materialRate.hsnNo : null, {
                updateOn: "blur",
            }),
            gst: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](materialRate != null ? materialRate.gst : null, {
                updateOn: "blur",
            }),
            qty: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](materialRate != null ? materialRate.qty : null, {
                updateOn: "blur",
            }),
        });
    }
    createaddhocDetail(dcAddHocMaterial) {
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            item: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](dcAddHocMaterial != null ? dcAddHocMaterial.item : null, {
                updateOn: "blur",
            }),
            price: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](dcAddHocMaterial != null ? dcAddHocMaterial.price : null, {
                updateOn: "blur",
            }),
        });
    }
    loadStockDetails() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.billingDetail != null) {
                this.stockDetail = this.billingDetail.materialDetails;
                this.stockCategory = this.stockDetail.map(item => item.category).filter((value, index, self) => self.indexOf(value) === index).sort();
            }
            else {
                this.stockDetail = [];
                this.stockCategory = [];
            }
            return true;
        });
    }
    loadBranches() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.branches = yield this.divisionService.getBranches();
            return true;
        });
    }
    addMaterial() {
        let matdetails = this.form.get('materialDetails');
        matdetails.push(this.createMaterialDetail());
    }
    deleteMaterial(index) {
        let matdetails = this.form.get('materialDetails');
        matdetails.removeAt(index);
        this.materialstockType.splice(index, 1);
    }
    addMaterialAddhoc() {
        let matdetails = this.form.get('materialAddhoc');
        matdetails.push(this.createaddhocDetail());
    }
    deleteMaterialAddhoc(index) {
        let matdetails = this.form.get('materialAddhoc');
        matdetails.removeAt(index);
    }
    onMaterialChange(event, element, index) {
        if (!event.target.value)
            return;
        let ref = this.stockDetail.filter(item => item.category == event.target.value)[0].category;
        element.controls['item'].reset();
        element.controls['uom'].patchValue(null, { emitEvent: false });
        element.controls['hsnNo'].patchValue(null, { emitEvent: false });
        element.controls['gst'].patchValue(null, { emitEvent: false });
        this.materialstockType[index].stockType = this.stockDetail.filter(item => item.category == ref).map(item => item.item).sort();
    }
    onMaterialTypeChange(event, element) {
        if (!event.target.value)
            return;
        let ref = this.stockDetail.filter(item => item.item == event.target.value)[0];
        element.controls['uom'].patchValue(ref.uom, { emitEvent: false });
        element.controls['hsnNo'].patchValue(ref.hsnNo, { emitEvent: false });
        element.controls['gst'].patchValue(ref.gst, { emitEvent: false });
    }
    padLeadingZeros(num, size) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            var s = num + '';
            while (s.length < size)
                s = '0' + s;
            return yield s;
        });
    }
    updateReceiptBook(receipt) {
        this.salespiplineService.addupdateReceiptBook(receipt, receipt.id == null ? false : true).subscribe();
    }
    addDC() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!this.form.valid) {
                return;
            }
            if (this.dcId != null)
                this.dcDetail = yield this.salespiplineService.getDCDetail(this.dcId);
            let fmbillingDetail = this.form.value;
            let branch = this.branches.filter(x => x.name == fmbillingDetail.branch)[0];
            fmbillingDetail.salesId = this.saleId;
            fmbillingDetail.clientId = this.clientSales.clientsale.clientId;
            fmbillingDetail.locationId = this.locationId;
            fmbillingDetail.site = this.clientSales.clientsale.locations.filter(x => x.id == this.locationId)[0].city;
            fmbillingDetail.isDelete = false;
            if (this.billingDetail != null) {
                fmbillingDetail.id = this.billingDetail.id;
            }
            if (fmbillingDetail.materialDetails.length == 0) {
                return;
            }
            fmbillingDetail.materialDetails.forEach(material => {
                let filterresult = this.billingDetail.materialDetails.filter(m => m.item == material.item && m.category == material.category && m.hsnNo == material.hsnNo);
                material.rate = Number(filterresult[0].price);
                material.amount = Number(filterresult[0].price) * Number(material.qty);
                material.tax = material.amount * (Number(filterresult[0].gst.replace('%', '')) / 100);
                material.totamount = material.amount + material.tax;
            });
            if (this.dcDetail == null) {
                let receiptBook = new _salespipeline_model__WEBPACK_IMPORTED_MODULE_9__["ReceiptBook"]();
                receiptBook.category = 'D';
                receiptBook.type = 'C';
                receiptBook.branch = branch.initials;
                receiptBook.year = 2021;
                let receiptNo = yield this.salespiplineService.getlastReceiptNumber(receiptBook);
                if (receiptNo != null) {
                    receiptBook.id = receiptNo.id;
                    receiptBook.srnumber = receiptNo.srnumber + 1;
                }
                else {
                    receiptBook.srnumber = 1;
                    receiptBook.id = null;
                }
                let srNo = yield this.padLeadingZeros(receiptBook.srnumber, 5);
                fmbillingDetail.srNo = `${receiptBook.category}/${receiptBook.type}/${branch.initials}/${receiptBook.year}/${srNo}`;
                fmbillingDetail.isUsed = false;
                this.salespiplineService
                    .addupdateDC(fmbillingDetail, false)
                    .subscribe((res) => {
                    this.toastController
                        .create({
                        message: 'Data updated',
                        duration: 2000,
                        color: 'success',
                    })
                        .then((tost) => {
                        this.updateReceiptBook(receiptBook);
                        tost.present();
                        this.router.navigate([
                            '/salespipeline/deliverychallanlist/' +
                                fmbillingDetail.clientId,
                        ]);
                    });
                });
            }
            else {
                fmbillingDetail.srNo = this.dcDetail.srNo;
                fmbillingDetail.isUsed = this.dcDetail.isUsed;
                fmbillingDetail.id = this.dcId;
                let invoice = yield this.salespiplineService.getInvoiceByDCId(this.dcDetail.id);
                this.updateInvoice(invoice, fmbillingDetail);
                this.salespiplineService
                    .addupdateDC(fmbillingDetail, true)
                    .subscribe((res) => {
                    this.toastController
                        .create({
                        message: 'Data updated',
                        duration: 2000,
                        color: 'success',
                    })
                        .then((tost) => {
                        tost.present();
                        this.router.navigate(['/salespipeline/deliverychallanlist/' + fmbillingDetail.clientId]);
                    });
                });
            }
        });
    }
    updateInvoice(invoice, dc) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (invoice == null)
                return;
            let inx = 0;
            invoice.dc.forEach((element, index) => {
                if (element.id === dc.id) {
                    inx = index;
                }
            });
            invoice.dc[inx] = dc;
            let totamount = 0;
            let tax = 0;
            let amount = 0;
            invoice.dc.forEach(dcelement => {
                dcelement.materialDetails.forEach((material) => {
                    amount = amount + material.amount;
                    tax = tax + material.tax;
                    totamount = totamount + amount + tax;
                });
            });
            invoice.amount = amount;
            invoice.tax = tax;
            invoice.totamount = totamount;
            this.salespiplineService.addupdateInvoice(invoice, true).subscribe();
        });
    }
};
DeliveryChallanPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavController"] },
    { type: src_app_services_division_service__WEBPACK_IMPORTED_MODULE_8__["DivisionService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["LoadingController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _salespipeline_service__WEBPACK_IMPORTED_MODULE_10__["SalespipelineService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"] }
];
DeliveryChallanPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-delivery-challan',
        template: _raw_loader_delivery_challan_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_delivery_challan_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], DeliveryChallanPage);



/***/ }),

/***/ "d1ER":
/*!***********************************************************************************!*\
  !*** ./src/app/salespipeline/delivery-challan/delivery-challan-routing.module.ts ***!
  \***********************************************************************************/
/*! exports provided: DeliveryChallanPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryChallanPageRoutingModule", function() { return DeliveryChallanPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _delivery_challan_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./delivery-challan.page */ "bOmo");




const routes = [
    {
        path: '',
        component: _delivery_challan_page__WEBPACK_IMPORTED_MODULE_3__["DeliveryChallanPage"]
    }
];
let DeliveryChallanPageRoutingModule = class DeliveryChallanPageRoutingModule {
};
DeliveryChallanPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], DeliveryChallanPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=delivery-challan-delivery-challan-module.js.map