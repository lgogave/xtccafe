(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["demo-request-demo-request-module"],{

/***/ "3iBL":
/*!*******************************************************************!*\
  !*** ./src/app/salespipeline/demo-request/demo-request.page.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".section {\n  margin: 5px;\n  border: 2px solid #BA55D3;\n}\n\n.label {\n  color: #aeaeae;\n}\n\n.panel_header {\n  width: 100%;\n  display: inline-block;\n  background-color: #ffffff;\n  border: 1px solid rgba(0, 0, 0, 0.09);\n  border-bottom: 0px solid transparent;\n  vertical-align: top;\n  position: relative;\n  min-height: 75px;\n}\n\n.panel_header .title {\n  margin-top: 10px;\n  font-family: \"Roboto\", Arial, Helvetica, sans-serif;\n  font-size: 19px;\n  padding-left: 30px;\n  padding-top: 15px;\n  line-height: 30px;\n  color: #676767;\n  font-weight: 400;\n  text-transform: uppercase;\n  display: inline-block;\n}\n\n.pull-left {\n  float: left !important;\n}\n\n.pull-right {\n  float: right !important;\n}\n\n.panel_header .actions {\n  margin: 10px 15px 0 15px;\n  line-height: 50px;\n  position: absolute;\n  right: 0px;\n  top: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxkZW1vLXJlcXVlc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtFQUNBLHlCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxjQUFBO0FBRUY7O0FBQ0E7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSx5QkFBQTtFQUNBLHFDQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFFRjs7QUFDQTtFQUNFLGdCQUFBO0VBQ0EsbURBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EseUJBQUE7RUFDQSxxQkFBQTtBQUVGOztBQUFBO0VBQ0Usc0JBQUE7QUFHRjs7QUFEQTtFQUNFLHVCQUFBO0FBSUY7O0FBRkE7RUFDRSx3QkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsUUFBQTtBQUtGIiwiZmlsZSI6ImRlbW8tcmVxdWVzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2VjdGlvbntcclxuICBtYXJnaW46IDVweDtcclxuICBib3JkZXI6IDJweCBzb2xpZCAjQkE1NUQzO1xyXG59XHJcbi5sYWJlbHtcclxuICBjb2xvcjogI2FlYWVhZTtcclxufVxyXG5cclxuLnBhbmVsX2hlYWRlciB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgwLDAsMCwwLjA5KTtcclxuICBib3JkZXItYm90dG9tOiAwcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgdmVydGljYWwtYWxpZ246IHRvcDtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgbWluLWhlaWdodDogNzVweDtcclxufVxyXG5cclxuLnBhbmVsX2hlYWRlciAudGl0bGUge1xyXG4gIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgZm9udC1mYW1pbHk6ICdSb2JvdG8nLCBBcmlhbCwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmO1xyXG4gIGZvbnQtc2l6ZTogMTlweDtcclxuICBwYWRkaW5nLWxlZnQ6IDMwcHg7XHJcbiAgcGFkZGluZy10b3A6IDE1cHg7XHJcbiAgbGluZS1oZWlnaHQ6IDMwcHg7XHJcbiAgY29sb3I6ICM2NzY3Njc7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxufVxyXG4ucHVsbC1sZWZ0IHtcclxuICBmbG9hdDogbGVmdCFpbXBvcnRhbnQ7XHJcbn1cclxuLnB1bGwtcmlnaHQge1xyXG4gIGZsb2F0OiByaWdodCFpbXBvcnRhbnQ7XHJcbn1cclxuLnBhbmVsX2hlYWRlciAuYWN0aW9ucyB7XHJcbiAgbWFyZ2luOiAxMHB4IDE1cHggMCAxNXB4O1xyXG4gIGxpbmUtaGVpZ2h0OiA1MHB4O1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICByaWdodDogMHB4O1xyXG4gIHRvcDogMHB4O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "RE6X":
/*!*******************************************************************!*\
  !*** ./src/app/salespipeline/demo-request/demo-request.module.ts ***!
  \*******************************************************************/
/*! exports provided: DemoRequestPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoRequestPageModule", function() { return DemoRequestPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _demo_request_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./demo-request-routing.module */ "y8pr");
/* harmony import */ var _demo_request_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./demo-request.page */ "WmQI");







let DemoRequestPageModule = class DemoRequestPageModule {
};
DemoRequestPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _demo_request_routing_module__WEBPACK_IMPORTED_MODULE_5__["DemoRequestPageRoutingModule"]
        ],
        declarations: [_demo_request_page__WEBPACK_IMPORTED_MODULE_6__["DemoRequestPage"]]
    })
], DemoRequestPageModule);



/***/ }),

/***/ "U8gh":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/salespipeline/demo-request/demo-request.page.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref=\"/salespipeline\">\n      </ion-back-button>\n      <ion-title>Demo Requisition Form</ion-title>\n      <ion-button (click)=\"addDemoRequest()\" [disabled]=\"!form?.valid\">\n        <ion-icon name=\"checkmark\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <form [formGroup]=\"form\" *ngIf=\"!isLoading\">\n    <ion-grid>\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Organization</span><span style=\"color: #FF6347;\">*</span>\n            <ion-item>\n              <ion-input type=\"text\" autocomplete autocorrect placeholder=\"Client Name\" formControlName=\"orgName\">\n              </ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('orgName').valid && form.get('orgName').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Client name should not be empty.</p>\n          </ion-col>\n        </ion-row>\n\n\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Client Status</ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"orgStatus\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </div>\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Statutory Detail</span>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n        <ion-col size-sm=\"3\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" class=\"label\">Tax Type\n          </ion-label>\n          <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"taxType\">\n            <ion-select-option [value]=\"CGSTSGST\">CGST/SGST</ion-select-option>\n              <ion-select-option [value]=\"IGST\">IGST\n            </ion-select-option>\n            </ion-select>\n        </ion-item>\n        </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">GST No</ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"satGSTNo\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">SEZ\n              </ion-label>\n              <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"satSEZ\">\n                <ion-select-option value=\"Yes\">Yes</ion-select-option>\n                <ion-select-option value=\"No\">No</ion-select-option>\n              </ion-select>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('satSEZ').valid && form.get('satSEZ').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Please select SEZ/Non SEZ.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Branch\n              </ion-label>\n              <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"satBranch\">\n                <ion-select-option *ngFor=\"let branch of branches\" [value]=\"branch.name\">{{branch.name}}\n                </ion-select-option>\n              </ion-select>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('satBranch').valid && form.get('satBranch').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Please select brach for challan address.</p>\n          </ion-col>\n        </ion-row>\n      </div>\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Address of the Demonstration</span><span style=\"color: #FF6347;\">*</span>\n            <ion-item>\n              <ion-input type=\"text\" autocomplete autocorrect placeholder=\"Address\" formControlName=\"address\">\n              </ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('address').valid && form.get('address').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Address should not be empty.</p>\n          </ion-col>\n        </ion-row>\n\n\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Location<span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"addLocation\"></ion-input>\n            </ion-item>\n          </ion-col>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Pin Code<span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"addPincode\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n\n        <ion-row *ngIf=\"!form.get('addLocation').valid && form.get('addLocation').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Location should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('addPincode').valid && form.get('addPincode').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Pincode should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">State<span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"addState\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n\n        <ion-row *ngIf=\"!form.get('addState').valid && form.get('addState').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">State should not be empty.</p>\n          </ion-col>\n        </ion-row>\n      </div>\n\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Contact Person</span><span style=\"color: #FF6347;\">*</span>\n            <ion-item>\n              <ion-input type=\"text\" autocomplete autocorrect placeholder formControlName=\"conName\" placeholder='Name'>\n              </ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('conName').valid && form.get('conName').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Contact Person should not be empty.</p>\n          </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Mobile No<span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"conMobile\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('conMobile').valid && form.get('conMobile').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Mobile number should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Email</ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"conEmail\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </div>\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Machine detail</span><span style=\"color: #FF6347;\">*</span>\n          </ion-col>\n        </ion-row>\n        <div *ngFor=\"let item of form.get('machineDetails')['controls']; let i = index;\" formArrayName=\"machineDetails\">\n          <div [formGroupName]=\"i\">\n            <ion-row>\n              <ion-col size=\"10\">\n                <ion-row>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Machine\n                      </ion-label>\n                      <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineName\" (ionChange)=\"onMachineChange($event,form.get('machineDetails')['controls'][i])\">\n                        <ion-select-option *ngFor=\"let machine of machines\" [value]=\"machine\">{{machine}}\n                        </ion-select-option>\n                        </ion-select>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Type\n                      </ion-label>\n                      <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineType\">\n                        <ion-select-option *ngFor=\"let machine of machineType\" [value]=\"machine\">{{machine}}\n                        </ion-select-option>\n                        </ion-select>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Category\n                      </ion-label>\n                      <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"volumeType\">\n                        <ion-select-option *ngFor=\"let machine of machineCategory\" [value]=\"machine\">{{machine}}\n                        </ion-select-option>\n                        </ion-select>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">No.of Machine\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"machineCount\"></ion-input>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Machine Serial Number\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"machinesrno\"></ion-input>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">HSN Number\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"machinehsnNo\"></ion-input>\n                    </ion-item>\n                  </ion-col>\n\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Rate (* applicable for SEZ)\n                      </ion-label>\n                      <ion-input type=\"Number\" autocomplete autocorrect formControlName=\"machinerate\"></ion-input>\n                    </ion-item>\n                  </ion-col>\n\n                </ion-row>\n              </ion-col>\n              <ion-col size=\"2\">\n                <div style=\"height: 95%; border-left:2px solid #FF69B4\">\n                  <ion-button size=\"small\" class=\" button-assertive button-clear\" style=\"margin-top: 75px;\"\n                    (click)=\"deleteMachine(i)\">\n                    <ion-icon name=\"trash\" slot=\"icon-only\"></ion-icon>\n                  </ion-button>\n                </div>\n              </ion-col>\n            </ion-row>\n          </div>\n        </div>\n        <ion-row>\n          <ion-col size=\"12\">\n            <ion-button size=\"small\" (click)=\"addMachine()\">\n              <ion-icon name=\"add-circle\"></ion-icon> Add Machine\n            </ion-button>\n          </ion-col>\n        </ion-row>\n\n\n\n      </div>\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Accessories</span>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Installation/Demo Kit</ion-label>\n              <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"accInstallation\" multiple>\n                <ion-select-option *ngFor=\"let kit of installkititems\" [value]=\"kit\">{{kit}}\n                </ion-select-option>\n                </ion-select>\n            </ion-item>\n          </ion-col>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Other Accessories</ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"accOther\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </div>\n\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Terms of Installation</span>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Demo</ion-label>\n              <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"instDemo\">\n                <ion-select-option value=\"Free\">Free</ion-select-option>\n                <ion-select-option value=\"Chargeble\">Chargeble</ion-select-option>\n              </ion-select>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </div>\n\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Date</span>\n          </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">DC Date<span style=\"color: #FF6347;\">*</span>\n              </ion-label>\n              <ion-datetime formControlName=\"dateDC\" display-format=\"MMM DD YYYY\" picker-format=\"YY MMM DD\">\n              </ion-datetime>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Date of Delivery<span style=\"color: #FF6347;\">*</span>\n              </ion-label>\n              <ion-datetime formControlName=\"dateDelivery\" display-format=\"MMM DD YYYY\" picker-format=\"YY MMM DD\">\n              </ion-datetime>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('dateDelivery').valid && form.get('dateDelivery').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Date of Delivery should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Start Date of Demo<span style=\"color: #FF6347;\">*</span>\n              </ion-label>\n              <ion-datetime formControlName=\"dateDemo\" display-format=\"MMM DD YYYY\" picker-format=\"YY MMM DD\">\n              </ion-datetime>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('dateDemo').valid && form.get('dateDemo').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Start Date of Demo should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">End Date of Demo<span style=\"color: #FF6347;\">*</span>\n              </ion-label>\n              <ion-datetime formControlName=\"dateEndDemo\" display-format=\"MMM DD YYYY\" picker-format=\"YY MMM DD\">\n              </ion-datetime>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('dateEndDemo').valid && form.get('dateEndDemo').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">End Date of Demo should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Date of Pickup<span style=\"color: #FF6347;\">*</span>\n              </ion-label>\n              <ion-datetime formControlName=\"datePickup\" display-format=\"MMM DD YYYY\" picker-format=\"YY MMM DD\">\n              </ion-datetime>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('datePickup').valid && form.get('datePickup').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Date of Pickup should not be empty.</p>\n          </ion-col>\n        </ion-row>\n      </div>\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Details of Consumption</span>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">No.Employee\n              </ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"cnsNoEmp\"></ion-input>\n            </ion-item>\n          </ion-col>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">No.of Cups /day</ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"cnsNoCups\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </div>\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Details of Material</span>\n          </ion-col>\n        </ion-row>\n        <div *ngFor=\"let item of form.get('materialDetails')['controls']; let i = index;\"\n          formArrayName=\"materialDetails\">\n          <div [formGroupName]=\"i\">\n            <ion-row>\n              <ion-col size=\"10\">\n                <ion-row>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Material\n                      </ion-label>\n                      <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"category\" (ionChange)=\"onMaterialChange($event,form.get('materialDetails')['controls'][i])\">\n                        <ion-select-option *ngFor=\"let stock of stockCategory\" [value]=\"stock\">{{stock}}\n                        </ion-select-option>\n                        </ion-select>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col  size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Type\n                      </ion-label>\n                      <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"item\" (ionChange)=\"onMaterialTypeChange($event,form.get('materialDetails')['controls'][i])\">\n                        <ion-select-option *ngFor=\"let stock of stockType\" [value]=\"stock\">{{stock}}\n                        </ion-select-option>\n                        </ion-select>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item color=\"success\">\n                      <ion-label position=\"floating\" class=\"label\"  style=\"color: #fff;\">UOM\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"uom\" readonly></ion-input>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item  color=\"success\">\n                      <ion-label position=\"floating\" class=\"label\"  style=\"color: #fff;\">HSNCode\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"hsnNo\" readonly></ion-input>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item  color=\"success\">\n                      <ion-label position=\"floating\" class=\"label\" style=\"color: #fff;\">GST\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"gst\"\n                      [value]=\"item.get('gst').value\"\n                      readonly></ion-input>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col  size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Qty\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"qty\"></ion-input>\n                    </ion-item>\n                  </ion-col>\n                </ion-row>\n                <ion-row>\n                  <ion-col  size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Rate (* Applicable for SEZ)\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"rate\"></ion-input>\n                    </ion-item>\n                  </ion-col>\n                </ion-row>\n              </ion-col>\n              <ion-col size=\"2\">\n                <div style=\"height: 95%; border-left:2px solid #FF69B4;\">\n                  <ion-button size=\"small\" class=\" button-assertive button-clear\" style=\"margin-top: 75px;\"\n                    (click)=\"deleteMaterial(i)\">\n                    <ion-icon name=\"trash\" slot=\"icon-only\"></ion-icon>\n                  </ion-button>\n                </div>\n              </ion-col>\n            </ion-row>\n          </div>\n        </div>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-button size=\"small\" (click)=\"addMaterial()\">\n              <ion-icon name=\"add-circle\"></ion-icon> Add Material\n            </ion-button>\n          </ion-col>\n        </ion-row>\n      </div>\n\n\n\n\n\n    </ion-grid>\n  </form>\n</ion-content>\n");

/***/ }),

/***/ "WmQI":
/*!*****************************************************************!*\
  !*** ./src/app/salespipeline/demo-request/demo-request.page.ts ***!
  \*****************************************************************/
/*! exports provided: DemoRequestPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoRequestPage", function() { return DemoRequestPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_demo_request_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./demo-request.page.html */ "U8gh");
/* harmony import */ var _demo_request_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./demo-request.page.scss */ "3iBL");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_services_demo_request_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/demo-request.service */ "4ttV");
/* harmony import */ var _salespipeline_model__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../salespipeline.model */ "ZSGM");
/* harmony import */ var _salespipeline_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../salespipeline.service */ "bL0d");
/* harmony import */ var src_app_services_division_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/division.service */ "KWQH");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ "ofXK");












let DemoRequestPage = class DemoRequestPage {
    constructor(route, navCtrl, salespiplineService, loadingCtrl, demoRequestService, toastController, router, divisionService) {
        this.route = route;
        this.navCtrl = navCtrl;
        this.salespiplineService = salespiplineService;
        this.loadingCtrl = loadingCtrl;
        this.demoRequestService = demoRequestService;
        this.toastController = toastController;
        this.router = router;
        this.divisionService = divisionService;
        this.isLoading = true;
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.route.paramMap.subscribe((paramMap) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                if (!paramMap.has('salesId')) {
                    this.navCtrl.navigateBack('/salespipeline');
                }
                if (!paramMap.has('locationIndex')) {
                    this.navCtrl.navigateBack('/salespipeline');
                }
                this.perPipe = new _angular_common__WEBPACK_IMPORTED_MODULE_11__["PercentPipe"]('en-US');
                this.saleId = paramMap.get('salesId');
                this.locationIndex = paramMap.get('locationIndex');
                yield this.loadMachineDetails();
                yield this.loadStockDetails();
                yield this.loadInstallKitDetails();
                yield this.loadBranches();
                this.loadingCtrl.create({ keyboardClose: true }).then((loadingEl) => {
                    loadingEl.present();
                    this.salespiplineService.getSalesPipelineById(this.saleId).subscribe(res => {
                        this.clientSales = res;
                        var result = this.initializeForm();
                        loadingEl.dismiss();
                        this.isLoading = false;
                    });
                });
            }));
        });
    }
    initializeForm() {
        this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            machineDetails: this.buildMachineDetail(),
            materialDetails: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormArray"]([this.createMaterialDetail()]),
            orgName: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.clientSales.clientsale.client, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
            orgStatus: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.clientSales.client.potentialNature, { updateOn: 'blur' }),
            address: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.clientSales.clientsale.locations[this.locationIndex].installAddress, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
            addLocation: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.clientSales.clientsale.locations[this.locationIndex].installAt, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
            addPincode: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
            addState: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
            conName: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.clientSales.client.contactPerson, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
            conMobile: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.clientSales.client.contactNumber, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
            conEmail: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.clientSales.client.email, { updateOn: 'blur' }),
            accInstallation: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur' }),
            accOther: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur' }),
            instDemo: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur' }),
            dateDC: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](new Date().toISOString(), { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
            dateDelivery: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
            dateDemo: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
            dateEndDemo: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
            datePickup: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
            satGSTNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur' }),
            satSEZ: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
            satBranch: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
            cnsNoEmp: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur' }),
            cnsNoCups: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur' }),
            taxType: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required] }),
        });
        return true;
    }
    buildMachineDetail() {
        let machines = [];
        this.clientSales.clientsale.locations[this.locationIndex].machines.forEach(element => {
            machines.push(new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
                machineName: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](element.machineName, {
                    updateOn: "blur",
                }),
                machineType: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](element.machineType, {
                    updateOn: "blur",
                }),
                volumeType: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](element.machineCategory, {
                    updateOn: "blur",
                }),
                machineCount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](element.machineCount, {
                    updateOn: "blur",
                }),
                machinesrno: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](element.machineSrNo, {
                    updateOn: "blur",
                }),
                machinehsnNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](element.machinehsncode ? element.machinehsncode : '', {
                    updateOn: "blur",
                }),
                machinerate: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: "blur",
                })
            }));
        });
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormArray"](machines);
    }
    createMachineDetail() {
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            machineName: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            machineType: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            volumeType: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            machineCount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            machinesrno: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            machinehsnNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            machinerate: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            })
        });
    }
    createMaterialDetail() {
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            category: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            item: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            uom: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            hsnNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            gst: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            qty: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
            rate: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                updateOn: "blur",
            }),
        });
    }
    addDemoRequest() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!this.form.valid) {
                return;
            }
            let demoRequest = this.form.value;
            if (demoRequest.machineDetails.length == 0
                || demoRequest.materialDetails.length == 0) {
                return;
            }
            demoRequest.reqStatus = 'Demo Request Created';
            let id = Math.floor(Math.random() * 26) + Date.now();
            demoRequest.id = id;
            demoRequest.salespipelineId = this.saleId;
            let branch = this.branches.filter(x => x.name == demoRequest.satBranch)[0];
            let receiptBook = new _salespipeline_model__WEBPACK_IMPORTED_MODULE_8__["ReceiptBook"]();
            receiptBook.category = "DD";
            receiptBook.type = "C";
            receiptBook.branch = branch.initials;
            receiptBook.year = 2021;
            let receiptNo = yield this.salespiplineService.getlastReceiptNumber(receiptBook);
            if (receiptNo != null) {
                receiptBook.id = receiptNo.id;
                receiptBook.srnumber = receiptNo.srnumber + 1;
            }
            else {
                receiptBook.srnumber = 1;
                receiptBook.id = null;
            }
            let srNo = yield this.padLeadingZeros(receiptBook.srnumber, 5);
            demoRequest.srNo = `${receiptBook.category}/${receiptBook.type}/${branch.initials}/${receiptBook.year}/${srNo}`;
            this.demoRequestService.addDemoRequest(demoRequest).subscribe((res) => {
                this.toastController.create({
                    message: 'Demo Request Created. Id:' + demoRequest.srNo,
                    duration: 2000,
                    color: 'success',
                }).then((tost) => {
                    this.updateReceiptBook(receiptBook);
                    tost.present();
                    this.router.navigate(['/salespipeline/demorequests']);
                });
            });
        });
    }
    addMachine() {
        let mchdetails = this.form.get('machineDetails');
        mchdetails.push(this.createMachineDetail());
    }
    deleteMachine(index) {
        let mchdetails = this.form.get('machineDetails');
        mchdetails.removeAt(index);
    }
    addMaterial() {
        let matdetails = this.form.get('materialDetails');
        matdetails.push(this.createMaterialDetail());
    }
    deleteMaterial(index) {
        let matdetails = this.form.get('materialDetails');
        matdetails.removeAt(index);
    }
    loadMachineDetails() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.machinehsncodes = yield this.divisionService.getMachineHSNCodes();
            this.machineDetail = yield this.divisionService.getMachineDetailList();
            this.machines = this.machineDetail.filter(item => item.group == 0).sort((a, b) => a.srno - b.srno).map(item => item.name);
            this.machineType = this.machineDetail.filter(item => item.group == 1).sort((a, b) => a.srno - b.srno).map(item => item.name);
            this.machineCategory = this.machineDetail.filter(item => item.group == 2).sort((a, b) => a.srno - b.srno).map(item => item.name);
            return true;
        });
    }
    loadStockDetails() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.stockDetail = yield this.divisionService.getStock();
            this.stockCategory = this.stockDetail.map(item => item.category).filter((value, index, self) => self.indexOf(value) === index).sort();
            return true;
        });
    }
    loadInstallKitDetails() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.installkit = yield this.divisionService.getInstallKits();
            this.installkititems = this.installkit.map(item => item.item).sort();
            return true;
        });
    }
    loadBranches() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.branches = yield this.divisionService.getBranches();
            return true;
        });
    }
    onMachineChange(event, element) {
        if (!event.target.value)
            return;
        let ref = this.machineDetail.filter(item => item.name == event.target.value)[0].name;
        element.controls['volumeType'].reset();
        this.machineCategory = [];
        this.machineCategory = this.machineDetail.filter(item => item.ref == ref && item.group == 2).sort((a, b) => a.srno - b.srno).map(item => item.name);
        if (ref == "FM" || ref == "Mtl(kg/mth)") {
            element.controls['volumeType'].patchValue("Not Applicable", { emitEvent: false });
        }
        let hsncodes = this.machinehsncodes.filter(x => x.name == ref);
        if ((hsncodes === null || hsncodes === void 0 ? void 0 : hsncodes.length) > 0) {
            element.controls['machinehsnNo'].patchValue(hsncodes[0].hsncode, { emitEvent: false });
        }
        else {
            element.controls['machinehsnNo'].patchValue(null, { emitEvent: false });
        }
    }
    onMaterialChange(event, element) {
        if (!event.target.value)
            return;
        let ref = this.stockDetail.filter(item => item.category == event.target.value)[0].category;
        element.controls['item'].reset();
        this.stockType = [];
        element.controls['uom'].patchValue(null, { emitEvent: false });
        element.controls['hsnNo'].patchValue(null, { emitEvent: false });
        element.controls['gst'].patchValue(null, { emitEvent: false });
        this.stockType = this.stockDetail.filter(item => item.category == ref).map(item => item.item).sort();
    }
    onMaterialTypeChange(event, element) {
        if (!event.target.value)
            return;
        let ref = this.stockDetail.filter(item => item.item == event.target.value)[0];
        element.controls['uom'].patchValue(ref.uom, { emitEvent: false });
        element.controls['hsnNo'].patchValue(ref.hsnNo, { emitEvent: false });
        element.controls['gst'].patchValue(this.perPipe.transform(ref.gst), { emitEvent: false });
    }
    updateReceiptBook(receipt) {
        this.salespiplineService.addupdateReceiptBook(receipt, receipt.id == null ? false : true).subscribe();
    }
    padLeadingZeros(num, size) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            var s = num + '';
            while (s.length < size)
                s = '0' + s;
            return yield s;
        });
    }
};
DemoRequestPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: _salespipeline_service__WEBPACK_IMPORTED_MODULE_9__["SalespipelineService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] },
    { type: src_app_services_demo_request_service__WEBPACK_IMPORTED_MODULE_7__["DemoRequestService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: src_app_services_division_service__WEBPACK_IMPORTED_MODULE_10__["DivisionService"] }
];
DemoRequestPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-demo-request',
        template: _raw_loader_demo_request_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_demo_request_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], DemoRequestPage);



/***/ }),

/***/ "y8pr":
/*!***************************************************************************!*\
  !*** ./src/app/salespipeline/demo-request/demo-request-routing.module.ts ***!
  \***************************************************************************/
/*! exports provided: DemoRequestPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoRequestPageRoutingModule", function() { return DemoRequestPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _demo_request_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./demo-request.page */ "WmQI");




const routes = [
    {
        path: '',
        component: _demo_request_page__WEBPACK_IMPORTED_MODULE_3__["DemoRequestPage"]
    }
];
let DemoRequestPageRoutingModule = class DemoRequestPageRoutingModule {
};
DemoRequestPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], DemoRequestPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=demo-request-demo-request-module.js.map