(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["demo-request-detail-demo-request-detail-module"],{

/***/ "Ucyt":
/*!***********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/salespipeline/demo-request-detail/demo-request-detail.page.html ***!
  \***********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref=\"/salespipeline\">\n      </ion-back-button>\n      <ion-title>Demo Requisition Form</ion-title>\n      <ion-button [routerLink]=\"['/','salespipeline','editdemorequest',demoId]\"  [disabled]=\"!isLoading && !(demoRequest.reqStatus=='Demo Request Created' || demoRequest.reqStatus=='Rejected'?true:false)\">\n        <ion-icon name=\"create\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n    <ion-grid *ngIf=\"!isLoading\">\n    <div class=\"section\">\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <span style=\"font-size:13px\">Organization</span>\n          <ion-item>\n            <h6 class=\"label\">Client : </h6>\n            <h6>{{demoRequest.orgName}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <h6 class=\"label\">Client Status : </h6>\n            <h6>{{demoRequest.orgStatus}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n    </div>\n    <div class=\"section\">\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <span style=\"font-size:13px\">Address of the Organization</span>\n          <ion-item>\n            <ion-label>{{demoRequest.address}}</ion-label>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"3\" offset-sm=\"3\">\n          <ion-item>\n            <h6 class=\"label\">Location:</h6>\n            <h6>{{demoRequest.addLocation}}</h6>\n          </ion-item>\n      </ion-col>\n      <ion-col size-sm=\"3\" offset-sm=\"3\">\n        <ion-item>\n          <h6 class=\"label\">Pin Code : </h6>\n          <h6>{{demoRequest.addPincode}}</h6>\n        </ion-item>\n    </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <h6  class=\"label\">State : </h6>\n            <h6>{{demoRequest.addState}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n    </div>\n\n    <div class=\"section\">\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <span style=\"font-size:13px\">Contact Details</span>\n          <ion-item>\n            <h6>{{demoRequest.conName}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"3\" offset-sm=\"3\">\n          <ion-item>\n            <h6  class=\"label\">Mobile No : </h6>\n            <h6>{{demoRequest.conMobile}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <h6  class=\"label\">Email : </h6>\n            <h6>{{demoRequest.conEmail}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n    </div>\n\n    <div class=\"section\">\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <span style=\"font-size:13px\">Machine Details</span>\n          <div *ngFor=\"let item of demoRequest.machineDetails\">\n            <div style=\"border: 1px solid #A04000;\">\n          <ion-item>\n            <h6 class=\"label\">Machine: </h6>\n            <h6>{{item['machineName']}}</h6>\n          </ion-item>\n          <ion-item>\n            <h6 class=\"label\">Type:</h6>\n            <h6> {{item['machineType']}}</h6>\n          </ion-item>\n          <ion-item>\n            <h6 class=\"label\">Category:</h6>\n            <h6>{{item['volumeType']}}</h6>\n          </ion-item>\n          <ion-item>\n            <h6 class=\"label\">Count:</h6>\n            <h6>{{item['machineCount']}}</h6>\n          </ion-item>\n          <ion-item>\n            <h6 class=\"label\">Serial No:</h6>\n            <h6>{{item['machinesrno']}}</h6>\n          </ion-item>\n          <ion-item>\n            <h6 class=\"label\">HSN No:</h6>\n            <h6>{{item['machinehsnNo']}}</h6>\n          </ion-item>\n          <ion-item>\n            <h6 class=\"label\">Rate:</h6>\n            <h6>{{item['machinerate']}}</h6>\n          </ion-item>\n        </div>\n        </div>\n      </ion-col>\n      </ion-row>\n    </div>\n\n\n    <div class=\"section\">\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <span style=\"font-size:13px\">Accessories</span>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"3\" offset-sm=\"3\">\n          <ion-item>\n            <h6  class=\"label\">Installation/Demo Kit : </h6>\n            <h6>{{demoRequest.accInstallation}}</h6>\n          </ion-item>\n      </ion-col>\n      <ion-col size-sm=\"3\" offset-sm=\"3\">\n        <ion-item>\n          <h6  class=\"label\">Other Accessories : </h6>\n          <h6>{{demoRequest.accOther}}</h6>\n        </ion-item>\n    </ion-col>\n      </ion-row>\n    </div>\n\n\n    <div class=\"section\">\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <span style=\"font-size:13px\">Terms of Installation</span>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n\n      <ion-col size-sm=\"3\" offset-sm=\"3\">\n        <ion-item>\n          <h6  class=\"label\">Demo : </h6>\n          <h6>{{demoRequest.instDemo}}</h6>\n        </ion-item>\n    </ion-col>\n      </ion-row>\n    </div>\n\n    <div class=\"section\">\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <span style=\"font-size:13px\">Date</span>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <h6  class=\"label\">DC Date : </h6>\n            <h6>{{demoRequest.dateDC==null?getTimeStampDate(demoRequest.createdOn):getDate(demoRequest.dateDC)}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <h6  class=\"label\">Date of Delivery : </h6>\n            <h6>{{getDate(demoRequest.dateDelivery)}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <h6  class=\"label\">Start Date of Demo : </h6>\n            <h6>{{getDate(demoRequest.dateDemo)}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <h6  class=\"label\">End Date of Demo : </h6>\n            <h6>{{getDate(demoRequest.dateEndDemo)}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <h6  class=\"label\">Date of Pickup : </h6>\n            <h6>{{getDate(demoRequest.datePickup)}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n    </div>\n\n    <div class=\"section\">\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <span style=\"font-size:13px\">Statutory Detail</span>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <h6  class=\"label\">Tax Type : </h6>\n            <h6>{{demoRequest.taxType}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <h6  class=\"label\">GST No : </h6>\n            <h6>{{demoRequest.satGSTNo}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <h6  class=\"label\">SEZ : </h6>\n            <h6>{{demoRequest.satSEZ}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <h6  class=\"label\">Branch : </h6>\n            <h6>{{demoRequest.satBranch}}</h6>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n    </div>\n\n    <div class=\"section\">\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <span style=\"font-size:13px\">Details of Consumption</span>\n      </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"3\" offset-sm=\"3\">\n          <ion-item>\n            <h6  class=\"label\">No.Employee :\n            </h6>\n            <h6>{{demoRequest.cnsNoEmp}}</h6>\n          </ion-item>\n      </ion-col>\n      <ion-col size-sm=\"3\" offset-sm=\"3\">\n        <ion-item>\n          <h6  class=\"label\">No.of Cups /day : </h6>\n          <h6>{{demoRequest.cnsNoCups}}</h6>\n        </ion-item>\n    </ion-col>\n      </ion-row>\n    </div>\n\n\n    <div class=\"section\">\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <span style=\"font-size:13px\">Material Details</span>\n          <div *ngFor=\"let item of demoRequest.materialDetails\">\n            <div style=\"border: 1px solid #A04000;\">\n          <ion-item>\n            <h6 class=\"label\">Category:</h6>\n            <h6> {{item['category']}}</h6>\n          </ion-item>\n          <ion-item>\n            <h6 class=\"label\">Type:</h6>\n            <h6>{{item['item']}}</h6>\n          </ion-item>\n          <ion-item>\n            <h6 class=\"label\">UOM:</h6>\n            <h6> {{item['uom']}}</h6>\n          </ion-item>\n          <ion-item>\n            <h6 class=\"label\">HSNNo:</h6>\n            <h6>{{item['hsnNo']}}</h6>\n          </ion-item>\n          <ion-item>\n            <h6 class=\"label\">GST:</h6>\n            <h6>{{item['gst']}}</h6>\n          </ion-item>\n          <ion-item>\n            <h6 class=\"label\">Qty:</h6>\n            <h6>{{item['qty']}}</h6>\n          </ion-item>\n          <ion-item>\n            <h6 class=\"label\">Rate (Applicable for SEZ only):</h6>\n            <h6>{{item['rate']}}</h6>\n          </ion-item>\n        </div>\n        </div>\n      </ion-col>\n      </ion-row>\n    </div>\n\n    </ion-grid>\n\n</ion-content>\n");

/***/ }),

/***/ "hCoH":
/*!*******************************************************************************!*\
  !*** ./src/app/salespipeline/demo-request-detail/demo-request-detail.page.ts ***!
  \*******************************************************************************/
/*! exports provided: DemoRequestDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoRequestDetailPage", function() { return DemoRequestDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_demo_request_detail_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./demo-request-detail.page.html */ "Ucyt");
/* harmony import */ var _demo_request_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./demo-request-detail.page.scss */ "w4Od");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_services_demo_request_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/demo-request.service */ "4ttV");
/* harmony import */ var _utilities_dataconverters__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../utilities/dataconverters */ "igNZ");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ "ofXK");









let DemoRequestDetailPage = class DemoRequestDetailPage {
    constructor(demoRequestService, datePipe, route, navCtrl) {
        this.demoRequestService = demoRequestService;
        this.datePipe = datePipe;
        this.route = route;
        this.navCtrl = navCtrl;
        this.isLoading = false;
    }
    ngOnInit() {
        this.route.paramMap.subscribe((paramMap) => {
            if (!paramMap.has('demoId')) {
                this.navCtrl.navigateBack('/salespipeline/demorequests');
                return;
            }
            this.demoId = paramMap.get('demoId');
            this.isLoading = true;
        });
    }
    ionViewWillEnter() {
        this.isLoading = true;
        this.demoRequestService.getDemoRequestById(this.demoId).subscribe((res) => {
            this.demoRequest = res;
            this.isLoading = false;
        });
    }
    getDate(date) {
        return Object(_utilities_dataconverters__WEBPACK_IMPORTED_MODULE_7__["convertTimestampToDate"])(date);
    }
    getTimeStampDate(date) {
        return this.datePipe.transform(new Date(Object(_utilities_dataconverters__WEBPACK_IMPORTED_MODULE_7__["convertTimeStampToDate"])(date)), 'dd-MMM-yy');
    }
};
DemoRequestDetailPage.ctorParameters = () => [
    { type: src_app_services_demo_request_service__WEBPACK_IMPORTED_MODULE_6__["DemoRequestService"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_8__["DatePipe"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] }
];
DemoRequestDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-demo-request-detail',
        template: _raw_loader_demo_request_detail_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_demo_request_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], DemoRequestDetailPage);



/***/ }),

/***/ "nfxM":
/*!*********************************************************************************!*\
  !*** ./src/app/salespipeline/demo-request-detail/demo-request-detail.module.ts ***!
  \*********************************************************************************/
/*! exports provided: DemoRequestDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoRequestDetailPageModule", function() { return DemoRequestDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _demo_request_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./demo-request-detail-routing.module */ "yv0E");
/* harmony import */ var _demo_request_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./demo-request-detail.page */ "hCoH");







let DemoRequestDetailPageModule = class DemoRequestDetailPageModule {
};
DemoRequestDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _demo_request_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["DemoRequestDetailPageRoutingModule"]
        ],
        providers: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"]
        ],
        declarations: [_demo_request_detail_page__WEBPACK_IMPORTED_MODULE_6__["DemoRequestDetailPage"]]
    })
], DemoRequestDetailPageModule);



/***/ }),

/***/ "w4Od":
/*!*********************************************************************************!*\
  !*** ./src/app/salespipeline/demo-request-detail/demo-request-detail.page.scss ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".section {\n  margin: 5px;\n  border: 2px solid #BA55D3;\n}\n\n.label {\n  color: #BA55D3;\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxkZW1vLXJlcXVlc3QtZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7RUFDQSx5QkFBQTtBQUNGOztBQUNBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7QUFFRiIsImZpbGUiOiJkZW1vLXJlcXVlc3QtZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zZWN0aW9ue1xyXG4gIG1hcmdpbjogNXB4O1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkICNCQTU1RDM7XHJcbn1cclxuLmxhYmVse1xyXG4gIGNvbG9yOiAjQkE1NUQzO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "yv0E":
/*!*****************************************************************************************!*\
  !*** ./src/app/salespipeline/demo-request-detail/demo-request-detail-routing.module.ts ***!
  \*****************************************************************************************/
/*! exports provided: DemoRequestDetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoRequestDetailPageRoutingModule", function() { return DemoRequestDetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _demo_request_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./demo-request-detail.page */ "hCoH");




const routes = [
    {
        path: '',
        component: _demo_request_detail_page__WEBPACK_IMPORTED_MODULE_3__["DemoRequestDetailPage"]
    }
];
let DemoRequestDetailPageRoutingModule = class DemoRequestDetailPageRoutingModule {
};
DemoRequestDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], DemoRequestDetailPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=demo-request-detail-demo-request-detail-module.js.map