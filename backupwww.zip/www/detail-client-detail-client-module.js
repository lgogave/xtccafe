(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["detail-client-detail-client-module"],{

/***/ "LpJM":
/*!*************************************************************!*\
  !*** ./src/app/clients/detail-client/detail-client.page.ts ***!
  \*************************************************************/
/*! exports provided: DetailClientPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailClientPage", function() { return DetailClientPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_detail_client_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./detail-client.page.html */ "sHDb");
/* harmony import */ var _detail_client_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./detail-client.page.scss */ "ctkA");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var _client_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../client.service */ "+RYs");









let DetailClientPage = class DetailClientPage {
    constructor(router, navCtrl, modelCtrl, clientService, route, actionSheetCtrl, loadingCtrl, alertCtrl, authService) {
        this.router = router;
        this.navCtrl = navCtrl;
        this.modelCtrl = modelCtrl;
        this.clientService = clientService;
        this.route = route;
        this.actionSheetCtrl = actionSheetCtrl;
        this.loadingCtrl = loadingCtrl;
        this.alertCtrl = alertCtrl;
        this.authService = authService;
        this.isLoading = false;
    }
    ngOnInit() {
        this.route.paramMap.subscribe(paramMap => {
            if (!paramMap.has('clientId')) {
                this.navCtrl.navigateBack('/clients');
                return;
            }
            this.clientId = paramMap.get('clientId');
            this.isLoading = true;
            let fetchedUserId;
            this.authService.userId.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["switchMap"])(userId => {
                if (!userId) {
                    throw new Error('User not found!');
                }
                fetchedUserId = userId;
                return this.clientService.getClient(paramMap.get('clientId'));
            })).subscribe(client => {
                this.client = client;
                this.isLoading = false;
            });
        }, error => {
            this.alertCtrl.create({
                header: "An error occured",
                message: "Client could not be load. Please try that later.",
                buttons: [{ text: 'Okay', handler: () => {
                            this.router.navigate(['/clients']);
                        }
                    }]
            }).then(alerEl => {
                alerEl.present();
            });
        });
    }
};
DetailClientPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _client_service__WEBPACK_IMPORTED_MODULE_8__["ClientService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ActionSheetController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"] }
];
DetailClientPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-detail-client',
        template: _raw_loader_detail_client_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_detail_client_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], DetailClientPage);



/***/ }),

/***/ "ctkA":
/*!***************************************************************!*\
  !*** ./src/app/clients/detail-client/detail-client.page.scss ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZXRhaWwtY2xpZW50LnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "eZdo":
/*!***************************************************************!*\
  !*** ./src/app/clients/detail-client/detail-client.module.ts ***!
  \***************************************************************/
/*! exports provided: DetailClientPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailClientPageModule", function() { return DetailClientPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _detail_client_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./detail-client-routing.module */ "wpiw");
/* harmony import */ var _detail_client_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./detail-client.page */ "LpJM");







let DetailClientPageModule = class DetailClientPageModule {
};
DetailClientPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _detail_client_routing_module__WEBPACK_IMPORTED_MODULE_5__["DetailClientPageRoutingModule"]
        ],
        declarations: [_detail_client_page__WEBPACK_IMPORTED_MODULE_6__["DetailClientPage"]]
    })
], DetailClientPageModule);



/***/ }),

/***/ "sHDb":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/clients/detail-client/detail-client.page.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref=\"/clients\">\n      </ion-back-button>\n      <ion-title><div class=\"ion-text-wrap\">{{isLoading?'Loading...':client.name}}</div></ion-title>\n      <ion-button [routerLink]=\"['/','clients','edit',clientId]\">\n        <ion-icon name=\"create\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div *ngIf=\"isLoading\" class=\"ion-text-center\">\n<ion-spinner color=\"primary\"></ion-spinner>\n  </div>\n  <ion-grid class=\"ion-no-padding\" *ngIf=\"!isLoading\">\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-list>\n          <ion-item>\n            <span>Division : {{client.divisions?.join(',')}}</span>\n          </ion-item>\n          <ion-item>\n            <span>GST Number: {{client.gstNumber}}</span>\n          </ion-item>\n          <ion-item>\n            <span>Client Type : {{client.clientTypes?.join(',')}}</span>\n          </ion-item>\n          <ion-item>\n            <span>Client Group: {{client.group}}</span>\n          </ion-item>\n          <ion-item>\n            <span>Contact Person : {{client.contactPerson}}</span>\n          </ion-item>\n          <ion-item>\n            <span>Contact Number : {{client.contactNumber}}</span>\n          </ion-item>\n          <ion-item>\n            <span>Email : {{client.email}}</span>\n          </ion-item>\n          <ion-item>\n            <span>Potential Nature : {{client.potentialNature}}</span>\n          </ion-item>\n          <ion-item>\n            <span>Employee Strength : {{client.employeeStrength}}</span>\n          </ion-item>\n\n          <ion-item>\n            <span>Account Owner : {{client.accountOwner}}</span>\n          </ion-item>\n\n          <ion-item>\n            <span>Country : {{client.country}}</span>\n          </ion-item>\n          <ion-item>\n            <span>Region : {{client.region}}</span>\n          </ion-item>\n          <ion-item>\n            <span>Sub Region : {{client.subRegion}}</span>\n          </ion-item>\n          <ion-item>\n            <span>State : {{client.state}}</span>\n          </ion-item>\n          <ion-item>\n            <span>City : {{client.city}}</span>\n          </ion-item>\n\n\n\n        </ion-list>\n      </ion-col>\n    </ion-row>\n\n  </ion-grid>\n\n\n</ion-content>\n");

/***/ }),

/***/ "wpiw":
/*!***********************************************************************!*\
  !*** ./src/app/clients/detail-client/detail-client-routing.module.ts ***!
  \***********************************************************************/
/*! exports provided: DetailClientPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailClientPageRoutingModule", function() { return DetailClientPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _detail_client_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./detail-client.page */ "LpJM");




const routes = [
    {
        path: '',
        component: _detail_client_page__WEBPACK_IMPORTED_MODULE_3__["DetailClientPage"]
    }
];
let DetailClientPageRoutingModule = class DetailClientPageRoutingModule {
};
DetailClientPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], DetailClientPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=detail-client-detail-client-module.js.map