(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["detail-sales-detail-sales-module"],{

/***/ "3/Fc":
/*!****************************************************************!*\
  !*** ./src/app/salespipeline/dc-popup/dc-popup.component.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkYy1wb3B1cC5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "5RWk":
/*!*****************************************************************!*\
  !*** ./src/app/salespipeline/detail-sales/detail-sales.page.ts ***!
  \*****************************************************************/
/*! exports provided: DetailSalesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailSalesPage", function() { return DetailSalesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_detail_sales_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./detail-sales.page.html */ "AnFL");
/* harmony import */ var _detail_sales_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./detail-sales.page.scss */ "TizF");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var _salespipeline_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../salespipeline.service */ "bL0d");
/* harmony import */ var _dc_popup_dc_popup_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../dc-popup/dc-popup.component */ "e+hD");











let DetailSalesPage = class DetailSalesPage {
    constructor(router, navCtrl, modelCtrl, salespipelineService, route, actionSheetCtrl, loadingCtrl, alertCtrl, authService, popoverCtrl) {
        this.router = router;
        this.navCtrl = navCtrl;
        this.modelCtrl = modelCtrl;
        this.salespipelineService = salespipelineService;
        this.route = route;
        this.actionSheetCtrl = actionSheetCtrl;
        this.loadingCtrl = loadingCtrl;
        this.alertCtrl = alertCtrl;
        this.authService = authService;
        this.popoverCtrl = popoverCtrl;
        this.isLoading = false;
    }
    ngOnInit() {
        this.route.paramMap.subscribe((paramMap) => {
            if (!paramMap.has('salesId')) {
                this.navCtrl.navigateBack('/salespipeline');
                return;
            }
            this.salesId = paramMap.get('salesId');
            this.isLoading = true;
            let fetchedUserId;
            this.authService.userId
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["switchMap"])((userId) => {
                if (!userId) {
                    throw new Error('User not found!');
                }
                fetchedUserId = userId;
                return this.salespipelineService.getClientSalesPipeline(paramMap.get('salesId'));
            }))
                .subscribe((sales) => {
                this.salespipeline = sales;
                this.isLoading = false;
            });
        }, (error) => {
            this.alertCtrl
                .create({
                header: 'An error occured',
                message: 'Salespipeline could not be load. Please try that later.',
                buttons: [
                    {
                        text: 'Okay',
                        handler: () => {
                            this.router.navigate(['/salespipeline']);
                        },
                    },
                ],
            })
                .then((alerEl) => {
                alerEl.present();
            });
        });
    }
    convertTimestampToDate(date) {
        return this.salespipelineService.convertTimeStampToDate(date);
    }
    presentPopover(ev, nsalesId, nlocationId) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const popover = yield this.popoverCtrl.create({
                component: _dc_popup_dc_popup_component__WEBPACK_IMPORTED_MODULE_9__["DcPopupComponent"],
                event: ev,
                translucent: true,
                // mode:'ios',
                componentProps: { salesId: nsalesId, locationId: nlocationId }
            });
            yield popover.present();
            yield popover.onDidDismiss();
        });
    }
};
DetailSalesPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _salespipeline_service__WEBPACK_IMPORTED_MODULE_8__["SalespipelineService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ActionSheetController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["PopoverController"] }
];
DetailSalesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-detail-sales',
        template: _raw_loader_detail_sales_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_detail_sales_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], DetailSalesPage);



/***/ }),

/***/ "AnFL":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/salespipeline/detail-sales/detail-sales.page.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref=\"/salespipeline\">\n      </ion-back-button>\n      <ion-title text-wrap><div class=\"ion-text-wrap\">{{isLoading?'Loading...':salespipeline.client}}</div></ion-title>\n      <ion-button  [routerLink]=\"['/','salespipeline','edit',salesId]\">\n        <ion-icon name=\"create\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div *ngIf=\"isLoading\" class=\"ion-text-center\">\n<ion-spinner color=\"primary\"></ion-spinner>\n  </div>\n  <ion-grid class=\"ion-no-padding\" *ngIf=\"!isLoading\">\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-card>\n          <ion-card-content>\n            <ion-item>\n              <ion-icon name=\"cafe-outline\" size=\"medium\" style=\"color: #E91E63;padding-right: 5px;\"></ion-icon>\n              <ion-label style=\"font-size: 15px;\">\n                 <b> Client Group : </b>{{salespipeline.group}}</ion-label>\n            </ion-item>\n            <ion-item class=\"item item-text-wrap\">\n              <ion-icon name=\"create-outline\"  size=\"medium\" style=\"color: #E91E63;padding-right: 5px;\"></ion-icon>\n              <ion-label style=\"font-size: 15px;\"  text-wrap>\n                 <b> Comment : </b>{{salespipeline.comment}}</ion-label>\n                 <button [routerLink]=\"['/','salespipeline','comments',salespipeline.id,salespipeline.client]\" style=\"color: #000033;border:none!important; outline:none!important;background: #ffce00;padding:5px;\">More...</button>\n            </ion-item>\n            <ion-item >\n              <ion-icon name=\"cash-outline\"  size=\"medium\" style=\"color: #E91E63;padding-right: 5px;\"></ion-icon>\n              <ion-label style=\"font-size: 15px;\" >\n                 <b> Amount : </b>{{salespipeline.amount}}</ion-label>\n            </ion-item>\n\n\n            <ion-row class=\"card-tab\" style=\"background:#3F51B5\" *ngFor=\"let location of salespipeline.locations;let i = index;\">\n              <ion-col size-sm=\"6\" offset-sm=\"3\">\n                <ion-item color=\"success\" style=\"padding-right: 5px;\">\n                  <ion-icon name=\"location-outline\"></ion-icon>\n                  <ion-label><b> City : </b> {{location.city}} </ion-label>\n                 </ion-item>\n                 <ion-item>Branch:{{location.branchcity}}</ion-item>\n                 <ion-item>Consumable INV Applicable:{{location.isConsumable}}</ion-item>\n                 <ion-item>Rental INV Applicable:{{location.isRental}}</ion-item>\n                 <ion-item>Cap for Rental Invoice:{{location.renLimit}}</ion-item>\n                 <ion-item>Managed By:{{location.accowner}}</ion-item>\n                 <ion-item [style.display]=\"location.currentStatus=='S7 : Win' ? 'block' : 'none'\">\n                  <button [routerLink]=\"['/','salespipeline','clientbilling',salespipeline.id,location.id]\" style=\"color: #000033;border:none!important; outline:none!important;background: #ffce00;padding:5px;\">Billing Rates</button>\n                  <!-- <button [routerLink]=\"['/','salespipeline','deliverychallan',salespipeline.id,location.id]\" style=\"color: #000033;border:none!important; outline:none!important;background: #ffce00;padding:5px;margin: 12px;\">Create DC</button> -->\n                  <button (click)=\"presentPopover($event,salespipeline.id,location.id)\" style=\"color: #000033;border:none!important; outline:none!important;background: #ffce00;padding:5px;margin: 12px;\">Create DC</button>\n                  <button [routerLink]=\"['/','salespipeline','deliverychallanlist',salespipeline.clientId,location.id]\" style=\"color: #000033;border:none!important; outline:none!important;background: #ffce00;padding:5px;\">View DC</button>\n                  <button [routerLink]=\"['/','salespipeline','invoicelist',location.id]\" style=\"color: #000033;border:none!important; outline:none!important;background: #ffce00;padding:5px;margin: 12px;\">View Invoice</button>\n                </ion-item>\n\n                <ion-item>\n                  <button [routerLink]=\"['/','salespipeline','demorequest',salespipeline.id,i]\" style=\"color: #000033;border:none!important; outline:none!important;background: #BA55D3;padding:10px;margin: 12px;color:#fff;\">Create Demo Request</button>\n                </ion-item>\n                 <ion-item>\n                  <ion-label text-wrap><b> Billing Address : </b> {{location.address}} </ion-label>\n                 </ion-item>\n\n                 <ion-item>\n                  <ion-label text-wrap><b> Installed at : </b> {{location.installAt}} </ion-label>\n                 </ion-item>\n\n                 <ion-item>\n                  <ion-label text-wrap><b> Installed address : </b> {{location.installAddress}} </ion-label>\n                 </ion-item>\n\n\n\n                 <ion-item>\n                  <ion-label><b> Closure Date : </b>  {{convertTimestampToDate(location.closureDate) | date:'mediumDate'}} </ion-label>\n                 </ion-item>\n                 <ion-item >\n                  <ion-icon name=\"cash-outline\"  size=\"medium\" style=\"color: #E91E63;padding-right: 5px;\"></ion-icon>\n                  <ion-label style=\"font-size: 15px;\">\n                     <b> Amount : </b>{{location.amount}}</ion-label>\n                </ion-item>\n\n                <ion-row class=\"card-tab\" style=\"background:#3F51B5\" *ngFor=\"let machine of location.machines; let j = index;\">\n                  <ion-col size-sm=\"6\" offset-sm=\"3\">\n                    <ion-item color=\"danger\">\n                      <ion-icon name=\"file-tray-stacked-outline\" style=\"padding-right: 5px;\"></ion-icon>\n                      <ion-label><b> Machine : </b> {{machine.machineName}} </ion-label>\n                     </ion-item>\n\n                     <ion-item>\n\n                      <ion-label><b> Machine Type : </b> {{machine.machineType}} </ion-label>\n                     </ion-item>\n\n                     <ion-item>\n\n                      <ion-label><b> Machine Category : </b> {{machine.machineCategory}} </ion-label>\n                     </ion-item>\n                     <ion-item>\n                      <ion-label><b> Count : </b> {{machine.machineCount}} </ion-label>\n                     </ion-item>\n                     <ion-item>\n                      <ion-label><b> Serial No : </b> {{machine.machineSrNo}} </ion-label>\n                     </ion-item>\n                     <ion-item>\n                      <ion-label><b> HSNCode : </b> {{machine.machinehsncode}} </ion-label>\n                     </ion-item>\n\n                     <ion-item>\n                      <ion-label><b> Rate : </b> {{machine.rate}} </ion-label>\n                     </ion-item>\n                     <ion-item>\n                      <ion-label><b> Machine Type : </b> {{machine.machineType}} </ion-label>\n                     </ion-item>\n                     <ion-item>\n                      <ion-label><b> Confidence Level : </b> {{machine.conflevel}}% </ion-label>\n                     </ion-item>\n\n                     <ion-item >\n                      <ion-icon name=\"cash-outline\"  size=\"medium\" style=\"color: #E91E63;padding-right: 5px;\"></ion-icon>\n                      <ion-label style=\"font-size: 15px;\">\n                         <b> Amount : </b>{{machine.amount}}</ion-label>\n                    </ion-item>\n\n                    <ion-item color=\"secondary\">\n                      <ion-label><b> Machine Rent : </b> {{machine.mchRent}} </ion-label>\n                     </ion-item>\n                     <ion-item color=\"secondary\">\n                      <ion-label><b> Consumable CAP : </b> {{machine.consumableCap}} </ion-label>\n                     </ion-item>\n                     <ion-item color=\"secondary\">\n                      <ion-label><b> Installation Charges : </b> {{machine.mchInstCharges}} </ion-label>\n                     </ion-item>\n                     <ion-item color=\"secondary\">\n                      <ion-label><b> Security Deposite : </b> {{machine.mchSecDeposite}} </ion-label>\n                     </ion-item>\n                  </ion-col>\n                </ion-row>\n              </ion-col>\n            </ion-row>\n          </ion-card-content>\n        </ion-card>\n        <div></div>\n\n        </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n</ion-content>\n");

/***/ }),

/***/ "TizF":
/*!*******************************************************************!*\
  !*** ./src/app/salespipeline/detail-sales/detail-sales.page.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".componentWrapper {\n  border: solid cadetblue;\n  border-radius: 40px;\n  padding: 15px 10px 10px 10px;\n  margin-top: 20px;\n  width: 95%;\n}\n\n.componentWrapper .header {\n  position: absolute;\n  margin-top: -25px;\n  margin-left: 10px;\n  color: white;\n  background: cadetblue;\n  border-radius: 10px;\n  padding: 2px 10px;\n}\n\n.cardclose {\n  position: absolute;\n  margin-top: -5px;\n  margin-left: 250px;\n  background: white;\n  border-radius: 5px;\n  margin-bottom: 30px;\n}\n\n.close-icon-info {\n  display: block;\n  box-sizing: border-box;\n  width: 20px;\n  height: 20px;\n  border-width: 3px;\n  border-style: solid;\n  border-color: #3F51B5;\n  border-radius: 100%;\n  background: -webkit-linear-gradient(-45deg, transparent 0%, transparent 46%, white 46%, white 56%, transparent 56%, transparent 100%), -webkit-linear-gradient(45deg, transparent 0%, transparent 46%, white 46%, white 56%, transparent 56%, transparent 100%);\n  background-color: #3F51B5;\n  box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.5);\n  transition: all 0.3s ease;\n  margin: 8px;\n}\n\n.close-icon-accent {\n  display: block;\n  box-sizing: border-box;\n  width: 20px;\n  height: 20px;\n  border-width: 3px;\n  border-style: solid;\n  border-color: #e91e63;\n  border-radius: 100%;\n  background: -webkit-linear-gradient(-45deg, transparent 0%, transparent 46%, white 46%, white 56%, transparent 56%, transparent 100%), -webkit-linear-gradient(45deg, transparent 0%, transparent 46%, white 46%, white 56%, transparent 56%, transparent 100%);\n  background-color: #e91e63;\n  box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.5);\n  transition: all 0.3s ease;\n}\n\n.card-tab {\n  margin-inline: 0px;\n}\n\n.card-content {\n  padding: 0px;\n}\n\n.ionitem1 {\n  background: #3F51B5;\n}\n\n.error-label {\n  font-size: small;\n  color: #fff;\n}\n\n.container {\n  width: 100%;\n  text-align: center;\n}\n\n.left {\n  float: left;\n  height: 30px;\n  margin: 5px;\n}\n\n.center {\n  display: inline-block;\n  height: 30px;\n  margin: 5px;\n}\n\n.right {\n  float: right;\n  height: 30px;\n  margin: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxkZXRhaWwtc2FsZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLDRCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUFFRjs7QUFBQTtFQUVFLGNBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSwrUEFBQTtFQUNBLHlCQUFBO0VBQ0EsOENBQUE7RUFDQSx5QkFBQTtFQUNBLFdBQUE7QUFFRjs7QUFBQTtFQUVFLGNBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSwrUEFBQTtFQUNBLHlCQUFBO0VBQ0EsOENBQUE7RUFDQSx5QkFBQTtBQUVGOztBQUVDO0VBQ0Msa0JBQUE7QUFDRjs7QUFDQztFQUNDLFlBQUE7QUFFRjs7QUFBQztFQUNELG1CQUFBO0FBR0E7O0FBQUE7RUFDRSxnQkFBQTtFQUFpQixXQUFBO0FBSW5COztBQURBO0VBQ0UsV0FBQTtFQUNBLGtCQUFBO0FBSUY7O0FBREE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFJRjs7QUFEQTtFQUNFLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFJRjs7QUFEQTtFQUNFLFlBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQUlGIiwiZmlsZSI6ImRldGFpbC1zYWxlcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29tcG9uZW50V3JhcHBlciB7XHJcbiAgYm9yZGVyOiBzb2xpZCBjYWRldGJsdWU7XHJcbiAgYm9yZGVyLXJhZGl1czogNDBweDtcclxuICBwYWRkaW5nOiAxNXB4IDEwcHggMTBweCAxMHB4O1xyXG4gIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgd2lkdGg6IDk1JTtcclxufVxyXG5cclxuLmNvbXBvbmVudFdyYXBwZXIgLmhlYWRlciB7XHJcbiAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgbWFyZ2luLXRvcDotMjVweDtcclxuICBtYXJnaW4tbGVmdDoxMHB4O1xyXG4gIGNvbG9yOndoaXRlO1xyXG4gIGJhY2tncm91bmQ6Y2FkZXRibHVlO1xyXG4gIGJvcmRlci1yYWRpdXM6MTBweDtcclxuICBwYWRkaW5nOjJweCAxMHB4O1xyXG59XHJcbi5jYXJkY2xvc2Uge1xyXG4gIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gIG1hcmdpbi10b3A6LTVweDtcclxuICBtYXJnaW4tbGVmdDoyNTBweDtcclxuICBiYWNrZ3JvdW5kOndoaXRlO1xyXG4gIGJvcmRlci1yYWRpdXM6NXB4O1xyXG4gIG1hcmdpbi1ib3R0b206MzBweDtcclxufVxyXG4uY2xvc2UtaWNvbi1pbmZvXHJcbntcclxuICBkaXNwbGF5OmJsb2NrO1xyXG4gIGJveC1zaXppbmc6Ym9yZGVyLWJveDtcclxuICB3aWR0aDoyMHB4O1xyXG4gIGhlaWdodDoyMHB4O1xyXG4gIGJvcmRlci13aWR0aDozcHg7XHJcbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICBib3JkZXItY29sb3I6IzNGNTFCNTtcclxuICBib3JkZXItcmFkaXVzOjEwMCU7XHJcbiAgYmFja2dyb3VuZDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQoLTQ1ZGVnLCB0cmFuc3BhcmVudCAwJSwgdHJhbnNwYXJlbnQgNDYlLCB3aGl0ZSA0NiUsICB3aGl0ZSA1NiUsdHJhbnNwYXJlbnQgNTYlLCB0cmFuc3BhcmVudCAxMDAlKSwgLXdlYmtpdC1saW5lYXItZ3JhZGllbnQoNDVkZWcsIHRyYW5zcGFyZW50IDAlLCB0cmFuc3BhcmVudCA0NiUsIHdoaXRlIDQ2JSwgIHdoaXRlIDU2JSx0cmFuc3BhcmVudCA1NiUsIHRyYW5zcGFyZW50IDEwMCUpO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IzNGNTFCNTtcclxuICBib3gtc2hhZG93OjBweCAwcHggNXB4IDJweCByZ2JhKDAsMCwwLDAuNSk7XHJcbiAgdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZTtcclxuICBtYXJnaW46IDhweDtcclxufVxyXG4uY2xvc2UtaWNvbi1hY2NlbnRcclxue1xyXG4gIGRpc3BsYXk6YmxvY2s7XHJcbiAgYm94LXNpemluZzpib3JkZXItYm94O1xyXG4gIHdpZHRoOjIwcHg7XHJcbiAgaGVpZ2h0OjIwcHg7XHJcbiAgYm9yZGVyLXdpZHRoOjNweDtcclxuICBib3JkZXItc3R5bGU6IHNvbGlkO1xyXG4gIGJvcmRlci1jb2xvcjojZTkxZTYzO1xyXG4gIGJvcmRlci1yYWRpdXM6MTAwJTtcclxuICBiYWNrZ3JvdW5kOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudCgtNDVkZWcsIHRyYW5zcGFyZW50IDAlLCB0cmFuc3BhcmVudCA0NiUsIHdoaXRlIDQ2JSwgIHdoaXRlIDU2JSx0cmFuc3BhcmVudCA1NiUsIHRyYW5zcGFyZW50IDEwMCUpLCAtd2Via2l0LWxpbmVhci1ncmFkaWVudCg0NWRlZywgdHJhbnNwYXJlbnQgMCUsIHRyYW5zcGFyZW50IDQ2JSwgd2hpdGUgNDYlLCAgd2hpdGUgNTYlLHRyYW5zcGFyZW50IDU2JSwgdHJhbnNwYXJlbnQgMTAwJSk7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjojZTkxZTYzO1xyXG4gIGJveC1zaGFkb3c6MHB4IDBweCA1cHggMnB4IHJnYmEoMCwwLDAsMC41KTtcclxuICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlO1xyXG59XHJcblxyXG5cclxuIC5jYXJkLXRhYntcclxuICBtYXJnaW4taW5saW5lOiAwcHg7XHJcbiB9XHJcbiAuY2FyZC1jb250ZW50e1xyXG4gIHBhZGRpbmc6IDBweDtcclxuIH1cclxuIC5pb25pdGVtMXtcclxuYmFja2dyb3VuZDogIzNGNTFCNTtcclxuIH1cclxuXHJcbi5lcnJvci1sYWJlbHtcclxuICBmb250LXNpemU6IHNtYWxsO2NvbG9yOiNmZmZcclxufVxyXG5cclxuLmNvbnRhaW5lciB7XHJcbiAgd2lkdGg6MTAwJTtcclxuICB0ZXh0LWFsaWduOmNlbnRlcjtcclxufVxyXG5cclxuLmxlZnQge1xyXG4gIGZsb2F0OmxlZnQ7XHJcbiAgaGVpZ2h0OiAzMHB4O1xyXG4gIG1hcmdpbjogNXB4O1xyXG59XHJcblxyXG4uY2VudGVyIHtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgaGVpZ2h0OiAzMHB4O1xyXG4gIG1hcmdpbjogNXB4O1xyXG59XHJcblxyXG4ucmlnaHQge1xyXG4gIGZsb2F0OnJpZ2h0O1xyXG4gIGhlaWdodDogMzBweDtcclxuICBtYXJnaW46IDVweDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "bkVY":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/salespipeline/dc-popup/dc-popup.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item detail (click)=\"createConsumable()\">\n          <ion-label>\n            Create Consumable DC\n          </ion-label>\n        </ion-item>\n        <ion-item detail (click)=\"createInstallation()\">\n          <ion-label>\n            Create Installation DC\n          </ion-label>\n        </ion-item>\n        </ion-col>\n        </ion-row>\n        </ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "e+hD":
/*!**************************************************************!*\
  !*** ./src/app/salespipeline/dc-popup/dc-popup.component.ts ***!
  \**************************************************************/
/*! exports provided: DcPopupComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DcPopupComponent", function() { return DcPopupComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_dc_popup_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./dc-popup.component.html */ "bkVY");
/* harmony import */ var _dc_popup_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dc-popup.component.scss */ "3/Fc");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");





let DcPopupComponent = class DcPopupComponent {
    constructor(navCtrl, popoverCtrl) {
        this.navCtrl = navCtrl;
        this.popoverCtrl = popoverCtrl;
    }
    ngOnInit() { }
    createConsumable() {
        this.popoverCtrl.dismiss();
        this.navCtrl.navigateForward('/salespipeline/deliverychallan/' + this.salesId + '/' + this.locationId);
    }
    createInstallation() {
        this.popoverCtrl.dismiss();
        this.navCtrl.navigateForward('/salespipeline/dcinstallation/' + this.salesId + '/' + this.locationId);
    }
};
DcPopupComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["PopoverController"] }
];
DcPopupComponent.propDecorators = {
    salesId: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    locationId: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
DcPopupComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-dc-popup',
        template: _raw_loader_dc_popup_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_dc_popup_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], DcPopupComponent);



/***/ }),

/***/ "erD5":
/*!*******************************************************************!*\
  !*** ./src/app/salespipeline/detail-sales/detail-sales.module.ts ***!
  \*******************************************************************/
/*! exports provided: DetailSalesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailSalesPageModule", function() { return DetailSalesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _detail_sales_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./detail-sales-routing.module */ "oT0F");
/* harmony import */ var _detail_sales_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./detail-sales.page */ "5RWk");
/* harmony import */ var _dc_popup_dc_popup_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../dc-popup/dc-popup.component */ "e+hD");








let DetailSalesPageModule = class DetailSalesPageModule {
};
DetailSalesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _detail_sales_routing_module__WEBPACK_IMPORTED_MODULE_5__["DetailSalesPageRoutingModule"]
        ],
        declarations: [_detail_sales_page__WEBPACK_IMPORTED_MODULE_6__["DetailSalesPage"], _dc_popup_dc_popup_component__WEBPACK_IMPORTED_MODULE_7__["DcPopupComponent"]],
        entryComponents: [_dc_popup_dc_popup_component__WEBPACK_IMPORTED_MODULE_7__["DcPopupComponent"]]
    })
], DetailSalesPageModule);



/***/ }),

/***/ "oT0F":
/*!***************************************************************************!*\
  !*** ./src/app/salespipeline/detail-sales/detail-sales-routing.module.ts ***!
  \***************************************************************************/
/*! exports provided: DetailSalesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailSalesPageRoutingModule", function() { return DetailSalesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _detail_sales_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./detail-sales.page */ "5RWk");




const routes = [
    {
        path: '',
        component: _detail_sales_page__WEBPACK_IMPORTED_MODULE_3__["DetailSalesPage"]
    }
];
let DetailSalesPageRoutingModule = class DetailSalesPageRoutingModule {
};
DetailSalesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], DetailSalesPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=detail-sales-detail-sales-module.js.map