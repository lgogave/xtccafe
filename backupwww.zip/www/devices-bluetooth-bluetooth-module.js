(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["devices-bluetooth-bluetooth-module"],{

/***/ "I/IY":
/*!*******************************************************!*\
  !*** ./src/app/devices/bluetooth/bluetooth.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJibHVldG9vdGgucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "bRl7":
/*!******************************************************************!*\
  !*** ./node_modules/@ionic-native/bluetooth-serial/ngx/index.js ***!
  \******************************************************************/
/*! exports provided: BluetoothSerial */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BluetoothSerial", function() { return BluetoothSerial; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_native_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/core */ "C6fG");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "qCKp");





var BluetoothSerial = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(BluetoothSerial, _super);
    function BluetoothSerial() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BluetoothSerial.prototype.connect = function (macAddress_or_uuid) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "connect", { "platforms": ["Android", "iOS", "Windows Phone"], "observable": true, "clearFunction": "disconnect" }, arguments); };
    BluetoothSerial.prototype.connectInsecure = function (macAddress) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "connectInsecure", { "platforms": ["Android"], "observable": true, "clearFunction": "disconnect" }, arguments); };
    BluetoothSerial.prototype.disconnect = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "disconnect", {}, arguments); };
    BluetoothSerial.prototype.write = function (data) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "write", { "platforms": ["Android", "iOS", "Windows Phone"] }, arguments); };
    BluetoothSerial.prototype.available = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "available", { "platforms": ["Android", "iOS", "Windows Phone"] }, arguments); };
    BluetoothSerial.prototype.read = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "read", { "platforms": ["Android", "iOS", "Windows Phone"] }, arguments); };
    BluetoothSerial.prototype.readUntil = function (delimiter) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "readUntil", { "platforms": ["Android", "iOS", "Windows Phone"] }, arguments); };
    BluetoothSerial.prototype.subscribe = function (delimiter) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "subscribe", { "platforms": ["Android", "iOS", "Windows Phone"], "observable": true, "clearFunction": "unsubscribe" }, arguments); };
    BluetoothSerial.prototype.subscribeRawData = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "subscribeRawData", { "platforms": ["Android", "iOS", "Windows Phone"], "observable": true, "clearFunction": "unsubscribeRawData" }, arguments); };
    BluetoothSerial.prototype.clear = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "clear", { "platforms": ["Android", "iOS", "Windows Phone"] }, arguments); };
    BluetoothSerial.prototype.list = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "list", { "platforms": ["Android", "iOS", "Windows Phone"] }, arguments); };
    BluetoothSerial.prototype.isEnabled = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "isEnabled", { "platforms": ["Android", "iOS", "Windows Phone"] }, arguments); };
    BluetoothSerial.prototype.isConnected = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "isConnected", { "platforms": ["Android", "iOS", "Windows Phone"] }, arguments); };
    BluetoothSerial.prototype.readRSSI = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "readRSSI", { "platforms": ["Android", "iOS", "Windows Phone"] }, arguments); };
    BluetoothSerial.prototype.showBluetoothSettings = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "showBluetoothSettings", { "platforms": ["Android", "iOS", "Windows Phone"] }, arguments); };
    BluetoothSerial.prototype.enable = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "enable", { "platforms": ["Android", "iOS", "Windows Phone"] }, arguments); };
    BluetoothSerial.prototype.discoverUnpaired = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "discoverUnpaired", { "platforms": ["Android", "iOS", "Windows Phone"] }, arguments); };
    BluetoothSerial.prototype.setDeviceDiscoveredListener = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "setDeviceDiscoveredListener", { "platforms": ["Android", "iOS", "Windows Phone"], "observable": true, "clearFunction": "clearDeviceDiscoveredListener" }, arguments); };
    BluetoothSerial.prototype.setName = function (newName) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "setName", { "platforms": ["Android"], "sync": true }, arguments); };
    BluetoothSerial.prototype.setDiscoverable = function (discoverableDuration) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "setDiscoverable", { "platforms": ["Android"], "sync": true }, arguments); };
    BluetoothSerial.pluginName = "BluetoothSerial";
    BluetoothSerial.repo = "https://github.com/don/BluetoothSerial";
    BluetoothSerial.plugin = "cordova-plugin-bluetooth-serial";
    BluetoothSerial.pluginRef = "bluetoothSerial";
    BluetoothSerial.platforms = ["Android", "iOS", "Windows Phone 8"];
BluetoothSerial.ɵfac = function BluetoothSerial_Factory(t) { return ɵBluetoothSerial_BaseFactory(t || BluetoothSerial); };
BluetoothSerial.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: BluetoothSerial, factory: function (t) { return BluetoothSerial.ɵfac(t); } });
var ɵBluetoothSerial_BaseFactory = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetInheritedFactory"](BluetoothSerial);
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](BluetoothSerial, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"]
    }], null, null); })();
    return BluetoothSerial;
}(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["IonicNativePlugin"]));


//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9AaW9uaWMtbmF0aXZlL3BsdWdpbnMvYmx1ZXRvb3RoLXNlcmlhbC9uZ3gvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyw4QkFBc0MsTUFBTSxvQkFBb0IsQ0FBQztBQUN4RSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sTUFBTSxDQUFDOztBQUNsQztBQUcwQixJQWtDVyxtQ0FBaUI7QUFBQztBQUU5QjtBQUNzQztBQUFNLElBUW5FLGlDQUFPLGFBQUMsa0JBQTBCO0FBT2xDLElBT0EseUNBQWUsYUFBQyxVQUFrQjtBQVM5QixJQUFKLG9DQUFVO0FBS2lCLElBTzNCLCtCQUFLLGFBQUMsSUFBUztBQU1ILElBS1osbUNBQVM7QUFNbUMsSUFLNUMsOEJBQUk7QUFNTSxJQU1WLG1DQUFTLGFBQUMsU0FBaUI7QUFNZixJQVFaLG1DQUFTLGFBQUMsU0FBaUI7QUFRMUIsSUFLRCwwQ0FBZ0I7QUFTZSxJQUUvQiwrQkFBSztBQU9OLElBSUMsOEJBQUk7QUFNOEIsSUFLbEMsbUNBQVM7QUFNZ0MsSUFLekMscUNBQVc7QUFNaUIsSUFLNUIsa0NBQVE7QUFNb0IsSUFLNUIsK0NBQXFCO0FBUXRCLElBR0MsZ0NBQU07QUFNb0MsSUFLMUMsMENBQWdCO0FBS21FLElBUW5GLHFEQUEyQjtBQVNmLElBR1osaUNBQU8sYUFBQyxPQUFlO0FBSUEsSUFNdkIseUNBQWUsYUFBQyxvQkFBNEI7QUFFNEM7QUFBb0Q7QUFBcUU7QUFBZ0U7QUFBbUQ7bURBek9yVSxVQUFVOzs7OzswQkFDTDtBQUFDLDBCQXhDUDtBQUFFLEVBd0NtQyxpQkFBaUI7QUFDckQsU0FEWSxlQUFlO0FBQUkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb3Jkb3ZhLCBJb25pY05hdGl2ZVBsdWdpbiwgUGx1Z2luIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9jb3JlJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcblxuLyoqXG4gKiBAbmFtZSBCbHVldG9vdGggU2VyaWFsXG4gKiBAZGVzY3JpcHRpb24gVGhpcyBwbHVnaW4gZW5hYmxlcyBzZXJpYWwgY29tbXVuaWNhdGlvbiBvdmVyIEJsdWV0b290aC4gSXQgd2FzIHdyaXR0ZW4gZm9yIGNvbW11bmljYXRpbmcgYmV0d2VlbiBBbmRyb2lkIG9yIGlPUyBhbmQgYW4gQXJkdWlubyAobm90IEFuZHJvaWQgdG8gQW5kcm9pZCBvciBpT1MgdG8gaU9TKS5cbiAqIEB1c2FnZVxuICogYGBgdHlwZXNjcmlwdFxuICogaW1wb3J0IHsgQmx1ZXRvb3RoU2VyaWFsIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9ibHVldG9vdGgtc2VyaWFsL25neCc7XG4gKlxuICogY29uc3RydWN0b3IocHJpdmF0ZSBibHVldG9vdGhTZXJpYWw6IEJsdWV0b290aFNlcmlhbCkgeyB9XG4gKlxuICpcbiAqIC8vIFdyaXRlIGEgc3RyaW5nXG4gKiB0aGlzLmJsdWV0b290aFNlcmlhbC53cml0ZSgnaGVsbG8gd29ybGQnKS50aGVuKHN1Y2Nlc3MsIGZhaWx1cmUpO1xuICpcbiAqIC8vIEFycmF5IG9mIGludCBvciBieXRlc1xuICogdGhpcy5ibHVldG9vdGhTZXJpYWwud3JpdGUoWzE4NiwgMjIwLCAyMjJdKS50aGVuKHN1Y2Nlc3MsIGZhaWx1cmUpO1xuICpcbiAqIC8vIFR5cGVkIEFycmF5XG4gKiB2YXIgZGF0YSA9IG5ldyBVaW50OEFycmF5KDQpO1xuICogZGF0YVswXSA9IDB4NDE7XG4gKiBkYXRhWzFdID0gMHg0MjtcbiAqIGRhdGFbMl0gPSAweDQzO1xuICogZGF0YVszXSA9IDB4NDQ7XG4gKiB0aGlzLmJsdWV0b290aFNlcmlhbC53cml0ZShkYXRhKS50aGVuKHN1Y2Nlc3MsIGZhaWx1cmUpO1xuICpcbiAqIC8vIEFycmF5IEJ1ZmZlclxuICogdGhpcy5ibHVldG9vdGhTZXJpYWwud3JpdGUoZGF0YS5idWZmZXIpLnRoZW4oc3VjY2VzcywgZmFpbHVyZSk7XG4gKiBgYGBcbiAqL1xuQFBsdWdpbih7XG4gIHBsdWdpbk5hbWU6ICdCbHVldG9vdGhTZXJpYWwnLFxuICByZXBvOiAnaHR0cHM6Ly9naXRodWIuY29tL2Rvbi9CbHVldG9vdGhTZXJpYWwnLFxuICBwbHVnaW46ICdjb3Jkb3ZhLXBsdWdpbi1ibHVldG9vdGgtc2VyaWFsJyxcbiAgcGx1Z2luUmVmOiAnYmx1ZXRvb3RoU2VyaWFsJyxcbiAgcGxhdGZvcm1zOiBbJ0FuZHJvaWQnLCAnaU9TJywgJ1dpbmRvd3MgUGhvbmUgOCddLFxufSlcbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBCbHVldG9vdGhTZXJpYWwgZXh0ZW5kcyBJb25pY05hdGl2ZVBsdWdpbiB7XG4gIC8qKlxuICAgKiBDb25uZWN0IHRvIGEgQmx1ZXRvb3RoIGRldmljZVxuICAgKiBAcGFyYW0ge3N0cmluZ30gbWFjQWRkcmVzc19vcl91dWlkIElkZW50aWZpZXIgb2YgdGhlIHJlbW90ZSBkZXZpY2VcbiAgICogQHJldHVybnMge09ic2VydmFibGU8YW55Pn0gU3Vic2NyaWJlIHRvIGNvbm5lY3QsIHVuc3Vic2NyaWJlIHRvIGRpc2Nvbm5lY3QuXG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgcGxhdGZvcm1zOiBbJ0FuZHJvaWQnLCAnaU9TJywgJ1dpbmRvd3MgUGhvbmUnXSxcbiAgICBvYnNlcnZhYmxlOiB0cnVlLFxuICAgIGNsZWFyRnVuY3Rpb246ICdkaXNjb25uZWN0JyxcbiAgfSlcbiAgY29ubmVjdChtYWNBZGRyZXNzX29yX3V1aWQ6IHN0cmluZyk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIENvbm5lY3QgaW5zZWN1cmVseSB0byBhIEJsdWV0b290aCBkZXZpY2VcbiAgICogQHBhcmFtIHtzdHJpbmd9IG1hY0FkZHJlc3MgSWRlbnRpZmllciBvZiB0aGUgcmVtb3RlIGRldmljZVxuICAgKiBAcmV0dXJucyB7T2JzZXJ2YWJsZTxhbnk+fSBTdWJzY3JpYmUgdG8gY29ubmVjdCwgdW5zdWJzY3JpYmUgdG8gZGlzY29ubmVjdC5cbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCddLFxuICAgIG9ic2VydmFibGU6IHRydWUsXG4gICAgY2xlYXJGdW5jdGlvbjogJ2Rpc2Nvbm5lY3QnLFxuICB9KVxuICBjb25uZWN0SW5zZWN1cmUobWFjQWRkcmVzczogc3RyaW5nKTogT2JzZXJ2YWJsZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogRGlzY29ubmVjdCBmcm9tIHRoZSBjb25uZWN0ZWQgZGV2aWNlXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGRpc2Nvbm5lY3QoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogV3JpdGVzIGRhdGEgdG8gdGhlIHNlcmlhbCBwb3J0XG4gICAqIEBwYXJhbSB7YW55fSBkYXRhIEFycmF5QnVmZmVyIG9mIGRhdGFcbiAgICogQHJldHVybnMge1Byb21pc2U8YW55Pn0gcmV0dXJucyBhIHByb21pc2Ugd2hlbiBkYXRhIGhhcyBiZWVuIHdyaXR0ZW5cbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCcsICdpT1MnLCAnV2luZG93cyBQaG9uZSddLFxuICB9KVxuICB3cml0ZShkYXRhOiBhbnkpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXRzIHRoZSBudW1iZXIgb2YgYnl0ZXMgb2YgZGF0YSBhdmFpbGFibGVcbiAgICogQHJldHVybnMge1Byb21pc2U8YW55Pn0gcmV0dXJucyBhIHByb21pc2UgdGhhdCBjb250YWlucyB0aGUgYXZhaWxhYmxlIGJ5dGVzXG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgcGxhdGZvcm1zOiBbJ0FuZHJvaWQnLCAnaU9TJywgJ1dpbmRvd3MgUGhvbmUnXSxcbiAgfSlcbiAgYXZhaWxhYmxlKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlYWRzIGRhdGEgZnJvbSB0aGUgYnVmZmVyXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59IHJldHVybnMgYSBwcm9taXNlIHdpdGggZGF0YSBmcm9tIHRoZSBidWZmZXJcbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCcsICdpT1MnLCAnV2luZG93cyBQaG9uZSddLFxuICB9KVxuICByZWFkKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlYWRzIGRhdGEgZnJvbSB0aGUgYnVmZmVyIHVudGlsIGl0IHJlYWNoZXMgYSBkZWxpbWl0ZXJcbiAgICogQHBhcmFtIHtzdHJpbmd9IGRlbGltaXRlciBzdHJpbmcgdGhhdCB5b3Ugd2FudCB0byBzZWFyY2ggdW50aWxcbiAgICogQHJldHVybnMge1Byb21pc2U8YW55Pn0gcmV0dXJucyBhIHByb21pc2VcbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCcsICdpT1MnLCAnV2luZG93cyBQaG9uZSddLFxuICB9KVxuICByZWFkVW50aWwoZGVsaW1pdGVyOiBzdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBTdWJzY3JpYmUgdG8gYmUgbm90aWZpZWQgd2hlbiBkYXRhIGlzIHJlY2VpdmVkXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBkZWxpbWl0ZXIgdGhlIHN0cmluZyB5b3Ugd2FudCB0byB3YXRjaCBmb3JcbiAgICogQHJldHVybnMge09ic2VydmFibGU8YW55Pn0gcmV0dXJucyBhbiBvYnNlcnZhYmxlLlxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHBsYXRmb3JtczogWydBbmRyb2lkJywgJ2lPUycsICdXaW5kb3dzIFBob25lJ10sXG4gICAgb2JzZXJ2YWJsZTogdHJ1ZSxcbiAgICBjbGVhckZ1bmN0aW9uOiAndW5zdWJzY3JpYmUnLFxuICB9KVxuICBzdWJzY3JpYmUoZGVsaW1pdGVyOiBzdHJpbmcpOiBPYnNlcnZhYmxlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBTdWJzY3JpYmUgdG8gYmUgbm90aWZpZWQgd2hlbiBkYXRhIGlzIHJlY2VpdmVkXG4gICAqIEByZXR1cm5zIHtPYnNlcnZhYmxlPGFueT59IHJldHVybnMgYW4gb2JzZXJ2YWJsZVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHBsYXRmb3JtczogWydBbmRyb2lkJywgJ2lPUycsICdXaW5kb3dzIFBob25lJ10sXG4gICAgb2JzZXJ2YWJsZTogdHJ1ZSxcbiAgICBjbGVhckZ1bmN0aW9uOiAndW5zdWJzY3JpYmVSYXdEYXRhJyxcbiAgfSlcbiAgc3Vic2NyaWJlUmF3RGF0YSgpOiBPYnNlcnZhYmxlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBDbGVhcnMgZGF0YSBpbiBidWZmZXJcbiAgICogQHJldHVybnMge1Byb21pc2U8YW55Pn0gcmV0dXJucyBhIHByb21pc2Ugd2hlbiBjb21wbGV0ZWRcbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCcsICdpT1MnLCAnV2luZG93cyBQaG9uZSddLFxuICB9KVxuICBjbGVhcigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBMaXN0cyBib25kZWQgZGV2aWNlc1xuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fSByZXR1cm5zIGEgcHJvbWlzZVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHBsYXRmb3JtczogWydBbmRyb2lkJywgJ2lPUycsICdXaW5kb3dzIFBob25lJ10sXG4gIH0pXG4gIGxpc3QoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogUmVwb3J0cyBpZiBibHVldG9vdGggaXMgZW5hYmxlZFxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fSByZXR1cm5zIGEgcHJvbWlzZVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHBsYXRmb3JtczogWydBbmRyb2lkJywgJ2lPUycsICdXaW5kb3dzIFBob25lJ10sXG4gIH0pXG4gIGlzRW5hYmxlZCgpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXBvcnRzIHRoZSBjb25uZWN0aW9uIHN0YXR1c1xuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fSByZXR1cm5zIGEgcHJvbWlzZVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHBsYXRmb3JtczogWydBbmRyb2lkJywgJ2lPUycsICdXaW5kb3dzIFBob25lJ10sXG4gIH0pXG4gIGlzQ29ubmVjdGVkKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlYWRzIHRoZSBSU1NJIGZyb20gdGhlIGNvbm5lY3RlZCBwZXJpcGhlcmFsXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59IHJldHVybnMgYSBwcm9taXNlXG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgcGxhdGZvcm1zOiBbJ0FuZHJvaWQnLCAnaU9TJywgJ1dpbmRvd3MgUGhvbmUnXSxcbiAgfSlcbiAgcmVhZFJTU0koKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogU2hvdyB0aGUgQmx1ZXRvb3RoIHNldHRpbmdzIG9uIHRoZSBkZXZpY2VcbiAgICogQHJldHVybnMge1Byb21pc2U8YW55Pn0gcmV0dXJucyBhIHByb21pc2VcbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCcsICdpT1MnLCAnV2luZG93cyBQaG9uZSddLFxuICB9KVxuICBzaG93Qmx1ZXRvb3RoU2V0dGluZ3MoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogRW5hYmxlIEJsdWV0b290aCBvbiB0aGUgZGV2aWNlXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59IHJldHVybnMgYSBwcm9taXNlXG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgcGxhdGZvcm1zOiBbJ0FuZHJvaWQnLCAnaU9TJywgJ1dpbmRvd3MgUGhvbmUnXSxcbiAgfSlcbiAgZW5hYmxlKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIERpc2NvdmVyIHVucGFpcmVkIGRldmljZXNcbiAgICogQHJldHVybnMge1Byb21pc2U8YW55Pn0gcmV0dXJucyBhIHByb21pc2VcbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCcsICdpT1MnLCAnV2luZG93cyBQaG9uZSddLFxuICB9KVxuICBkaXNjb3ZlclVucGFpcmVkKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIFN1YnNjcmliZSB0byBiZSBub3RpZmllZCBvbiBCbHVldG9vdGggZGV2aWNlIGRpc2NvdmVyeS4gRGlzY292ZXJ5IHByb2Nlc3MgbXVzdCBiZSBpbml0aWF0ZWQgd2l0aCB0aGUgYGRpc2NvdmVyVW5wYWlyZWRgIGZ1bmN0aW9uLlxuICAgKiBAcmV0dXJucyB7T2JzZXJ2YWJsZTxhbnk+fSBSZXR1cm5zIGFuIG9ic2VydmFibGVcbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCcsICdpT1MnLCAnV2luZG93cyBQaG9uZSddLFxuICAgIG9ic2VydmFibGU6IHRydWUsXG4gICAgY2xlYXJGdW5jdGlvbjogJ2NsZWFyRGV2aWNlRGlzY292ZXJlZExpc3RlbmVyJyxcbiAgfSlcbiAgc2V0RGV2aWNlRGlzY292ZXJlZExpc3RlbmVyKCk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIFNldHMgdGhlIGh1bWFuIHJlYWRhYmxlIGRldmljZSBuYW1lIHRoYXQgaXMgYnJvYWRjYXN0ZWQgdG8gb3RoZXIgZGV2aWNlc1xuICAgKiBAcGFyYW0ge3N0cmluZ30gbmV3TmFtZSBEZXNpcmVkIG5hbWUgb2YgZGV2aWNlXG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgcGxhdGZvcm1zOiBbJ0FuZHJvaWQnXSxcbiAgICBzeW5jOiB0cnVlLFxuICB9KVxuICBzZXROYW1lKG5ld05hbWU6IHN0cmluZyk6IHZvaWQge31cblxuICAvKipcbiAgICogTWFrZXMgdGhlIGRldmljZSBkaXNjb3ZlcmFibGUgYnkgb3RoZXIgZGV2aWNlc1xuICAgKiBAcGFyYW0ge251bWJlcn0gZGlzY292ZXJhYmxlRHVyYXRpb24gRGVzaXJlZCBudW1iZXIgb2Ygc2Vjb25kcyBkZXZpY2Ugc2hvdWxkIGJlIGRpc2NvdmVyYWJsZSBmb3JcbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCddLFxuICAgIHN5bmM6IHRydWUsXG4gIH0pXG4gIHNldERpc2NvdmVyYWJsZShkaXNjb3ZlcmFibGVEdXJhdGlvbjogbnVtYmVyKTogdm9pZCB7fVxufVxuIl19

/***/ }),

/***/ "j1s5":
/*!*****************************************************!*\
  !*** ./src/app/devices/bluetooth/bluetooth.page.ts ***!
  \*****************************************************/
/*! exports provided: BluetoothPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BluetoothPage", function() { return BluetoothPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_bluetooth_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./bluetooth.page.html */ "sSSd");
/* harmony import */ var _bluetooth_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./bluetooth.page.scss */ "I/IY");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _bluetooth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./bluetooth.service */ "kHBP");






let BluetoothPage = class BluetoothPage {
    constructor(toastCtrl, alertCtrl, plt, bluetooth) {
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.plt = plt;
        this.bluetooth = bluetooth;
        this.devices = [];
        this.showSpinner = false;
        this.isConnected = false;
        this.connChecked = false;
        this.messagelog = '';
        this.message = '';
        this.messages = [];
        if (this.plt.is('cordova')) {
        }
    }
    ngOnInit() {
        this.showSpinner = true;
        this.bluetooth.storedConnection().then((connected) => {
            this.isConnected = true;
            this.showSpinner = false;
            this.devices = [];
            this.devices.push(this.bluetooth.getstoredDevice());
        }, (fail) => {
            this.bluetooth.searchBluetooth().then((devices) => {
                this.devices = devices;
                this.showSpinner = false;
            }, (error) => {
                this.presentToast(error);
                this.showSpinner = false;
            });
        });
    }
    disconnect() {
        return new Promise(result => {
            this.isConnected = false;
            this.bluetooth.disconnect().then(response => {
                result(response);
            });
        });
    }
    sendMessage(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.messagelog = "wait...";
            this.sendElement.disabled = true;
            let data = yield this.bluetooth.dataInOut(`${message}\n`);
            this.messagelog = data.toString();
            this.sendElement.disabled = false;
            // this.bluetooth.dataInOut(`${message}\n`).subscribe(data => {
            //   if (data !== 'BLUETOOTH.NOT_CONNECTED') {
            //     try {
            //       if (data) {
            //         const entry = JSON.parse(data);
            //         this.addLine(message);
            //       }
            //     } catch (error) {
            //       console.log(`[bluetooth-168]: ${JSON.stringify(error)}`);
            //     }
            //     // this.presentToast(data);
            //     this.message = '';
            //   } else {
            //     this.presentToast(data);
            //   }
            // });
        });
    }
    addLine(message) {
        this.messages.push(message);
    }
    presentToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                message: text,
                duration: 3000
            });
            yield toast.present();
        });
    }
    ngOnDestroy() {
        this.disconnect();
    }
    refreshBluetooth(refresher) {
        if (refresher) {
            this.bluetooth.searchBluetooth().then((successMessage) => {
                this.devices = [];
                this.devices = successMessage;
                refresher.target.complete();
            }, fail => {
                this.presentToast(fail);
                refresher.target.complete();
            });
        }
    }
    checkConnection(seleccion) {
        this.bluetooth.checkConnection().then((isConnected) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'BLUETOOTH.ALERTS.RECONNECT.TITLE',
                message: 'BLUETOOTH.ALERTS.RECONNECT.MESSAGE',
                buttons: [
                    {
                        text: 'CANCEL',
                        role: 'cancel',
                        handler: () => { }
                    },
                    {
                        text: 'ACCEPT',
                        handler: () => {
                            this.disconnect().then(() => {
                                this.bluetooth.deviceConnection(seleccion).then(success => {
                                    this.isConnected = true;
                                    this.presentToast(success);
                                }, fail => {
                                    this.isConnected = false;
                                    this.presentToast(fail);
                                });
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        }), (notConnected) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'BLUETOOTH.ALERTS.CONNECT.TITLE',
                message: 'BLUETOOTH.ALERTS.CONNECT.MESSAGE',
                buttons: [
                    {
                        text: 'CANCEL',
                        role: 'cancel',
                        handler: () => { }
                    },
                    {
                        text: 'ACCEPT',
                        handler: () => {
                            this.bluetooth.deviceConnection(seleccion).then(success => {
                                this.isConnected = true;
                                this.connectElement.checked = false;
                                this.presentToast(success);
                            }, fail => {
                                this.isConnected = false;
                                this.connectElement.checked = true;
                                this.presentToast(fail);
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        }));
    }
};
BluetoothPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] },
    { type: _bluetooth_service__WEBPACK_IMPORTED_MODULE_5__["BluetoothService"] }
];
BluetoothPage.propDecorators = {
    connectElement: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['connectElement',] }],
    sendElement: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['sendElement',] }]
};
BluetoothPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-bluetooth',
        template: _raw_loader_bluetooth_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_bluetooth_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], BluetoothPage);



/***/ }),

/***/ "kG7V":
/*!***************************************************************!*\
  !*** ./src/app/devices/bluetooth/bluetooth-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: BluetoothPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BluetoothPageRoutingModule", function() { return BluetoothPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _bluetooth_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./bluetooth.page */ "j1s5");




const routes = [
    {
        path: '',
        component: _bluetooth_page__WEBPACK_IMPORTED_MODULE_3__["BluetoothPage"]
    }
];
let BluetoothPageRoutingModule = class BluetoothPageRoutingModule {
};
BluetoothPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], BluetoothPageRoutingModule);



/***/ }),

/***/ "kHBP":
/*!********************************************************!*\
  !*** ./src/app/devices/bluetooth/bluetooth.service.ts ***!
  \********************************************************/
/*! exports provided: BluetoothService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BluetoothService", function() { return BluetoothService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/bluetooth-serial/ngx */ "bRl7");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./storage.service */ "q8xk");






let BluetoothService = class BluetoothService {
    constructor(bluetoothSerial, storage) {
        this.bluetoothSerial = bluetoothSerial;
        this.storage = storage;
    }
    searchBluetooth() {
        return new Promise((resolve, reject) => {
            this.bluetoothSerial.isEnabled().then(success => {
                this.bluetoothSerial.discoverUnpaired().then(response => {
                    if (response.length > 0) {
                        resolve(response);
                    }
                    else {
                        reject('BLUETOOTH.NOT_DEVICES_FOUND');
                    }
                }).catch((error) => {
                    console.log(`[bluetooth.service-41] Error: ${JSON.stringify(error)}`);
                    reject('BLUETOOTH.NOT_AVAILABLE_IN_THIS_DEVICE');
                });
            }, fail => {
                console.log(`[bluetooth.service-45] Error: ${JSON.stringify(fail)}`);
                reject('BLUETOOTH.NOT_AVAILABLE');
            });
        });
    }
    checkConnection() {
        return new Promise((resolve, reject) => {
            this.bluetoothSerial.isConnected().then(isConnected => {
                resolve('BLUETOOTH.CONNECTED');
            }, notConnected => {
                reject('BLUETOOTH.NOT_CONNECTED');
            });
        });
    }
    deviceConnection(device) {
        return new Promise((resolve, reject) => {
            this.connection = this.bluetoothSerial.connect(device.id).subscribe(() => {
                let res = this.storage.setBluetoothId(device);
                resolve('BLUETOOTH.CONNECTED');
            }, fail => {
                console.log(`[bluetooth.service-88] Error conexión: ${JSON.stringify(fail)}`);
                reject('BLUETOOTH.CANNOT_CONNECT');
            });
        });
    }
    disconnect() {
        return new Promise((result) => {
            if (this.connectionCommunication) {
                this.connectionCommunication.unsubscribe();
            }
            if (this.connection) {
                this.connection.unsubscribe();
            }
            result(true);
        });
    }
    dataInOut(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return this.bluetoothSerial.isConnected().then((isConnected) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                return yield this.bluetoothSerial.write(message).then((success) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    return yield this.bluetoothSerial.read().then((data) => {
                        return data;
                    });
                }));
            }), notConected => {
                return 'Blutooth Not connect';
            });
        });
    }
    dataInOut_(message) {
        return rxjs__WEBPACK_IMPORTED_MODULE_3__["Observable"].create(observer => {
            this.bluetoothSerial.isConnected().then((isConnected) => {
                this.reader = Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["from"])(this.bluetoothSerial.write(message)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["mergeMap"])(() => {
                    return this.bluetoothSerial.subscribeRawData();
                })).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["mergeMap"])(() => {
                    return this.bluetoothSerial.readUntil('\n'); // <= delimitador
                }));
                this.reader.subscribe(data => {
                    observer.next(data);
                });
            }, notConected => {
                observer.next('BLUETOOTH.NOT_CONNECTED');
                observer.complete();
            });
        });
    }
    storedConnection() {
        return new Promise((resolve, reject) => {
            let device = this.storage.getBluetoothId();
            this.deviceConnection(device).then(success => {
                resolve(success);
            }, fail => {
                reject(fail);
            });
        });
    }
    getstoredDevice() {
        return this.storage.getBluetoothId();
    }
};
BluetoothService.ctorParameters = () => [
    { type: _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_2__["BluetoothSerial"] },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"] }
];
BluetoothService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], BluetoothService);



/***/ }),

/***/ "q8xk":
/*!******************************************************!*\
  !*** ./src/app/devices/bluetooth/storage.service.ts ***!
  \******************************************************/
/*! exports provided: StorageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StorageService", function() { return StorageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");


let StorageService = class StorageService {
    constructor() {
        this.BLUETOOTH_ID = 'bluetoothId';
    }
    getBluetoothId() {
        return this._connectedDevice;
    }
    setBluetoothId(device) {
        this._connectedDevice = device;
        return true;
    }
};
StorageService.ctorParameters = () => [];
StorageService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], StorageService);



/***/ }),

/***/ "sSSd":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/devices/bluetooth/bluetooth.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons>\n      <ion-button>\n        <ion-menu-button slot=\"start\"></ion-menu-button>\n      </ion-button>\n      <ion-icon  color=\"primary\" name=\"bluetooth\" slot=\"start\"></ion-icon>\n      <ion-title color=\"primary\">Bluetooth</ion-title>\n      <ion-text>Disconnect</ion-text>\n      <ion-toggle slot=\"end\" name=\"cherry\" color=\"danger\" (ionChange)=\"disconnect()\" #connectElement [disabled]=\"!isConnected\"></ion-toggle>\n    </ion-buttons>\n</ion-toolbar>\n</ion-header>\n<ion-content>\n  <ion-refresher slot=\"fixed\" *ngIf=\"showSpinner === false\" (ionRefresh)=\"refreshBluetooth($event)\">\n    <ion-refresher-content refreshingText=\"{{ 'BLUETOOTH.SEARCHING' }}\">\n    </ion-refresher-content>\n  </ion-refresher>\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <div [hidden]=\"showSpinner === false\" text-center>\n          <ion-spinner></ion-spinner> {{ \"BLUETOOTH.SEARCHING\" }}<br>\n        </div>\n        <ion-list  button (click)=\"checkConnection(device)\" *ngFor=\"let device of devices\">\n          <ion-item detail color=\"secondary\" *ngIf=\"device.name\">\n            <ion-label>{{ \"BLUETOOTH.NAME\"  }}: {{device.name}}</ion-label>\n          </ion-item>\n        </ion-list>\n      </ion-col>\n    </ion-row>\n\n<ion-row>\n  <ion-col>\n    <ion-item>\n      <ion-input type=\"text\" [(ngModel)]=\"message\" name=\"message\" [disabled]=\"!isConnected\"></ion-input>\n      <ion-button expand=\"block\" type=\"button\" [disabled]=\"!isConnected\" (click)=\"sendMessage(message);\" #sendElement>\n        <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n      </ion-button>\n    </ion-item>\n  </ion-col>\n</ion-row>\n\n<ion-row [hidden]=\"!isConnected\">\n  <ion-col>\n    <ion-item>\n      <ion-label>Received Data:</ion-label>\n      <ion-textarea row=\"3\" readonly>{{messagelog}}</ion-textarea>\n    </ion-item>\n  </ion-col>\n</ion-row>\n\n  <ion-row>\n    <ion-col>\n      <p *ngFor=\"let item of messages\">{{ item }}</p>\n      <div [hidden]=\"devices.length > 0 || showSpinner == true || isConnected\" text-center>\n        <p>{{ \"BLUETOOTH.NOT_FOUND\"  }}</p>\n      </div>\n    </ion-col>\n  </ion-row>\n  </ion-grid>\n\n\n\n\n\n\n  <ion-list lines=\"full\" style=\"display: none;\">\n    <ion-item button (click)=\"checkConnection(device)\" *ngFor=\"let device of devices\">\n      <ion-text>\n        <h3>{{ \"BLUETOOTH.NAME\"  }}: {{device.name}}</h3>\n        <p style=\"display: none;\">{{ \"BLUETOOTH.ID\"  }}: {{device.id}}</p>\n        <p style=\"display: none;\">{{ \"BLUETOOTH.ADDRESS\"  }}\n          <span [hidden]=\"device.address == undefined\">mac</span>\n          <span [hidden]=\"device.uuid == undefined\">uuid</span>\n          {{device.address}} {{device.uuid}}\n        </p>\n        <p style=\"display: none;\">\n          <span [hidden]=\"device.class == undefined\">Clase</span>\n          <span [hidden]=\"device.rssi == undefined\">Rssi</span>\n          {{device.class}} {{device.rssi}}\n        </p>\n      </ion-text>\n    </ion-item>\n  </ion-list>\n\n  <form (ngSubmit)=\"sendMessage(message);\" style=\"display: none;\">\n    <ion-item>\n      <ion-input type=\"text\" [(ngModel)]=\"message\" name=\"message\"></ion-input>\n    </ion-item>\n    <ion-row>\n      <ion-col>\n        <ion-button expand=\"block\" color=\"dark\" (click)=\"disconnect()\" [disabled]=\"!isConnected\">\n          {{ \"DISCONNECT\"  }}\n        </ion-button>\n      </ion-col>\n      <ion-col>\n        <ion-button expand=\"block\" type=\"submit\" [disabled]=\"!isConnected\">\n          {{ \"SEND\"  }}\n        </ion-button>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col>\n        <h1>Log</h1>\n        <h6>{{messagelog}}</h6>\n      </ion-col>\n    </ion-row>\n  </form>\n\n</ion-content>\n");

/***/ }),

/***/ "tShh":
/*!*******************************************************!*\
  !*** ./src/app/devices/bluetooth/bluetooth.module.ts ***!
  \*******************************************************/
/*! exports provided: BluetoothPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BluetoothPageModule", function() { return BluetoothPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _bluetooth_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./bluetooth-routing.module */ "kG7V");
/* harmony import */ var _bluetooth_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./bluetooth.page */ "j1s5");
/* harmony import */ var _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/bluetooth-serial/ngx */ "bRl7");
/* harmony import */ var _bluetooth_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./bluetooth.service */ "kHBP");
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./storage.service */ "q8xk");










let BluetoothPageModule = class BluetoothPageModule {
};
BluetoothPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _bluetooth_routing_module__WEBPACK_IMPORTED_MODULE_5__["BluetoothPageRoutingModule"]
        ],
        providers: [
            _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_7__["BluetoothSerial"],
            _bluetooth_service__WEBPACK_IMPORTED_MODULE_8__["BluetoothService"],
            _storage_service__WEBPACK_IMPORTED_MODULE_9__["StorageService"]
        ],
        declarations: [_bluetooth_page__WEBPACK_IMPORTED_MODULE_6__["BluetoothPage"]]
    })
], BluetoothPageModule);



/***/ })

}]);
//# sourceMappingURL=devices-bluetooth-bluetooth-module.js.map