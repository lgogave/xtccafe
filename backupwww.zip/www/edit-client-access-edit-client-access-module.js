(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-client-access-edit-client-access-module"],{

/***/ "+llI":
/*!**************************************************************************************!*\
  !*** ./src/app/settings/client-access/edit-client-access/edit-client-access.page.ts ***!
  \**************************************************************************************/
/*! exports provided: EditClientAccessPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditClientAccessPage", function() { return EditClientAccessPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_edit_client_access_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./edit-client-access.page.html */ "3O1n");
/* harmony import */ var _edit_client_access_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit-client-access.page.scss */ "/nh2");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let EditClientAccessPage = class EditClientAccessPage {
    constructor() { }
    ngOnInit() {
    }
};
EditClientAccessPage.ctorParameters = () => [];
EditClientAccessPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-edit-client-access',
        template: _raw_loader_edit_client_access_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_edit_client_access_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], EditClientAccessPage);



/***/ }),

/***/ "/nh2":
/*!****************************************************************************************!*\
  !*** ./src/app/settings/client-access/edit-client-access/edit-client-access.page.scss ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlZGl0LWNsaWVudC1hY2Nlc3MucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "3O1n":
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/settings/client-access/edit-client-access/edit-client-access.page.html ***!
  \******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>edit-client-access</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n");

/***/ }),

/***/ "FoZd":
/*!****************************************************************************************!*\
  !*** ./src/app/settings/client-access/edit-client-access/edit-client-access.module.ts ***!
  \****************************************************************************************/
/*! exports provided: EditClientAccessPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditClientAccessPageModule", function() { return EditClientAccessPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _edit_client_access_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./edit-client-access-routing.module */ "LujT");
/* harmony import */ var _edit_client_access_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit-client-access.page */ "+llI");







let EditClientAccessPageModule = class EditClientAccessPageModule {
};
EditClientAccessPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _edit_client_access_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditClientAccessPageRoutingModule"]
        ],
        declarations: [_edit_client_access_page__WEBPACK_IMPORTED_MODULE_6__["EditClientAccessPage"]]
    })
], EditClientAccessPageModule);



/***/ }),

/***/ "LujT":
/*!************************************************************************************************!*\
  !*** ./src/app/settings/client-access/edit-client-access/edit-client-access-routing.module.ts ***!
  \************************************************************************************************/
/*! exports provided: EditClientAccessPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditClientAccessPageRoutingModule", function() { return EditClientAccessPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _edit_client_access_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./edit-client-access.page */ "+llI");




const routes = [
    {
        path: '',
        component: _edit_client_access_page__WEBPACK_IMPORTED_MODULE_3__["EditClientAccessPage"]
    }
];
let EditClientAccessPageRoutingModule = class EditClientAccessPageRoutingModule {
};
EditClientAccessPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditClientAccessPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=edit-client-access-edit-client-access-module.js.map