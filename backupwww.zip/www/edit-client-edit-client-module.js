(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-client-edit-client-module"],{

/***/ "7BeS":
/*!*********************************************************!*\
  !*** ./src/app/clients/edit-client/edit-client.page.ts ***!
  \*********************************************************/
/*! exports provided: EditClientPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditClientPage", function() { return EditClientPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_edit_client_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./edit-client.page.html */ "FrHg");
/* harmony import */ var _edit_client_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit-client.page.scss */ "SKY3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _services_client_type_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/client-type.service */ "uYsA");
/* harmony import */ var _services_division_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../services/division.service */ "KWQH");
/* harmony import */ var _client_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../client.service */ "+RYs");
/* harmony import */ var src_app_services_potentialnature_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/potentialnature.service */ "1VZb");
/* harmony import */ var _services_location_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../services/location.service */ "yHma");













let EditClientPage = class EditClientPage {
    constructor(route, navCtrl, clientService, router, loadingCtrl, alertCtrl, divisionService, clientTypeService, potentialNatureService, locationService, toastController) {
        this.route = route;
        this.navCtrl = navCtrl;
        this.clientService = clientService;
        this.router = router;
        this.loadingCtrl = loadingCtrl;
        this.alertCtrl = alertCtrl;
        this.divisionService = divisionService;
        this.clientTypeService = clientTypeService;
        this.potentialNatureService = potentialNatureService;
        this.locationService = locationService;
        this.toastController = toastController;
        this.isLoading = false;
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.route.paramMap.subscribe((paramMap) => {
                if (!paramMap.has('clientId')) {
                    this.navCtrl.navigateBack('/clients');
                }
                this.clientId = paramMap.get('clientId');
                this.isLoading = true;
                this.loadClient(this.clientId);
            });
            this.clients = yield this.clientService.getClientList();
            this.clientGroup = this.clients
                .map((item) => item.group)
                .filter((value, index, self) => {
                if (value != null)
                    return self.indexOf(value) === index;
            });
        });
    }
    loadClient(clientId) {
        this.clientSub = Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["combineLatest"])([
            this.clientService.getClient(clientId),
            this.divisionService.fetchDivisions(),
            this.clientTypeService.fetchclientTypes(),
            this.potentialNatureService.fetchPotentialnatures(),
            this.locationService.fetchLocations(),
        ]).subscribe((res) => {
            this.client = res[0];
            this.divisionList = res[1];
            this.clientTypeList = res[2];
            //console.log(JSON.stringify(res[1]));
            //console.log(JSON.stringify(res[2]));
            console.log(JSON.stringify(res[3]));
            this.potentialNatureList = res[3];
            this.locationList = res[4];
            let ncountry = this.client.country ? this.client.country : null;
            let nregion = this.client.region ? this.client.region : null;
            let nsubregion = this.client.subRegion ? this.client.subRegion : null;
            let nstate = this.client.state ? this.client.state : null;
            this.countries = this.locationList
                .map((item) => item.country)
                .filter((value, index, self) => self.indexOf(value) === index);
            if (ncountry != null) {
                this.regions = this.locationList
                    .filter((item) => item.country === ncountry)
                    .map((item) => item.region)
                    .filter((value, index, self) => self.indexOf(value) === index);
            }
            if (nregion != null) {
                this.subregions = this.locationList
                    .filter((item) => item.region === nregion)
                    .map((item) => item.subregion)
                    .filter((value, index, self) => self.indexOf(value) === index);
            }
            if (nsubregion != null) {
                this.states = this.locationList
                    .filter((item) => item.subregion === nsubregion)
                    .map((item) => item.state)
                    .filter((value, index, self) => self.indexOf(value) === index);
            }
            if (nstate != null) {
                this.cities = this.locationList
                    .filter((item) => item.state === nstate)
                    .map((item) => item.city)
                    .filter((value, index, self) => self.indexOf(value) === index);
            }
            this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
                divisionId: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.divisionIds ? this.client.divisionIds : null, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                name: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.name ? this.client.name : null, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                typeId: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.clientTypeIds ? this.client.clientTypeIds : null, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                contactPerson: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.contactPerson ? this.client.contactPerson : null, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                contactNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.contactNumber ? this.client.contactNumber : null, {
                    updateOn: 'blur',
                }),
                email: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.email ? this.client.email : null, {
                    updateOn: 'blur',
                }),
                potentialNatureId: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.potentialNatureId ? this.client.potentialNatureId : null, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                accountOwner: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.accountOwner ? this.client.accountOwner : null, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                gstNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.gstNumber ? this.client.gstNumber : null, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(15)],
                }),
                employeeStrength: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.employeeStrength ? this.client.employeeStrength : null, {
                    updateOn: 'blur',
                }),
                cmbClientGroup: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.group ? this.client.group : null, {
                    updateOn: 'blur',
                }),
                clientGroup: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: 'blur',
                }),
                ddCountry: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.country ? this.client.country : null, {
                    updateOn: 'blur',
                }),
                ddRegion: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.region ? this.client.region : null, {
                    updateOn: 'blur',
                }),
                ddSubRegion: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.subRegion ? this.client.subRegion : null, {
                    updateOn: 'blur',
                }),
                ddState: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.state ? this.client.state : null, {
                    updateOn: 'blur',
                }),
                ddCity: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.client.city ? this.client.city : null, {
                    updateOn: 'blur',
                }),
            });
            this.isLoading = false;
        }, (error) => {
            this.alertCtrl
                .create({
                header: 'An error occured',
                message: 'Client could not be fetch. Please try that later.',
                buttons: [
                    {
                        text: 'Okay',
                        handler: () => {
                            this.router.navigate(['/clients']);
                        },
                    },
                ],
            })
                .then((alerEl) => {
                alerEl.present();
            });
        });
    }
    updateNewGroup() {
        this.form.get('cmbClientGroup').reset();
    }
    onUpdateClient() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!this.form.valid)
                return;
            var exiclientId = yield this.clientService.getClientIdByGSTNumber(this.form.value.gstNumber);
            if (exiclientId.length > 0 && exiclientId[0] != this.clientId) {
                yield this.toastController.create({
                    message: 'Client GST already exist.',
                    duration: 2000,
                    color: 'danger',
                }).then((tost) => {
                    tost.present();
                });
                return;
            }
            this.loadingCtrl.create({ keyboardClose: true }).then((loadingEl) => {
                loadingEl.present();
                let nlocId = "";
                let nlocation = this.locationList.filter(item => item.country == (this.form.value.ddCountry == null ? "" : this.form.value.ddCountry) &&
                    item.region == (this.form.value.ddRegion == null ? "" : this.form.value.ddRegion) &&
                    item.subregion == (this.form.value.ddSubRegion == null ? "" : this.form.value.ddSubRegion) &&
                    item.state == (this.form.value.ddState == null ? "" : this.form.value.ddState) &&
                    item.city == (this.form.value.ddCity == null ? "" : this.form.value.ddCity));
                if (nlocation.length > 0) {
                    nlocId = nlocation[0].id;
                }
                let ndivisions = [];
                if (this.form.value.divisionId.length > 0) {
                    this.form.value.divisionId.forEach(element => {
                        ndivisions.push(this.divisionList.filter(div => div.id == element)[0].name);
                    });
                }
                let nclientTypes = [];
                if (this.form.value.typeId.length > 0) {
                    this.form.value.typeId.forEach((element) => {
                        nclientTypes.push(this.clientTypeList.filter((div) => div.id == element)[0].name);
                    });
                }
                console.log(this.client.id);
                this.clientService
                    .editClient(this.client.id, this.form.value.name, this.form.value.contactPerson, this.form.value.contactNumber, this.form.value.email, this.potentialNatureList.filter(item => item.id == this.form.value.potentialNatureId)[0].name, this.form.value.accountOwner, (this.form.value.cmbClientGroup == null ? this.form.value.clientGroup : this.form.value.cmbClientGroup), this.form.value.gstNumber, this.form.value.employeeStrength, this.form.value.potentialNatureId, this.form.value.ddCountry == null ? "" : this.form.value.ddCountry, this.form.value.ddRegion == null ? "" : this.form.value.ddRegion, this.form.value.ddSubRegion == null ? "" : this.form.value.ddSubRegion, this.form.value.ddState == null ? "" : this.form.value.ddState, this.form.value.ddCity == null ? "" : this.form.value.ddCity, nlocId, new Date(), this.form.value.divisionId, ndivisions, this.form.value.typeId, nclientTypes, this.client.clientId)
                    .subscribe(() => {
                    loadingEl.dismiss();
                    this.router.navigate(['/clients']);
                });
            });
        });
    }
    onChangeCountry(event) {
        let country = event.target.value;
        this.form.controls['ddRegion'].reset();
        this.form.controls['ddSubRegion'].reset();
        this.form.controls['ddState'].reset();
        this.form.controls['ddCity'].reset();
        this.regions = [];
        this.subregions = [];
        this.states = [];
        this.cities = [];
        this.regions = this.locationList.filter(item => item.country === country).map(item => item.region).filter((value, index, self) => self.indexOf(value) === index);
    }
    onChangeRegion(event) {
        let region = event.target.value;
        this.form.controls['ddSubRegion'].reset();
        this.form.controls['ddState'].reset();
        this.form.controls['ddCity'].reset();
        this.subregions = null;
        this.states = null;
        this.cities = null;
        this.subregions = this.locationList.filter(item => item.region === region).map(item => item.subregion).filter((value, index, self) => self.indexOf(value) === index);
    }
    onChangeSubRegion(event) {
        let subregion = event.target.value;
        this.form.controls['ddState'].reset();
        this.form.controls['ddCity'].reset();
        this.states = [];
        this.cities = [];
        this.states = this.locationList.filter(item => item.subregion === subregion).map(item => item.state).filter((value, index, self) => self.indexOf(value) === index);
    }
    onChangeStates(event) {
        let state = event.target.value;
        this.form.controls['ddCity'].reset();
        this.cities = [];
        this.cities = this.locationList.filter(item => item.state === state).map(item => item.city).filter((value, index, self) => self.indexOf(value) === index);
    }
    ionViewWillEnter() {
    }
    ngOnDestroy() {
        if (this.clientSub) {
            this.clientSub.unsubscribe();
        }
    }
};
EditClientPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: _client_service__WEBPACK_IMPORTED_MODULE_10__["ClientService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _services_division_service__WEBPACK_IMPORTED_MODULE_9__["DivisionService"] },
    { type: _services_client_type_service__WEBPACK_IMPORTED_MODULE_8__["ClientTypeService"] },
    { type: src_app_services_potentialnature_service__WEBPACK_IMPORTED_MODULE_11__["PotentialnatureService"] },
    { type: _services_location_service__WEBPACK_IMPORTED_MODULE_12__["LocationService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] }
];
EditClientPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-edit-client',
        template: _raw_loader_edit_client_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_edit_client_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], EditClientPage);



/***/ }),

/***/ "FrHg":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/clients/edit-client/edit-client.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref=\"/clients\">\n      </ion-back-button>\n      <ion-title>Edit Client</ion-title>\n      <ion-button (click)=\"onUpdateClient()\" [disabled]=\"!form?.valid\">\n        <ion-icon name=\"checkmark\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <div *ngIf=\"isLoading\" class=\"ion-text-center\">\n    <ion-spinner></ion-spinner>\n  </div>\n<form [formGroup]=\"form\" *ngIf=\"!isLoading\">\n  <ion-grid>\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >Division</ion-label>\n          <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"divisionId\" multiple >\n            <ion-select-option *ngFor=\"let division of divisionList\" [value]=\"division.id\">{{division.name}}\n            </ion-select-option>\n          </ion-select>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n    <ion-row *ngIf=\"!form.get('divisionId').valid && form.get('divisionId').touched\">\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <p>Division must not be empty.</p>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >Client Name <span style=\"color: #FF6347;\">*</span></ion-label>\n          <ion-input type=\"text\" autocomplete autocorrect formControlName=\"name\"></ion-input>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n    <ion-row *ngIf=\"!form.get('name').valid && form.get('name').touched\">\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <p style=\"font-size: small;color:#FF6347\">Client Name must not be empty.</p>\n      </ion-col>\n    </ion-row>\n\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >GST Number <span style=\"color: #FF6347;\">*</span></ion-label>\n          <ion-input type=\"text\" autocomplete autocorrect formControlName=\"gstNumber\"></ion-input>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n    <ion-row *ngIf=\"!form.get('gstNumber').valid && form.get('gstNumber').touched\">\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <p style=\"font-size: small;color:#FF6347\">GST number must not be empty & It should be 15-digit number</p>\n      </ion-col>\n    </ion-row>\n\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >Existing Group</ion-label>\n          <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"cmbClientGroup\">\n            <ion-select-option *ngFor=\"let clgrp of clientGroup\" [value]=\"clgrp\">{{clgrp}}\n            </ion-select-option>\n          </ion-select>\n    </ion-item>\n    </ion-col>\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\n      <ion-item>\n        <ion-label position=\"floating\" style=\"font-size: 12px;\">New Group</ion-label>\n        <ion-input type=\"text\" formControlName=\"clientGroup\" (ionChange)=\"updateNewGroup()\" ></ion-input>\n  </ion-item>\n  </ion-col>\n    </ion-row>\n\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >Client Type <span style=\"color: #FF6347;\">*</span></ion-label>\n          <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"typeId\" multiple>\n            <ion-select-option *ngFor=\"let clientType of clientTypeList\" [value]=\"clientType.id\">{{clientType.name}}\n            </ion-select-option>\n          </ion-select>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n    <ion-row *ngIf=\"!form.get('typeId').valid && form.get('typeId').touched\">\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <p style=\"font-size: small;color:#FF6347\">Client Type must not be empty.</p>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >Contact Person <span style=\"color: #FF6347;\">*</span></ion-label>\n          <ion-input type=\"text\" autocomplete autocorrect formControlName=\"contactPerson\"></ion-input>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n    <ion-row *ngIf=\"!form.get('contactPerson').valid && form.get('contactPerson').touched\">\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <p style=\"font-size: small;color:#FF6347\">Contact Person must not be empty.</p>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >Contact Number <span style=\"color: #FF6347;\">*</span></ion-label>\n          <ion-input type=\"number\" formControlName=\"contactNumber\"></ion-input>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n    <!-- <ion-row *ngIf=\"!form.get('contactNumber').valid && form.get('contactNumber').touched\">\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <p style=\"font-size: small;color:#FF6347\">Contact Number must not be empty.</p>\n      </ion-col>\n    </ion-row> -->\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >Email <span style=\"color: #FF6347;\">*</span></ion-label>\n          <ion-input type=\"text\" autocomplete autocorrect formControlName=\"email\"></ion-input>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n    <!-- <ion-row *ngIf=\"!form.get('email').valid && form.get('email').touched\">\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <p style=\"font-size: small;color:#FF6347\">Should be a valid email address.</p>\n      </ion-col>\n    </ion-row> -->\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >Potential Nature <span style=\"color: #FF6347;\">*</span></ion-label>\n          <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"potentialNatureId\">\n            <ion-select-option *ngFor=\"let pn of potentialNatureList\" [value]=\"pn.id\">{{pn.name}}\n            </ion-select-option>\n          </ion-select>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n    <ion-row *ngIf=\"!form.get('potentialNatureId').valid && form.get('potentialNatureId').touched\">\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <p style=\"font-size: small;color:#FF6347\">Potential Nature must not be empty.</p>\n      </ion-col>\n    </ion-row>\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Employee Strength</ion-label>\n            <ion-input type=\"number\" formControlName=\"employeeStrength\"></ion-input>\n      </ion-item>\n      </ion-col>\n      </ion-row>\n\n    <ion-row>\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >Account Owner <span style=\"color: #FF6347;\">*</span></ion-label>\n          <ion-input type=\"text\" autocomplete autocorrect formControlName=\"accountOwner\"></ion-input>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n    <ion-row *ngIf=\"!form.get('accountOwner').valid && form.get('accountOwner').touched\">\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <p style=\"font-size: small;color:#FF6347\">Account Owner Nature must not be empty.</p>\n      </ion-col>\n    </ion-row>\n\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >Country</ion-label>\n          <ion-select placeholder=\"Select One\"  interface=\"popover\" (ionChange)=\"onChangeCountry($event)\" formControlName=\"ddCountry\">\n            <ion-select-option *ngFor=\"let country of countries\" [value]=\"country\">{{country}}\n            </ion-select-option>\n          </ion-select>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >Region</ion-label>\n          <ion-select  placeholder=\"Select One\"  interface=\"popover\" (ionChange)=\"onChangeRegion($event)\" formControlName=\"ddRegion\">\n            <ion-select-option *ngFor=\"let region of regions\" [value]=\"region\">{{region}}\n            </ion-select-option>\n          </ion-select>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >Sub Region</ion-label>\n          <ion-select placeholder=\"Select One\"  interface=\"popover\" (ionChange)=\"onChangeSubRegion($event)\" formControlName=\"ddSubRegion\">\n            <ion-select-option *ngFor=\"let subregion of subregions\" [value]=\"subregion\">{{subregion}}\n            </ion-select-option>\n          </ion-select>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >State</ion-label>\n          <ion-select placeholder=\"Select One\"  interface=\"popover\" (ionChange)=\"onChangeStates($event)\"  formControlName=\"ddState\">\n            <ion-select-option *ngFor=\"let state of states\" [value]=\"state\">{{state}}\n            </ion-select-option>\n          </ion-select>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-item>\n          <ion-label position=\"floating\" >City</ion-label>\n          <ion-select placeholder=\"Select One\"  interface=\"popover\"   formControlName=\"ddCity\">\n            <ion-select-option *ngFor=\"let city of cities\" [value]=\"city\">{{city}}\n            </ion-select-option>\n          </ion-select>\n    </ion-item>\n    </ion-col>\n    </ion-row>\n\n\n\n  </ion-grid>\n</form>\n\n</ion-content>\n");

/***/ }),

/***/ "JCj0":
/*!***********************************************************!*\
  !*** ./src/app/clients/edit-client/edit-client.module.ts ***!
  \***********************************************************/
/*! exports provided: EditClientPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditClientPageModule", function() { return EditClientPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _edit_client_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./edit-client-routing.module */ "ToIR");
/* harmony import */ var _edit_client_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit-client.page */ "7BeS");







let EditClientPageModule = class EditClientPageModule {
};
EditClientPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _edit_client_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditClientPageRoutingModule"]
        ],
        declarations: [_edit_client_page__WEBPACK_IMPORTED_MODULE_6__["EditClientPage"]]
    })
], EditClientPageModule);



/***/ }),

/***/ "SKY3":
/*!***********************************************************!*\
  !*** ./src/app/clients/edit-client/edit-client.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".componentWrapper {\n  border: solid cadetblue;\n  border-radius: 40px;\n  padding: 15px 10px 10px 10px;\n  margin-top: 20px;\n  width: 95%;\n}\n\n.componentWrapper .header {\n  position: absolute;\n  margin-top: -25px;\n  margin-left: 10px;\n  color: white;\n  background: cadetblue;\n  border-radius: 10px;\n  padding: 2px 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxlZGl0LWNsaWVudC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsNEJBQUE7RUFDQSxnQkFBQTtFQUNBLFVBQUE7QUFDRjs7QUFFQTtFQUNFLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUFDRiIsImZpbGUiOiJlZGl0LWNsaWVudC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29tcG9uZW50V3JhcHBlciB7XHJcbiAgYm9yZGVyOiBzb2xpZCBjYWRldGJsdWU7XHJcbiAgYm9yZGVyLXJhZGl1czogNDBweDtcclxuICBwYWRkaW5nOiAxNXB4IDEwcHggMTBweCAxMHB4O1xyXG4gIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgd2lkdGg6IDk1JTtcclxufVxyXG5cclxuLmNvbXBvbmVudFdyYXBwZXIgLmhlYWRlciB7XHJcbiAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgbWFyZ2luLXRvcDotMjVweDtcclxuICBtYXJnaW4tbGVmdDoxMHB4O1xyXG4gIGNvbG9yOndoaXRlO1xyXG4gIGJhY2tncm91bmQ6Y2FkZXRibHVlO1xyXG4gIGJvcmRlci1yYWRpdXM6MTBweDtcclxuICBwYWRkaW5nOjJweCAxMHB4O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "ToIR":
/*!*******************************************************************!*\
  !*** ./src/app/clients/edit-client/edit-client-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: EditClientPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditClientPageRoutingModule", function() { return EditClientPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _edit_client_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./edit-client.page */ "7BeS");




const routes = [
    {
        path: '',
        component: _edit_client_page__WEBPACK_IMPORTED_MODULE_3__["EditClientPage"]
    }
];
let EditClientPageRoutingModule = class EditClientPageRoutingModule {
};
EditClientPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditClientPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=edit-client-edit-client-module.js.map