(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-demo-request-edit-demo-request-module"],{

/***/ "EwnK":
/*!*****************************************************************************!*\
  !*** ./src/app/salespipeline/edit-demo-request/edit-demo-request.module.ts ***!
  \*****************************************************************************/
/*! exports provided: EditDemoRequestPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditDemoRequestPageModule", function() { return EditDemoRequestPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _edit_demo_request_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./edit-demo-request-routing.module */ "cgzv");
/* harmony import */ var _edit_demo_request_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit-demo-request.page */ "iXnW");







let EditDemoRequestPageModule = class EditDemoRequestPageModule {
};
EditDemoRequestPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _edit_demo_request_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditDemoRequestPageRoutingModule"]
        ],
        declarations: [_edit_demo_request_page__WEBPACK_IMPORTED_MODULE_6__["EditDemoRequestPage"]]
    })
], EditDemoRequestPageModule);



/***/ }),

/***/ "JB3t":
/*!*****************************************************************************!*\
  !*** ./src/app/salespipeline/edit-demo-request/edit-demo-request.page.scss ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlZGl0LWRlbW8tcmVxdWVzdC5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "cgzv":
/*!*************************************************************************************!*\
  !*** ./src/app/salespipeline/edit-demo-request/edit-demo-request-routing.module.ts ***!
  \*************************************************************************************/
/*! exports provided: EditDemoRequestPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditDemoRequestPageRoutingModule", function() { return EditDemoRequestPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _edit_demo_request_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./edit-demo-request.page */ "iXnW");




const routes = [
    {
        path: '',
        component: _edit_demo_request_page__WEBPACK_IMPORTED_MODULE_3__["EditDemoRequestPage"]
    }
];
let EditDemoRequestPageRoutingModule = class EditDemoRequestPageRoutingModule {
};
EditDemoRequestPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditDemoRequestPageRoutingModule);



/***/ }),

/***/ "iXnW":
/*!***************************************************************************!*\
  !*** ./src/app/salespipeline/edit-demo-request/edit-demo-request.page.ts ***!
  \***************************************************************************/
/*! exports provided: EditDemoRequestPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditDemoRequestPage", function() { return EditDemoRequestPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_edit_demo_request_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./edit-demo-request.page.html */ "s/fy");
/* harmony import */ var _edit_demo_request_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit-demo-request.page.scss */ "JB3t");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_services_division_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/division.service */ "KWQH");
/* harmony import */ var src_app_utilities_dataconverters__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/utilities/dataconverters */ "igNZ");
/* harmony import */ var _services_demo_request_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../services/demo-request.service */ "4ttV");











let EditDemoRequestPage = class EditDemoRequestPage {
    constructor(demoRequestService, route, navCtrl, toastController, router, divisionService) {
        this.demoRequestService = demoRequestService;
        this.route = route;
        this.navCtrl = navCtrl;
        this.toastController = toastController;
        this.router = router;
        this.divisionService = divisionService;
        this.isLoading = false;
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.route.paramMap.subscribe((paramMap) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                if (!paramMap.has('demoId')) {
                    this.navCtrl.navigateBack('/salespipeline/demorequests');
                    return;
                }
                this.perPipe = new _angular_common__WEBPACK_IMPORTED_MODULE_3__["PercentPipe"]('en-US');
                this.demoId = paramMap.get('demoId');
                this.isLoading = true;
            }));
        });
    }
    ionViewWillEnter() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = true;
            this.demoRequestService.getDemoRequestById(this.demoId).subscribe((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                this.demoRequest = res;
                yield this.loadMachineDetails();
                yield this.loadStockDetails();
                yield this.loadInstallKitDetails();
                yield this.loadBranches();
                var result = this.initializeForm();
                this.isLoading = false;
            }));
        });
    }
    initializeForm() {
        let machineArray = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormArray"]([]);
        let materialArray = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormArray"]([]);
        this.demoRequest.machineDetails.forEach(element => {
            machineArray.push(this.createMachineDetail(element));
        });
        this.demoRequest.materialDetails.forEach(element => {
            materialArray.push(this.createMaterialDetail(element));
        });
        let res = this.initDependantDropDown();
        console.log(this.demoRequest);
        this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            machineDetails: machineArray,
            materialDetails: materialArray,
            orgName: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.orgName, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            orgStatus: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.orgStatus, {
                updateOn: 'blur',
            }),
            address: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.address, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            addLocation: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.addLocation, {
                updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]
            }),
            addPincode: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.addPincode, {
                updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]
            }),
            addState: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.addState, {
                updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]
            }),
            conName: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.conName, { updateOn: 'blur' }),
            conMobile: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.conMobile, {
                updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]
            }),
            conEmail: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.conEmail, {
                updateOn: 'blur',
            }),
            accInstallation: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.accInstallation, {
                updateOn: 'blur',
            }),
            accOther: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.accOther, {
                updateOn: 'blur',
            }),
            instDemo: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.instDemo, {
                updateOn: 'blur',
            }),
            dateDC: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.dateDC == null ? Object(src_app_utilities_dataconverters__WEBPACK_IMPORTED_MODULE_9__["convertTimeStampToDate"])(this.demoRequest.createdOn).toISOString() : this.demoRequest.dateDC, {
                updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]
            }),
            dateDelivery: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.dateDelivery, {
                updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]
            }),
            dateDemo: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.dateDemo, {
                updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]
            }),
            dateEndDemo: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.dateEndDemo, {
                updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]
            }),
            datePickup: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.datePickup, {
                updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]
            }),
            satGSTNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.satGSTNo, {
                updateOn: 'blur',
            }),
            taxType: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.taxType, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            satSEZ: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.satSEZ, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            satBranch: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.satBranch, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            cnsNoEmp: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.cnsNoEmp, {
                updateOn: 'blur',
            }),
            cnsNoCups: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.demoRequest.cnsNoCups, {
                updateOn: 'blur',
            }),
        });
        return true;
    }
    editDemoRequest() {
        if (!this.form.valid) {
            return;
        }
        let demoRequest = this.form.value;
        if (demoRequest.machineDetails.length == 0
            || demoRequest.materialDetails.length == 0) {
            return;
        }
        demoRequest.reqStatus = 'Demo Request Created';
        demoRequest.id = this.demoRequest.id;
        demoRequest.salespipelineId = this.demoRequest.salespipelineId;
        this.demoRequestService
            .editDemoRequest(demoRequest, this.demoId)
            .subscribe((res) => {
            this.toastController
                .create({
                message: 'Demo Request Updated. Id:' + this.demoRequest.srNo,
                duration: 2000,
                color: 'success',
            })
                .then((tost) => {
                tost.present();
                this.router.navigate(['/salespipeline/demorequests']);
            });
        });
    }
    createMachineDetail(machine) {
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            machineName: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](machine != null ? machine['machineName'] : null, {
                updateOn: "blur",
            }),
            machineType: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](machine != null ? machine['machineType'] : null, {
                updateOn: "blur",
            }),
            volumeType: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](machine != null ? machine['volumeType'] : null, {
                updateOn: "blur",
            }),
            machineCount: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](machine != null ? machine['machineCount'] : null, {
                updateOn: "blur",
            }),
            machinesrno: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](machine != null ? machine['machinesrno'] : null, {
                updateOn: "blur",
            }),
            machinehsnNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](machine != null ? machine['machinehsnNo'] : null, {
                updateOn: "blur",
            }),
            machinerate: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](machine != null ? machine['machinerate'] : null, {
                updateOn: "blur",
            })
        });
    }
    createMaterialDetail(material) {
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            category: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](material != null ? material['category'] : null, {
                updateOn: "blur",
            }),
            item: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](material != null ? material['item'] : null, {
                updateOn: "blur",
            }),
            uom: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](material != null ? material['uom'] : null, {
                updateOn: "blur",
            }),
            hsnNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](material != null ? material['hsnNo'] : null, {
                updateOn: "blur",
            }),
            gst: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](material != null ? material['gst'] : null, {
                updateOn: "blur",
            }),
            qty: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](material != null ? material['qty'] : null, {
                updateOn: "blur",
            }),
            rate: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](material != null ? material['rate'] : null, {
                updateOn: "blur",
            }),
        });
    }
    addMachine() {
        let mchdetails = this.form.get('machineDetails');
        mchdetails.push(this.createMachineDetail());
    }
    deleteMachine(index) {
        let mchdetails = this.form.get('machineDetails');
        mchdetails.removeAt(index);
    }
    addMaterial() {
        let matdetails = this.form.get('materialDetails');
        matdetails.push(this.createMaterialDetail());
    }
    deleteMaterial(index) {
        let matdetails = this.form.get('materialDetails');
        matdetails.removeAt(index);
    }
    loadMachineDetails() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.machineDetail = yield this.divisionService.getMachineDetailList();
            this.machines = this.machineDetail.filter(item => item.group == 0).sort((a, b) => a.srno - b.srno).map(item => item.name);
            this.machineType = this.machineDetail.filter(item => item.group == 1).sort((a, b) => a.srno - b.srno).map(item => item.name);
            return true;
        });
    }
    loadStockDetails() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.stockDetail = yield this.divisionService.getStock();
            this.stockCategory = this.stockDetail.map(item => item.category).filter((value, index, self) => self.indexOf(value) === index).sort();
            return true;
        });
    }
    loadInstallKitDetails() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.installkit = yield this.divisionService.getInstallKits();
            this.installkititems = this.installkit.map(item => item.item).sort();
            return true;
        });
    }
    loadBranches() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.branches = yield this.divisionService.getBranches();
            return true;
        });
    }
    onMachineChange(event, element) {
        if (!event.target.value)
            return;
        let ref = this.machineDetail.filter(item => item.name == event.target.value)[0].name;
        element.controls['volumeType'].reset();
        this.machineCategory = [];
        this.machineCategory = this.machineDetail.filter(item => item.ref == ref && item.group == 2).sort((a, b) => a.srno - b.srno).map(item => item.name);
        if (ref == "FM" || ref == "Mtl(kg/mth)") {
            element.controls['volumeType'].patchValue("Not Applicable", { emitEvent: false });
        }
    }
    onMaterialChange(event, element) {
        if (!event.target.value)
            return;
        let ref = this.stockDetail.filter(item => item.category == event.target.value)[0].category;
        element.controls['item'].reset();
        this.stockType = [];
        element.controls['uom'].patchValue(null, { emitEvent: false });
        element.controls['hsnNo'].patchValue(null, { emitEvent: false });
        element.controls['gst'].patchValue(null, { emitEvent: false });
        this.stockType = this.stockDetail.filter(item => item.category == ref).map(item => item.item).sort();
    }
    initDependantDropDown() {
        this.machineCategory = [];
        this.machineCategory = this.machineDetail.sort((a, b) => a.srno - b.srno).map(item => item.name);
        this.stockType = [];
        this.stockType = this.stockDetail.map(item => item.item).sort();
        return true;
    }
    onMaterialTypeChange(event, element) {
        if (!event.target.value)
            return;
        let ref = this.stockDetail.filter(item => item.item == event.target.value)[0];
        element.controls['uom'].patchValue(ref.uom, { emitEvent: false });
        element.controls['hsnNo'].patchValue(ref.hsnNo, { emitEvent: false });
        element.controls['gst'].patchValue(this.perPipe.transform(ref.gst), { emitEvent: false });
    }
};
EditDemoRequestPage.ctorParameters = () => [
    { type: _services_demo_request_service__WEBPACK_IMPORTED_MODULE_10__["DemoRequestService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: src_app_services_division_service__WEBPACK_IMPORTED_MODULE_8__["DivisionService"] }
];
EditDemoRequestPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-edit-demo-request',
        template: _raw_loader_edit_demo_request_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_edit_demo_request_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], EditDemoRequestPage);



/***/ }),

/***/ "s/fy":
/*!*******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/salespipeline/edit-demo-request/edit-demo-request.page.html ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref=\"/salespipeline/demorequests\">\n      </ion-back-button>\n      <ion-title>Edit Demo Req. Form</ion-title>\n      <ion-button (click)=\"editDemoRequest()\"  [disabled]=\"!form?.valid\">\n        <ion-icon name=\"checkmark\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <form [formGroup]=\"form\" *ngIf=\"!isLoading\">\n    <ion-grid>\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Organization</span><span style=\"color: #FF6347;\">*</span>\n            <ion-item>\n              <ion-input type=\"text\" autocomplete autocorrect placeholder=\"Client Name\" formControlName=\"orgName\">\n              </ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('orgName').valid && form.get('orgName').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Client name should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Client Status</ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"orgStatus\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </div>\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Statutory Detail</span>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" class=\"label\">Tax Type\n            </ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"taxType\">\n              <ion-select-option [value]=\"CGSTSGST\">CGST/SGST</ion-select-option>\n                <ion-select-option [value]=\"IGST\">IGST\n              </ion-select-option>\n              </ion-select>\n\n              <!-- <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"satSEZ\">\n                <ion-select-option value=\"Yes\">Yes</ion-select-option>\n                <ion-select-option value=\"No\">No</ion-select-option>\n              </ion-select> -->\n\n          </ion-item>\n          </ion-col>\n          </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">GST No</ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"satGSTNo\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">SEZ\n              </ion-label>\n              <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"satSEZ\">\n                <ion-select-option value=\"Yes\">Yes</ion-select-option>\n                <ion-select-option value=\"No\">No</ion-select-option>\n              </ion-select>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('satSEZ').valid && form.get('satSEZ').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Please select SEZ/Non SEZ.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Branch\n              </ion-label>\n              <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"satBranch\">\n                <ion-select-option *ngFor=\"let branch of branches\" [value]=\"branch.name\">{{branch.name}}\n                </ion-select-option>\n              </ion-select>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('satBranch').valid && form.get('satBranch').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Please select brach for challan address.</p>\n          </ion-col>\n        </ion-row>\n\n      </div>\n\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Address of the Demonstration</span><span style=\"color: #FF6347;\">*</span>\n            <ion-item>\n              <ion-input type=\"text\" autocomplete autocorrect placeholder=\"Address\" formControlName=\"address\">\n              </ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('address').valid && form.get('address').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Address should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Location<span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"addLocation\"></ion-input>\n            </ion-item>\n          </ion-col>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Pin Code<span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"addPincode\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('addLocation').valid && form.get('addLocation').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Location should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('addPincode').valid && form.get('addPincode').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Pincode should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">State<span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"addState\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('addState').valid && form.get('addState').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">State should not be empty.</p>\n          </ion-col>\n        </ion-row>\n      </div>\n\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Contact Person</span><span style=\"color: #FF6347;\">*</span>\n            <ion-item>\n              <ion-input type=\"text\" autocomplete autocorrect placeholder formControlName=\"conName\" placeholder='Name'>\n              </ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('conName').valid && form.get('conName').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Contact Person should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Mobile No<span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"conMobile\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('conMobile').valid && form.get('conMobile').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Mobile number should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Email</ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"conEmail\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </div>\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Machine detail</span><span style=\"color: #FF6347;\">*</span>\n          </ion-col>\n        </ion-row>\n        <div *ngFor=\"let item of form.get('machineDetails')['controls']; let i = index;\" formArrayName=\"machineDetails\">\n          <div [formGroupName]=\"i\">\n            <ion-row>\n              <ion-col size=\"10\">\n                <ion-row>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Machine\n                      </ion-label>\n                      <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineName\" (ionChange)=\"onMachineChange($event,form.get('machineDetails')['controls'][i])\">\n                        <ion-select-option *ngFor=\"let machine of machines\" [value]=\"machine\">{{machine}}\n                        </ion-select-option>\n                        </ion-select>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Type\n                      </ion-label>\n                      <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineType\">\n                        <ion-select-option *ngFor=\"let machine of machineType\" [value]=\"machine\">{{machine}}\n                        </ion-select-option>\n                        </ion-select>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Category\n                      </ion-label>\n                      <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"volumeType\">\n                        <ion-select-option *ngFor=\"let machine of machineCategory\" [value]=\"machine\">{{machine}}\n                        </ion-select-option>\n                        </ion-select>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">No.of Machine\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"machineCount\"></ion-input>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Machine Serial Number\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"machinesrno\"></ion-input>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">HSN Number\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"machinehsnNo\"></ion-input>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Rate (* applicable for SEZ)\n                      </ion-label>\n                      <ion-input type=\"Number\" autocomplete autocorrect formControlName=\"machinerate\"></ion-input>\n                    </ion-item>\n                  </ion-col>\n                </ion-row>\n              </ion-col>\n              <ion-col size=\"2\">\n                <div style=\"height: 95%; border-left:2px solid #FF69B4\">\n                  <ion-button size=\"small\" class=\" button-assertive button-clear\" style=\"margin-top: 75px;\"\n                    (click)=\"deleteMachine(i)\">\n                    <ion-icon name=\"trash\" slot=\"icon-only\"></ion-icon>\n                  </ion-button>\n                </div>\n              </ion-col>\n            </ion-row>\n          </div>\n        </div>\n        <ion-row>\n          <ion-col size=\"12\">\n            <ion-button size=\"small\" (click)=\"addMachine()\">\n              <ion-icon name=\"add-circle\"></ion-icon> Add Machine\n            </ion-button>\n          </ion-col>\n        </ion-row>\n      </div>\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Accessories</span>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Installation/Demo Kit</ion-label>\n              <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"accInstallation\" multiple>\n                <ion-select-option *ngFor=\"let kit of installkititems\" [value]=\"kit\">{{kit}}\n                </ion-select-option>\n                </ion-select>\n            </ion-item>\n          </ion-col>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Other Accessories</ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"accOther\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </div>\n\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Terms of Installation</span>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Demo</ion-label>\n              <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"instDemo\">\n                <ion-select-option value=\"Free\">Free</ion-select-option>\n                <ion-select-option value=\"Chargeble\">Chargeble</ion-select-option>\n              </ion-select>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </div>\n\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Date</span>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">DC Date<span style=\"color: #FF6347;\">*</span>\n              </ion-label>\n              <ion-datetime formControlName=\"dateDC\" display-format=\"MMM DD YYYY\" picker-format=\"YY MMM DD\">\n              </ion-datetime>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Date of Delivery<span style=\"color: #FF6347;\">*</span>\n              </ion-label>\n              <ion-datetime formControlName=\"dateDelivery\" display-format=\"MMM DD YYYY\" picker-format=\"YY MMM DD\">\n              </ion-datetime>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('dateDelivery').valid && form.get('dateDelivery').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Date of Delivery should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Start Date of Demo<span style=\"color: #FF6347;\">*</span>\n              </ion-label>\n              <ion-datetime formControlName=\"dateDemo\" display-format=\"MMM DD YYYY\" picker-format=\"YY MMM DD\">\n              </ion-datetime>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('dateDemo').valid && form.get('dateDemo').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Start Date of Demo should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">End Date of Demo<span style=\"color: #FF6347;\">*</span>\n              </ion-label>\n              <ion-datetime formControlName=\"dateEndDemo\" display-format=\"MMM DD YYYY\" picker-format=\"YY MMM DD\">\n              </ion-datetime>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('dateEndDemo').valid && form.get('dateEndDemo').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">End Date of Demo should not be empty.</p>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">Date of Pickup<span style=\"color: #FF6347;\">*</span>\n              </ion-label>\n              <ion-datetime formControlName=\"datePickup\" display-format=\"MMM DD YYYY\" picker-format=\"YY MMM DD\">\n              </ion-datetime>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"!form.get('datePickup').valid && form.get('datePickup').touched\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <p style=\"font-size: small;color:#FF6347\">Date of Pickup should not be empty.</p>\n          </ion-col>\n        </ion-row>\n      </div>\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Details of Consumption</span>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">No.Employee\n              </ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"cnsNoEmp\"></ion-input>\n            </ion-item>\n          </ion-col>\n          <ion-col size-sm=\"3\" offset-sm=\"3\">\n            <ion-item>\n              <ion-label position=\"floating\" class=\"label\">No.of Cups /day</ion-label>\n              <ion-input type=\"text\" autocomplete autocorrect formControlName=\"cnsNoCups\"></ion-input>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </div>\n\n      <div class=\"section\">\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <span style=\"font-size:13px\">Details of Material</span><span style=\"color: #FF6347;\">*</span>\n          </ion-col>\n        </ion-row>\n        <div *ngFor=\"let item of form.get('materialDetails')['controls']; let i = index;\"\n          formArrayName=\"materialDetails\">\n          <div [formGroupName]=\"i\">\n            <ion-row>\n              <ion-col size=\"10\">\n                <ion-row>\n                  <ion-col size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Material\n                      </ion-label>\n                      <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"category\" (ionChange)=\"onMaterialChange($event,form.get('materialDetails')['controls'][i])\">\n                        <ion-select-option *ngFor=\"let stock of stockCategory\" [value]=\"stock\">{{stock}}\n                        </ion-select-option>\n                        </ion-select>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col  size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Type\n                      </ion-label>\n                      <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"item\" (ionChange)=\"onMaterialTypeChange($event,form.get('materialDetails')['controls'][i])\">\n                        <ion-select-option *ngFor=\"let stock of stockType\" [value]=\"stock\">{{stock}}\n                        </ion-select-option>\n                        </ion-select>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item color=\"success\">\n                      <ion-label position=\"floating\" class=\"label\"  style=\"color: #fff;\">UOM\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"uom\" readonly></ion-input>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item  color=\"success\">\n                      <ion-label position=\"floating\" class=\"label\"  style=\"color: #fff;\">HSNCode\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"hsnNo\" readonly></ion-input>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item  color=\"success\">\n                      <ion-label position=\"floating\" class=\"label\" style=\"color: #fff;\">GST\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"gst\"\n                      [value]=\"item.get('gst').value\"\n                      readonly></ion-input>\n                    </ion-item>\n                  </ion-col>\n                  <ion-col  size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Qty\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"qty\"></ion-input>\n                    </ion-item>\n                  </ion-col>\n                </ion-row>\n                <ion-row>\n                  <ion-col  size=\"12\">\n                    <ion-item>\n                      <ion-label position=\"floating\" class=\"label\">Rate (* Applicable for SEZ)\n                      </ion-label>\n                      <ion-input type=\"text\" autocomplete autocorrect formControlName=\"rate\"></ion-input>\n                    </ion-item>\n                  </ion-col>\n                </ion-row>\n              </ion-col>\n\n\n              <ion-col size=\"2\">\n                <div style=\"height: 95%; border-left:2px solid #FF69B4;\">\n                  <ion-button size=\"small\" class=\" button-assertive button-clear\" style=\"margin-top: 75px;\"\n                    (click)=\"deleteMaterial(i)\">\n                    <ion-icon name=\"trash\" slot=\"icon-only\"></ion-icon>\n                  </ion-button>\n                </div>\n              </ion-col>\n            </ion-row>\n          </div>\n        </div>\n        <ion-row>\n          <ion-col size-sm=\"6\" offset-sm=\"3\">\n            <ion-button size=\"small\" (click)=\"addMaterial()\">\n              <ion-icon name=\"add-circle\"></ion-icon> Add Material\n            </ion-button>\n          </ion-col>\n        </ion-row>\n      </div>\n    </ion-grid>\n  </form>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=edit-demo-request-edit-demo-request-module.js.map