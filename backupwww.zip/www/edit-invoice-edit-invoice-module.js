(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-invoice-edit-invoice-module"],{

/***/ "FeOa":
/*!*****************************************************************!*\
  !*** ./src/app/salespipeline/edit-invoice/edit-invoice.page.ts ***!
  \*****************************************************************/
/*! exports provided: EditInvoicePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditInvoicePage", function() { return EditInvoicePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_edit_invoice_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./edit-invoice.page.html */ "sJ4I");
/* harmony import */ var _edit_invoice_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit-invoice.page.scss */ "RaJN");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_utilities_dataconverters__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/utilities/dataconverters */ "igNZ");
/* harmony import */ var _salespipeline_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../salespipeline.service */ "bL0d");










let EditInvoicePage = class EditInvoicePage {
    constructor(route, navCtrl, salesService, toastController, router, datePipe) {
        this.route = route;
        this.navCtrl = navCtrl;
        this.salesService = salesService;
        this.toastController = toastController;
        this.router = router;
        this.datePipe = datePipe;
        this.isLoading = true;
        this.invId = "";
        this.invoiceMonth = [];
    }
    doRefresh(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = true;
            this.invoiceMonth = yield this.salesService.getInvoiceMonth();
            this.invoice = yield this.salesService.getInvoiceById(this.invId);
            var result = this.initializeUpdateForm();
            this.isLoading = false;
            if (event != null) {
                event.target.complete();
            }
        });
    }
    ngOnInit() {
        this.route.paramMap.subscribe((paramMap) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!paramMap.has('invId')) {
                this.navCtrl.navigateBack('/salespipeline');
            }
            this.invId = paramMap.get('invId');
            this.doRefresh(null);
        }));
    }
    editInvoice() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!this.form.valid) {
                return;
            }
            if (this.invoice.srNo.startsWith("I/M") || this.invoice.srNo.startsWith("INV/Machine")) {
                yield this.updateInstalltionInvoice(this.form);
            }
            else {
                let invoiceModel = this.form.value;
                this.salesService
                    .addupdateInvoice({ id: this.invoice.id,
                    ponumber: invoiceModel.ponumber,
                    mchRent: invoiceModel.rent,
                    billName: invoiceModel.billName,
                    billAddress: invoiceModel.billAddress,
                    installAt: invoiceModel.installAt,
                    installAddress: invoiceModel.installAddress,
                    status: invoiceModel.status,
                    recAmount: invoiceModel.recAmount,
                    tranCharges: invoiceModel.tranCharges,
                    modifiedOn: new Date(),
                    createdOn: new Date(invoiceModel.createdOn),
                    displaymonth: this.datePipe.transform(new Date(invoiceModel.createdOn), 'MMM-yyyy')
                }, true).subscribe((res) => {
                    this.toastController
                        .create({
                        message: 'Data updated',
                        duration: 2000,
                        color: 'success',
                    })
                        .then((tost) => {
                        tost.present();
                        this.router.navigate(['/salespipeline/invoicelist/' + this.invoice.clientLocationId]);
                    });
                });
            }
        });
    }
    updateInstalltionInvoice(fm) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let invoiceModel = fm.value;
            let invamt = 0;
            let tranCharges = invoiceModel.tranCharges;
            this.invoice.dc.forEach(element => {
                element['machineDetails'].forEach(mch => {
                    invamt = invamt + Number(mch.mchInstCharges);
                });
            });
            yield this.salesService
                .addupdateInvoice({ id: this.invoice.id,
                ponumber: invoiceModel.ponumber,
                mchRent: invoiceModel.rent,
                billName: invoiceModel.billName,
                billAddress: invoiceModel.billAddress,
                installAt: invoiceModel.installAt,
                installAddress: invoiceModel.installAddress,
                status: invoiceModel.status,
                recAmount: invoiceModel.recAmount,
                tranCharges: invoiceModel.tranCharges,
                amount: invamt,
                totamount: invamt + invamt * 0.18,
                tax: invamt * 0.18,
                modifiedOn: new Date(),
                createdOn: new Date(invoiceModel.createdOn),
                displaymonth: this.datePipe.transform(new Date(invoiceModel.createdOn), 'MMM-yyyy')
            }, true).subscribe((res) => {
                this.toastController
                    .create({
                    message: 'Data updated',
                    duration: 2000,
                    color: 'success',
                })
                    .then((tost) => {
                    tost.present();
                    this.router.navigate(['/salespipeline/invoicelist/' + this.invoice.clientLocationId]);
                });
            });
        });
    }
    getMachineDetails(salesId, locationId) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let mchDetail = yield this.salesService.getSalesPiplineById(salesId);
            let loc = mchDetail.locations.filter((x) => x.id == locationId);
            if (loc.length > 0) {
                let rental = 0;
                let deposite = 0;
                let instCharges = 0;
                let consumableCap = 0;
                loc[0].machines.forEach((element) => {
                    rental = Number(rental) + Number(element.mchRent);
                    deposite = Number(deposite) + Number(element.mchSecDeposite);
                    (instCharges = Number(instCharges) + Number(element.mchInstCharges)),
                        (consumableCap =
                            Number(consumableCap) + Number(element.consumableCap));
                });
                let machineData = {
                    mchRent: rental,
                    mchdeposite: deposite,
                    mchinstCharges: instCharges,
                    consumableCap: consumableCap,
                    machineDetail: loc[0].machines,
                };
                return machineData;
            }
            return null;
        });
    }
    initializeUpdateForm() {
        this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            ponumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.invoice.ponumber, { updateOn: 'blur' }),
            createdOn: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](Object(src_app_utilities_dataconverters__WEBPACK_IMPORTED_MODULE_8__["convertTimeStampToDate"])(this.invoice.createdOn).toISOString(), { updateOn: 'blur' }),
            month: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.invoice.displaymonth, { updateOn: 'blur', validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required] }),
            rent: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.invoice.mchRent, { updateOn: 'blur' }),
            billName: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.invoice.billName, { updateOn: 'blur' }),
            billAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.invoice.billAddress, { updateOn: 'blur' }),
            installAt: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.invoice.installAt, { updateOn: 'blur' }),
            installAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.invoice.installAddress, { updateOn: 'blur' }),
            status: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.invoice.status, { updateOn: 'blur' }),
            recAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.invoice.recAmount, { updateOn: 'blur' }),
            tranCharges: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](this.invoice.tranCharges == null ? 0 : this.invoice.tranCharges, { updateOn: 'blur' }),
        });
    }
};
EditInvoicePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavController"] },
    { type: _salespipeline_service__WEBPACK_IMPORTED_MODULE_9__["SalespipelineService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["DatePipe"] }
];
EditInvoicePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-edit-invoice',
        template: _raw_loader_edit_invoice_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_edit_invoice_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], EditInvoicePage);



/***/ }),

/***/ "KKeL":
/*!*******************************************************************!*\
  !*** ./src/app/salespipeline/edit-invoice/edit-invoice.module.ts ***!
  \*******************************************************************/
/*! exports provided: EditInvoicePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditInvoicePageModule", function() { return EditInvoicePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _edit_invoice_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./edit-invoice-routing.module */ "YGET");
/* harmony import */ var _edit_invoice_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit-invoice.page */ "FeOa");







let EditInvoicePageModule = class EditInvoicePageModule {
};
EditInvoicePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _edit_invoice_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditInvoicePageRoutingModule"]
        ],
        declarations: [_edit_invoice_page__WEBPACK_IMPORTED_MODULE_6__["EditInvoicePage"]],
        providers: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"]
        ],
    })
], EditInvoicePageModule);



/***/ }),

/***/ "RaJN":
/*!*******************************************************************!*\
  !*** ./src/app/salespipeline/edit-invoice/edit-invoice.page.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlZGl0LWludm9pY2UucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "YGET":
/*!***************************************************************************!*\
  !*** ./src/app/salespipeline/edit-invoice/edit-invoice-routing.module.ts ***!
  \***************************************************************************/
/*! exports provided: EditInvoicePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditInvoicePageRoutingModule", function() { return EditInvoicePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _edit_invoice_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./edit-invoice.page */ "FeOa");




const routes = [
    {
        path: '',
        component: _edit_invoice_page__WEBPACK_IMPORTED_MODULE_3__["EditInvoicePage"]
    }
];
let EditInvoicePageRoutingModule = class EditInvoicePageRoutingModule {
};
EditInvoicePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditInvoicePageRoutingModule);



/***/ }),

/***/ "sJ4I":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/salespipeline/edit-invoice/edit-invoice.page.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref='/salespipeline'>\n      </ion-back-button>\n      <ion-title>Edit Invoice</ion-title>\n      <ion-button  (click)=\"editInvoice()\" [disabled]=\"!isLoading && !form.valid\">\n        <ion-icon name=\"checkmark\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <form [formGroup]=\"form\"  *ngIf=\"!isLoading\">\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <ion-item color=\"success\">\n          <ion-input type=\"text\" formControlName=\"month\" ReadOnly></ion-input>\n        </ion-item>\n\n        <ion-item>\n          <ion-label position=\"floating\" >Invoice Date <span style=\"color: #FF6347;\">*</span></ion-label>\n          <ion-datetime\n          formControlName=\"createdOn\"\n          display-format=\"MMM DD YYYY\"\n          picker-format=\"YY MMM DD\"\n          ></ion-datetime>\n        </ion-item>\n\n\n\n        <ion-item>\n              <ion-label position=\"floating\">PO Number<span style=\"color: #FF6347;\"></span></ion-label>\n              <ion-input type=\"text\" formControlName=\"ponumber\"></ion-input>\n        </ion-item>\n\n        <ion-item>\n          <ion-label position=\"floating\" >Transport Charges <span style=\"color: #FF6347;\">*</span></ion-label>\n          <ion-input type=\"number\" formControlName=\"tranCharges\"></ion-input>\n        </ion-item>\n\n            <ion-item>\n              <ion-label position=\"floating\">Billing Name<span style=\"color: #FF6347;\"></span></ion-label>\n              <ion-input type=\"text\" formControlName=\"billName\"></ion-input>\n            </ion-item>\n\n            <ion-item>\n              <ion-label position=\"floating\">Billing Address<span style=\"color: #FF6347;\"></span></ion-label>\n              <ion-textarea rows=\"4\" type=\"text\" formControlName=\"billAddress\"></ion-textarea>\n            </ion-item>\n\n            <ion-item>\n              <ion-label position=\"floating\">Installation At (Client Name)<span style=\"color: #FF6347;\"></span></ion-label>\n              <ion-input type=\"text\" formControlName=\"installAt\"></ion-input>\n            </ion-item>\n\n            <ion-item>\n              <ion-label position=\"floating\">Installation Address<span style=\"color: #FF6347;\"></span></ion-label>\n              <ion-textarea rows=\"4\" type=\"text\" formControlName=\"installAddress\"></ion-textarea>\n            </ion-item>\n            <ion-item style=\"display: none;\">\n              <ion-label position=\"floating\">Rent<span style=\"color: #FF6347;\"></span></ion-label>\n              <ion-input type=\"text\" formControlName=\"rent\"></ion-input>\n            </ion-item>\n\n            <ion-item>\n              <ion-label>Invoice Amount:{{invoice.totamount| currency:\"INR\":\"symbol\"}}</ion-label>\n            </ion-item>\n            <ion-item>\n              <ion-label position=\"floating\" >Invoice Status <span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"status\">\n                <ion-select-option value='Created'>Pending</ion-select-option>\n                <ion-select-option value='Pending'>Partial Payment Received</ion-select-option>\n                <ion-select-option value='Closed'>Full Payment Received</ion-select-option>\n              </ion-select>\n            </ion-item>\n            <ion-item>\n              <ion-label position=\"floating\" >Received Invoice Amount <span style=\"color: #FF6347;\">*</span></ion-label>\n              <ion-input type=\"number\" formControlName=\"recAmount\"></ion-input>\n            </ion-item>\n        </ion-col>\n        </ion-row>\n  </ion-grid>\n  </form>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=edit-invoice-edit-invoice-module.js.map