(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-sales-edit-sales-module"],{

/***/ "61sr":
/*!***********************************************************************!*\
  !*** ./src/app/salespipeline/edit-sales/edit-sales-routing.module.ts ***!
  \***********************************************************************/
/*! exports provided: EditSalesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditSalesPageRoutingModule", function() { return EditSalesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _edit_sales_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./edit-sales.page */ "XXZq");




const routes = [
    {
        path: '',
        component: _edit_sales_page__WEBPACK_IMPORTED_MODULE_3__["EditSalesPage"]
    }
];
let EditSalesPageRoutingModule = class EditSalesPageRoutingModule {
};
EditSalesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditSalesPageRoutingModule);



/***/ }),

/***/ "9QWD":
/*!***************************************************************!*\
  !*** ./src/app/salespipeline/edit-sales/edit-sales.module.ts ***!
  \***************************************************************/
/*! exports provided: EditSalesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditSalesPageModule", function() { return EditSalesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _edit_sales_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./edit-sales-routing.module */ "61sr");
/* harmony import */ var _edit_sales_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit-sales.page */ "XXZq");







let EditSalesPageModule = class EditSalesPageModule {
};
EditSalesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _edit_sales_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditSalesPageRoutingModule"]
        ],
        declarations: [_edit_sales_page__WEBPACK_IMPORTED_MODULE_6__["EditSalesPage"]]
    })
], EditSalesPageModule);



/***/ }),

/***/ "XXZq":
/*!*************************************************************!*\
  !*** ./src/app/salespipeline/edit-sales/edit-sales.page.ts ***!
  \*************************************************************/
/*! exports provided: EditSalesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditSalesPage", function() { return EditSalesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_edit_sales_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./edit-sales.page.html */ "bfQv");
/* harmony import */ var _edit_sales_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit-sales.page.scss */ "iofU");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var src_app_utilities_dataconverters__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/utilities/dataconverters */ "igNZ");
/* harmony import */ var _clients_client_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../clients/client.service */ "+RYs");
/* harmony import */ var _services_division_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../services/division.service */ "KWQH");
/* harmony import */ var _salespipeline_model__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../salespipeline.model */ "ZSGM");
/* harmony import */ var _salespipeline_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../salespipeline.service */ "bL0d");













let EditSalesPage = class EditSalesPage {
    constructor(route, navCtrl, clientService, router, loadingCtrl, alertCtrl, toastController, salesPipelineService, divisionService) {
        this.route = route;
        this.navCtrl = navCtrl;
        this.clientService = clientService;
        this.router = router;
        this.loadingCtrl = loadingCtrl;
        this.alertCtrl = alertCtrl;
        this.toastController = toastController;
        this.salesPipelineService = salesPipelineService;
        this.divisionService = divisionService;
        this.isLoading = false;
    }
    get locations() {
        return this.form.get('dataEntry');
    }
    addLocations() {
        this.locations.push(this.buildDataEntryForm());
    }
    deleteLocatios(index) {
        this.locations.removeAt(index);
    }
    getMachineDetails(fg) {
        let test = fg.get('machineDetails');
        return fg.get('machineDetails');
    }
    addMachineDetails(fg) {
        this.getMachineDetails(fg).push(this.buildMachineDetailForm());
    }
    deleteMachineDetails(fg, index) {
        this.getMachineDetails(fg).removeAt(index);
    }
    buildDataEntryForm(location, machines) {
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            machineDetails: machines != null ? machines : new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormArray"]([this.buildMachineDetailForm()]),
            city: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.city : null, {
                updateOn: 'blur',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            }),
            branchcity: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.branchcity : null, {
                updateOn: 'blur',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            }),
            isConsumable: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.isConsumable : null, {
                updateOn: 'blur',
            }),
            isRental: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.isRental : null, {
                updateOn: 'blur',
            }),
            renLimit: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.renLimit : null, {
                updateOn: 'blur',
            }),
            accowner: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.accowner : null, {
                updateOn: "blur",
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            }),
            address: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.address : null, {
                updateOn: 'blur',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            }),
            installAt: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.installAt : null, {
                updateOn: 'blur',
            }),
            installAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.installAddress : null, {
                updateOn: 'blur',
            }),
            branch: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.branch : null, {
                updateOn: 'blur',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            }),
            currentStatus: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.currentStatus : null, {
                updateOn: 'blur',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            }),
            hiddencurrentStatus: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.currentStatus : null, {
                updateOn: 'blur',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            }),
            closureDate: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? this.salesPipelineService.convertTimeStampToDate(location.closureDate).toJSON() : null, {
                updateOn: 'blur',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            }),
            amount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.amount : null, {
                updateOn: 'blur',
            }),
            billingAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.billingAmount : null, {
                updateOn: 'blur',
            }),
            machineCount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.machineCount : null, {
                updateOn: 'blur',
            }),
            id: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](location != null ? location.id : Object(src_app_utilities_dataconverters__WEBPACK_IMPORTED_MODULE_8__["GetNewId"])(), {
                updateOn: 'blur',
            }),
        });
    }
    buildMachineDetailForm(machine) {
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            machineName: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.machineName : null, {
                updateOn: 'blur',
            }),
            machineType: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.machineType : null, {
                updateOn: 'blur',
            }),
            volumeType: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.machineCategory : null, {
                updateOn: 'blur',
            }),
            machineCount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.machineCount : null, {
                updateOn: 'blur',
            }),
            machineSrNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.machineSrNo : null, {
                updateOn: 'blur',
            }),
            machinehsncode: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.machinehsncode : null, {
                updateOn: 'blur',
            }),
            rate: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.rate : null, {
                updateOn: 'blur',
            }),
            amount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.amount : null, {
                updateOn: 'blur',
            }),
            conflevel: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.conflevel : null, {
                updateOn: 'blur',
            }),
            billingAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.billingAmount : null, {
                updateOn: 'blur',
            }),
            mchRent: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.mchRent : null, {
                updateOn: 'blur',
            }),
            consumableCap: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.consumableCap : null, {
                updateOn: 'blur',
            }),
            mchInstCharges: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.mchInstCharges : null, {
                updateOn: 'blur',
            }),
            isInstChargesConsider: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.isInstChargesConsider : null, {
                updateOn: 'blur',
            }),
            mchSecDeposite: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.mchSecDeposite : null, {
                updateOn: 'blur',
            }),
            pulloutDate: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.pulloutDate : null, {
                updateOn: 'blur',
            }),
            pulloutreason: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](machine != null ? machine.pulloutreason : null, {
                updateOn: 'blur',
            }),
        });
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = true;
            this.route.paramMap.subscribe((paramMap) => {
                if (!paramMap.has('salesId')) {
                    this.navCtrl.navigateBack('/salespipeline');
                }
                this.saleId = paramMap.get('salesId');
            });
        });
    }
    loadSalesPipeline(saleId) {
        this.salesPipeSub = Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["combineLatest"])([
            this.salesPipelineService.getClientSalesPipeline(saleId),
            this.clientService.getClientList(),
            this.divisionService.getClientStatusList(),
            this.divisionService.getMachineDetailList()
        ]).subscribe((res) => {
            this.salesPipeline = res[0];
            this.clients = res[1];
            this.clientsStatus = res[2];
            this.machineDetail = res[3];
            this.machines = this.machineDetail.filter(item => item.group == 0).sort((a, b) => a.srno - b.srno).map(item => item.name);
            this.machineType = this.machineDetail.filter(item => item.group == 1).sort((a, b) => a.srno - b.srno).map(item => item.name);
            this.machineCategory = this.machineDetail.filter(item => item.group == 2).sort((a, b) => a.srno - b.srno).map(item => item.name);
            this.lastComment = res[0].comment;
            this.clientId = this.salesPipeline.clientId;
            if (this.salesPipeline.group != null) {
                this.loadedClients = this.clients.filter(item => item.group === this.salesPipeline.group);
            }
            else {
                this.loadedClients = this.clients;
            }
            this.clientGroup = this.clients
                .map((item) => item.group)
                .filter((value, index, self) => {
                if (value != null)
                    return self.indexOf(value) === index;
            });
            let locationArray = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormArray"]([]);
            this.salesPipeline.locations.forEach((item, i) => {
                let location = this.salesPipeline.locations[i];
                let machineArray = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormArray"]([]);
                location.machines.forEach((item, j) => {
                    let machine = location.machines[j];
                    machineArray.push(this.buildMachineDetailForm(machine));
                });
                locationArray.push(this.buildDataEntryForm(location, machineArray));
            });
            this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
                dataEntry: locationArray,
                group: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.salesPipeline.group, {
                    updateOn: 'blur',
                }),
                client: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.salesPipeline.clientId, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                comments: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.salesPipeline.comment, {
                    updateOn: 'blur',
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].maxLength(180)],
                }),
                amount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.salesPipeline.amount, {
                    updateOn: 'blur',
                }),
                billingAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.salesPipeline.billingAmount, {
                    updateOn: 'blur',
                }),
                machineCount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.salesPipeline.machineCount, {
                    updateOn: 'blur',
                }),
            });
            this.form.valueChanges.subscribe(val => {
                if (val.client == null)
                    return;
                let clientamount = 0;
                let clientbillamt = 0;
                let clientmachinecount = 0;
                this.form.get('dataEntry')['controls'].forEach((location, i) => {
                    let locamount = 0;
                    let locmachinecount = 0;
                    let locbillamt = 0;
                    this.form.get('dataEntry')['controls'][i].get('machineDetails')['controls'].forEach((machine, j) => {
                        let rate = this.form.get('dataEntry')['controls'][i].get('machineDetails')['controls'][j].get('rate').value;
                        let mccount = this.form.get('dataEntry')['controls'][i].get('machineDetails')['controls'][j].get('machineCount').value;
                        let conflevel = this.form.get('dataEntry')['controls'][i].get('machineDetails')['controls'][j].get('conflevel').value;
                        let amt = rate * Math.round(mccount * conflevel / 100);
                        let closureDate = new Date(this.form.get('dataEntry')['controls'][i].get('closureDate').value);
                        let closureamt = this.financialYearCalculation(closureDate, amt);
                        locamount = locamount + amt;
                        clientamount = clientamount + amt;
                        locbillamt = locbillamt + closureamt;
                        clientbillamt = clientbillamt + closureamt;
                        locmachinecount = locmachinecount + mccount;
                        clientmachinecount = clientmachinecount + mccount;
                        this.form.get('dataEntry')['controls'][i].get('machineDetails')['controls'][j].get('amount').patchValue(amt, { emitEvent: false });
                        this.form.get('dataEntry')['controls'][i].get('machineDetails')['controls'][j].get('billingAmount').patchValue(closureamt, { emitEvent: false });
                    });
                    this.form.get('dataEntry')['controls'][i].get('amount').patchValue(locamount, { emitEvent: false });
                    this.form.get('dataEntry')['controls'][i].get('billingAmount').patchValue(locbillamt, { emitEvent: false });
                    this.form.get('dataEntry')['controls'][i].get('machineCount').patchValue(locmachinecount, { emitEvent: false });
                });
                this.form.get('amount').patchValue(clientamount, { emitEvent: false });
                this.form.get('billingAmount').patchValue(clientbillamt, { emitEvent: false });
                this.form.get('machineCount').patchValue(clientmachinecount, { emitEvent: false });
            });
            this.isLoading = false;
        });
    }
    ionViewWillEnter() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.loadBranches();
            yield this.loadAccOwners();
            this.loadSalesPipeline(this.saleId);
            this.clientService.fetchClients().subscribe(() => { });
            this.salesPipelineService.getClientSalesPipeline(this.saleId);
        });
    }
    loadAccOwners() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.accowners = yield this.divisionService.getAccOwners();
            return true;
        });
    }
    loadBranches() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.branches = yield this.divisionService.getBranches();
            return true;
        });
    }
    onUpdateSalespipeline(redirection = true) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!this.form.valid) {
                return;
            }
            var exiclientId = yield this.salesPipelineService.getClientById(this.form.value.client);
            console.log(exiclientId);
            if (exiclientId.length > 0 && exiclientId[0]['clientId'] != this.clientId) {
                yield this.toastController.create({
                    message: 'Client data is already exist.',
                    duration: 2000,
                    color: 'danger',
                }).then((tost) => {
                    tost.present();
                });
                return;
            }
            let salesPipeline = this.AddSalesPipeline();
            let extSalepipe = yield this.salesPipelineService.deleteSalesPipelineByClietId(this.clientId);
            this.loadingCtrl.create({ keyboardClose: true }).then((loadingEl) => {
                loadingEl.present();
                // Tree Structue Input
                this.AddClientSalesPipeLine(loadingEl, redirection);
                // let arrayLength = salesPipeline.length - 1;
                //   salesPipeline.forEach((item, index) => {
                //     this.salesPipelineService
                //       .addSalesPipeline(item)
                //       .subscribe((response) => {
                //         console.log(index);
                //         if (arrayLength == index) {
                //           this.removeLoading(loadingEl,redirection);
                //         }
                //       });
                //   });
            });
        });
    }
    removeLoading(loadingEl, redirection = true) {
        this.isLoading = false;
        loadingEl.dismiss();
        this.form.reset();
        if (redirection)
            this.router.navigate(['/salespipeline']);
    }
    AddClientSalesPipeLine(loadingEl, redirection = true) {
        let locations = [];
        for (let i = 0; i < this.form.value.dataEntry.length; i++) {
            let location = this.form.value.dataEntry[i];
            let machines = [];
            for (let j = 0; j < location.machineDetails.length; j++) {
                let machine = location.machineDetails[j];
                machines.push(new _salespipeline_model__WEBPACK_IMPORTED_MODULE_11__["Machine"](machine.machineName, machine.machineType, machine.volumeType, machine.machineCount, machine.machineSrNo, machine.rate, machine.amount, machine.conflevel, machine.billingAmount, machine.mchRent, machine.consumableCap, machine.mchInstCharges, machine.mchSecDeposite, machine.isInstChargesConsider, machine.machinehsncode, machine.pulloutDate, machine.pulloutreason));
            }
            locations.push(new _salespipeline_model__WEBPACK_IMPORTED_MODULE_11__["Location"](location.city, location.address, location.installAt, location.installAddress, location.currentStatus, new Date(location.closureDate), location.amount, machines.map((obj) => {
                return Object.assign({}, obj);
            }), location.billingAmount, location.machineCount, location.id, location.branch, location.accowner, location.branchcity, location.isConsumable, location.isRental, location.renLimit));
        }
        let clientSalesPipeline = new _salespipeline_model__WEBPACK_IMPORTED_MODULE_11__["ClientSalesPipeline"]('', this.form.value.group, this.form.value.client, this.clients.filter((item) => item.id == this.form.value.client)[0].name, this.form.value.comments, '', new Date(), this.form.value.amount, locations.map((obj) => {
            return Object.assign({}, obj);
        }), 'edit', this.form.value.billingAmount, this.form.value.machineCount);
        this.salesPipelineService
            .editClientSalesPipeline(this.saleId, clientSalesPipeline, this.lastComment)
            .subscribe((response) => {
            this.removeLoading(loadingEl, redirection);
        });
    }
    AddSalesPipeline() {
        let salesPipeline = [];
        for (let i = 0; i < this.form.value.dataEntry.length; i++) {
            let location = this.form.value.dataEntry[i];
            for (let j = 0; j < location.machineDetails.length; j++) {
                let machine = location.machineDetails[j];
                salesPipeline.push(new _salespipeline_model__WEBPACK_IMPORTED_MODULE_11__["SalesPipeline"]('', this.form.value.group, this.form.value.client, this.clients.filter((item) => item.id == this.form.value.client)[0].name, this.form.value.comments, location.city, location.address, location.installAt, location.installAddress, location.currentStatus, new Date(location.closureDate), machine.machineName, machine.machineType, machine.volumeType, machine.machineCount, machine.machineSrNo, machine.rate, machine.amount, location.amount, this.form.value.amount, '', new Date(), machine.conflevel, machine.machinehsncode));
            }
        }
        return salesPipeline;
    }
    onChangeGroup(event) {
        let grp = event.target.value;
        this.form.controls['client'].reset();
        this.loadedClients = [];
        this.loadedClients = this.clients.filter(item => item.group === grp);
    }
    onMachineChange(event, element) {
        if (!event.target.value)
            return;
        let ref = this.machineDetail.filter((item) => item.name == event.target.value)[0].name;
        element.controls['volumeType'].reset();
        this.machineCategory = [];
        this.machineCategory = this.machineDetail
            .filter((item) => item.ref == ref && item.group == 2)
            .sort((a, b) => a.srno - b.srno)
            .map((item) => item.name);
        if (ref == 'FM' || ref == 'Mtl(kg/mth)') {
            element.controls['volumeType'].patchValue('Not Applicable', {
                emitEvent: false,
            });
        }
    }
    financialYearCalculation(closureDate, amount) {
        let extraday = 7;
        let startDate = new Date(closureDate.getFullYear(), closureDate.getMonth(), closureDate.getDate());
        startDate.setDate(startDate.getDate() + extraday);
        let endDate = new Date(startDate.getMonth() > 2 ? startDate.getFullYear() + 1 : startDate.getFullYear(), 2, 31);
        let diff = new Date(endDate.valueOf() - startDate.valueOf());
        let days = diff.valueOf() / 1000 / 60 / 60 / 24;
        return ((amount * 12) / 264) * days;
    }
    statusChange(event, element, index) {
        if (event.target.value == 'S3 : Demo initiated / done') {
            this.alertCtrl.create({
                header: 'Demo request!',
                message: '<strong>Are you sure you want to save and raise material requirement for Demo ?</strong>',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: () => {
                            let oldvalue = element.get('hiddencurrentStatus').value;
                            element
                                .get('currentStatus')
                                .patchValue(oldvalue, { emitEvent: false });
                        },
                    },
                    {
                        text: 'Okay',
                        handler: () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                            yield this.onUpdateSalespipeline(false);
                            this.router.navigate(['/salespipeline/demorequest/' + this.saleId + "/" + index]);
                            //Redirect to the next page
                        }),
                    },
                ],
            }).then((alertEl) => {
                alertEl.present();
            });
        }
        else {
            let curvalue = event.target.value;
            element.get('hiddencurrentStatus').patchValue(curvalue, { emitEvent: false });
        }
    }
    ngOnDestroy() {
        if (this.salesPipeSub) {
            this.salesPipeSub.unsubscribe();
        }
    }
};
EditSalesPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: _clients_client_service__WEBPACK_IMPORTED_MODULE_9__["ClientService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _salespipeline_service__WEBPACK_IMPORTED_MODULE_12__["SalespipelineService"] },
    { type: _services_division_service__WEBPACK_IMPORTED_MODULE_10__["DivisionService"] }
];
EditSalesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-edit-sales',
        template: _raw_loader_edit_sales_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_edit_sales_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], EditSalesPage);



/***/ }),

/***/ "bfQv":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/salespipeline/edit-sales/edit-sales.page.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref=\"/salespipeline\">\n      </ion-back-button>\n      <ion-title>Edit Salespipeline</ion-title>\n      <ion-button (click)=\"onUpdateSalespipeline()\"  [disabled]=\"!form?.valid\">\n        <ion-icon name=\"checkmark\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <form [formGroup]=\"form\" *ngIf=\"!isLoading\">\n    <ion-grid>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label>Client Group</ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"group\" (ionChange)=\"onChangeGroup($event)\">\n              <ion-select-option *ngFor=\"let grp of clientGroup\" [value]=\"grp\">{{grp}}\n              </ion-select-option>\n            </ion-select>\n          </ion-item>\n          <ion-item>\n            <ion-label>Client <span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"client\">\n              <ion-select-option *ngFor=\"let client of loadedClients\" [value]=\"client.id\">{{client.name}}\n              </ion-select-option>\n            </ion-select>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"!form.get('client').valid && form.get('client').touched\">\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <p>Client must not be empty.</p>\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\" >Comment<span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-textarea row=\"3\" formControlName=\"comments\"></ion-textarea>\n          </ion-item>\n\n          <ion-item color=\"success\">\n            <p>Amount : </p>\n            <ion-input type=\"number\" formControlName=\"amount\"  readonly ></ion-input>\n          </ion-item>\n          <ion-item style=\"display: none;\">\n            <ion-input type=\"number\" formControlName=\"billingAmount\" readonly></ion-input>\n            <ion-input type=\"number\" formControlName=\"machineCount\" readonly></ion-input>\n          </ion-item>\n      </ion-col>\n      </ion-row>\n\n\n      <ion-card class=\"card-tab\" style=\"background:#3F51B5\" *ngFor=\"let item of form.get('dataEntry')['controls']; let i = index;\">\n        <ion-card-content class=\"card-content\">\n        <ion-row  formArrayName=\"dataEntry\">\n          <ion-col size-sm=\"6\" offset-sm=\"3\" style=\"margin-inline:0px\">\n            <div [formGroupName]=\"i\">\n              <div id=\"container\">\n                <div class=\"center\"><ion-label style=\"color: #fff;padding-right: 70px;\">Location Detail</ion-label></div>\n                <div class=\"right\"><button class=\"close-icon-info\" (click)=\"deleteLocatios(i)\"></button></div>\n              </div>\n              <ion-input style=\"display:none;\"  value=\"Readonly\" readonly formControlName=\"id\"></ion-input>\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >City<span style=\"color: #FF6347;\">*</span></ion-label>\n                    <ion-input formControlName=\"city\"></ion-input>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Branch <span style=\"color: #FF6347;\">*</span></ion-label>\n                    <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"branchcity\">\n                      <ion-select-option *ngFor=\"let branch of branches\" [value]=\"branch.name\">{{branch.name}}\n                      </ion-select-option>\n                    </ion-select>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n\n\n\n              <ion-row *ngIf=\"!form.get('dataEntry')['controls'][i].get('city').valid && form.get('dataEntry')['controls'][i].get('city').touched\">\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <p class=\"error-label\">City should not be empty.</p>\n                </ion-col>\n              </ion-row>\n\n\n              <ion-row>\n                <ion-col size-sm=\"3\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label>Consumable Invoice Applicable</ion-label>\n                    <ion-checkbox color=\"primary\" slot=\"start\" formControlName=\"isConsumable\"></ion-checkbox>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size-sm=\"3\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label>Rental Invoice Applicable</ion-label>\n                    <ion-checkbox color=\"primary\" slot=\"start\" formControlName=\"isRental\"></ion-checkbox>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size-sm=\"3\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label  position=\"floating\">Cap for Rental Invoice</ion-label>\n                    <ion-input type=\"number\" formControlName=\"renLimit\"></ion-input>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n\n\n\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Account Managed By <span style=\"color: #FF6347;\">*</span></ion-label>\n                    <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"accowner\">\n                      <ion-select-option *ngFor=\"let accname of accowners\" [value]=\"accname.name\">{{accname.name}}\n                      </ion-select-option>\n                    </ion-select>\n\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n              <ion-row *ngIf=\"!form.get('dataEntry')['controls'][i].get('accowner').valid && form.get('dataEntry')['controls'][i].get('accowner').touched\">\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <p class=\"error-label\">Account Managed By should not be empty.</p>\n                </ion-col>\n              </ion-row>\n\n\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Billing Address<span style=\"color: #FF6347;\">*</span></ion-label>\n                    <ion-textarea rows=\"3\"  formControlName=\"address\"></ion-textarea>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Installed At <span style=\"color: #FF6347;\">*</span></ion-label>\n                    <ion-input type=\"text\" formControlName=\"installAt\"></ion-input>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Installation Address <span style=\"color: #FF6347;\">*</span></ion-label>\n                    <ion-textarea rows=\"3\"  formControlName=\"installAddress\"></ion-textarea>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" class=\"label\"> Deliver From Branch\n                    </ion-label>\n                    <ion-select placeholder=\"Select One\" interface=\"popover\" formControlName=\"branch\">\n                      <ion-select-option *ngFor=\"let branch of branches\" [value]=\"branch.name\">{{branch.name}}\n                      </ion-select-option>\n                    </ion-select>\n                  </ion-item>\n                </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n              <ion-item>\n                <ion-label position=\"floating\">Current Status <span style=\"color: #FF6347;\">*</span></ion-label>\n                <ion-input type=\"text\" formControlName=\"hiddencurrentStatus\" style=\"display: none;\"></ion-input>\n                <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"currentStatus\" (ionChange)=\"statusChange($event,form.get('dataEntry')['controls'][i],i)\">\n                  <ion-select-option *ngFor=\"let client of clientsStatus\" [value]=\"client.status\">{{client.status}}\n                  </ion-select-option>\n                </ion-select>\n              </ion-item>\n            </ion-col>\n          </ion-row>\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-item>\n                    <ion-label position=\"floating\" >Closure Date<span style=\"color: #FF6347;\">*</span></ion-label>\n                    <ion-datetime\n                    formControlName=\"closureDate\"\n                    display-format=\"MMM DD YYYY\"\n                    picker-format=\"YY MMM DD\"\n                    ></ion-datetime>\n                  </ion-item>\n\n                  <ion-item color=\"success\">\n                    <p>Amount : </p>\n                    <ion-input type=\"number\" formControlName=\"amount\"  readonly></ion-input>\n                  </ion-item>\n                  <ion-item style=\"display: none;\">\n                    <ion-input type=\"number\" formControlName=\"billingAmount\" readonly></ion-input>\n                    <ion-input type=\"number\" formControlName=\"machineCount\" readonly></ion-input>\n                  </ion-item>\n              </ion-col>\n              </ion-row>\n              <ion-row *ngIf=\"!form.get('dataEntry')['controls'][i].get('address').valid && form.get('dataEntry')['controls'][i].get('address').touched\">\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <p class=\"error-label\">Address should not be empty.</p>\n                </ion-col>\n              </ion-row>\n              <div style=\"background: #e91e63;margin: 5px;\"  *ngFor=\"let item of form.get('dataEntry')['controls'][i].get('machineDetails')['controls']; let j = index;\">\n                <ion-row  formArrayName=\"machineDetails\">\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <div [formGroupName]=\"j\">\n                      <div id=\"container\">\n                        <div class=\"center\"><ion-label style=\"color: #fff;padding-right: 70px;\"> <ion-icon name=\"chevron-forward\"></ion-icon> Machine Detail</ion-label></div>\n                        <div class=\"right\"><button class=\"close-icon-accent\" (click)=\"deleteMachineDetails(form.get('dataEntry')['controls'][i],j)\"></button></div>\n                      </div>\n                      <ion-row>\n                      <ion-col size-sm=\"6\" offset-sm=\"3\">\n                        <ion-item>\n                          <ion-label position=\"floating\" >Machine/Material <span style=\"color: #FF6347;\">*</span></ion-label>\n                          <!-- <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineName\">\n                            <ion-select-option value='Brewer'>Brewer</ion-select-option>\n                            <ion-select-option value='FM'>FM</ion-select-option>\n                            <ion-select-option value='B2C'>B2C</ion-select-option>\n                            <ion-select-option value='PreMix'>PreMix</ion-select-option>\n                            <ion-select-option value='Mtl(kg/mth)'>Mtl(kg/mth)</ion-select-option>\n                          </ion-select> -->\n\n                          <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineName\" (ionChange)=\"onMachineChange($event,form.get('dataEntry')['controls'][i].get('machineDetails')['controls'][j])\">\n                            <ion-select-option *ngFor=\"let machine of machines\" [value]=\"machine\">{{machine}}\n                            </ion-select-option>\n                            </ion-select>\n\n                        </ion-item>\n                    </ion-col>\n                    </ion-row>\n\n                    <ion-row>\n                      <ion-col size-sm=\"6\" offset-sm=\"3\">\n                        <ion-item>\n                          <ion-label position=\"floating\" >Type <span style=\"color: #FF6347;\">*</span></ion-label>\n\n                    <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineType\">\n                      <ion-select-option *ngFor=\"let machine of machineType\" [value]=\"machine\">{{machine}}\n                      </ion-select-option>\n                      </ion-select>\n                          <!-- <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"machineType\">\n                            <ion-select-option value='Manual'>Manual</ion-select-option>\n                            <ion-select-option value='Automatic'>Automatic</ion-select-option>\n                          </ion-select> -->\n                        </ion-item>\n                    </ion-col>\n                    </ion-row>\n\n                    <ion-row>\n                      <ion-col size-sm=\"6\" offset-sm=\"3\">\n                        <ion-item>\n                          <ion-label position=\"floating\" >Category <span style=\"color: #FF6347;\">*</span></ion-label>\n                          <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"volumeType\">\n                            <ion-select-option *ngFor=\"let machine of machineCategory\" [value]=\"machine\">{{machine}}\n                            </ion-select-option>\n                            </ion-select>\n                          <!-- <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"volumeType\">\n                            <ion-select-option value='Not Applicable'>Not Applicable</ion-select-option>\n                            <ion-select-option value='2-Chamber'>2-Chamber</ion-select-option>\n                            <ion-select-option value='3-Chamber'>3-Chamber</ion-select-option>\n                            <ion-select-option value='4-Chamber'>4-Chamber</ion-select-option>\n                            <ion-select-option value='Tea'>Tea</ion-select-option>\n                            <ion-select-option value='Coffee'>Coffee</ion-select-option>\n                            <ion-select-option value='Beans'>Beans</ion-select-option>\n                            <ion-select-option value='5 ltr'>5 ltr</ion-select-option>\n                            <ion-select-option value='10 ltr'>10 ltr</ion-select-option>\n                            <ion-select-option value='20 ltr'>20 ltr</ion-select-option>\n                          </ion-select> -->\n                        </ion-item>\n                    </ion-col>\n                    </ion-row>\n\n                    <ion-row>\n                      <ion-col size-sm=\"6\" offset-sm=\"3\">\n                        <ion-item>\n                          <ion-label position=\"floating\" >Machine Count <span style=\"color: #FF6347;\">*</span></ion-label>\n                          <ion-input type=\"number\" formControlName=\"machineCount\"></ion-input>\n                        </ion-item>\n                    </ion-col>\n                    </ion-row>\n\n                    <ion-row>\n                      <ion-col size-sm=\"6\" offset-sm=\"3\">\n                        <ion-item>\n                          <ion-label position=\"floating\" >Machine Serial No <span style=\"color: #FF6347;\">*</span></ion-label>\n                          <ion-input type=\"text\" formControlName=\"machineSrNo\"></ion-input>\n                        </ion-item>\n                    </ion-col>\n                    </ion-row>\n                    <ion-row>\n                      <ion-col size-sm=\"6\" offset-sm=\"3\">\n                        <ion-item>\n                          <ion-label position=\"floating\" >Machine HSNCode <span style=\"color: #FF6347;\">*</span></ion-label>\n                          <ion-input type=\"text\" formControlName=\"machinehsncode\"></ion-input>\n                        </ion-item>\n                    </ion-col>\n                    </ion-row>\n                    <ion-row>\n                      <ion-col size-sm=\"6\" offset-sm=\"3\">\n                        <ion-item>\n                          <ion-label position=\"floating\" >Rate <span style=\"color: #FF6347;\">*</span></ion-label>\n                          <ion-input type=\"number\" formControlName=\"rate\"></ion-input>\n                        </ion-item>\n                        <ion-item>\n                          <ion-label position=\"floating\" >Confidance Level % <span style=\"color: #FF6347;\">*</span></ion-label>\n                          <ion-input type=\"number\" formControlName=\"conflevel\"></ion-input>\n                        </ion-item>\n                        <ion-item color=\"success\">\n                          <p>Amount : </p>\n                          <ion-input type=\"number\" formControlName=\"amount\"  readonly></ion-input>\n                        </ion-item>\n                        <ion-item style=\"display: none;\">\n                          <ion-input type=\"number\" formControlName=\"billingAmount\" readonly></ion-input>\n                        </ion-item>\n                    </ion-col>\n                    </ion-row>\n\n                    <ion-row>\n                      <ion-col size-sm=\"6\" offset-sm=\"3\">\n                        <ion-item>\n                          <ion-label position=\"floating\" >Machine Rent <span style=\"color: #FF6347;\">(if Applicable)*</span></ion-label>\n                          <ion-input type=\"text\" formControlName=\"mchRent\"></ion-input>\n                        </ion-item>\n                    </ion-col>\n                    </ion-row>\n                    <ion-row>\n                      <ion-col size-sm=\"6\" offset-sm=\"3\">\n                        <ion-item>\n                          <ion-label position=\"floating\" >Consumable CAP <span style=\"color: #FF6347;\">(if Applicable)*</span></ion-label>\n                          <ion-input type=\"text\" formControlName=\"consumableCap\"></ion-input>\n                        </ion-item>\n                    </ion-col>\n                    </ion-row>\n                    <ion-row>\n                      <ion-col size-sm=\"6\" offset-sm=\"3\">\n                        <ion-item>\n                          <ion-label position=\"floating\" >Installation Charges<span style=\"color: #FF6347;\">(if Applicable)*</span></ion-label>\n                          <ion-input type=\"text\" formControlName=\"mchInstCharges\"></ion-input>\n                        </ion-item>\n                        <ion-item style=\"display: none;\">\n                          <ion-input type=\"text\" formControlName=\"isInstChargesConsider\" readonly></ion-input>\n                        </ion-item>\n                    </ion-col>\n                    </ion-row>\n                    <ion-row>\n                      <ion-col size-sm=\"6\" offset-sm=\"3\">\n                        <ion-item>\n                          <ion-label position=\"floating\" >Security Deposite<span style=\"color: #FF6347;\">(if Applicable)*</span></ion-label>\n                          <ion-input type=\"text\" formControlName=\"mchSecDeposite\"></ion-input>\n                        </ion-item>\n                    </ion-col>\n                    </ion-row>\n                    <ion-row>\n                      <ion-col size-sm=\"6\" offset-sm=\"3\">\n                    <ion-item>\n                      <ion-label position=\"floating\" >Pullout Date<span style=\"color: #FF6347;\">*</span></ion-label>\n                      <ion-datetime\n                      formControlName=\"pulloutDate\"\n                      display-format=\"MMM DD YYYY\"\n                      picker-format=\"YY MMM DD\"\n                      ></ion-datetime>\n                    </ion-item>\n                  </ion-col>\n                </ion-row>\n\n                <ion-row>\n                  <ion-col size-sm=\"6\" offset-sm=\"3\">\n                    <ion-item>\n                      <ion-label position=\"floating\" >Pullout Reason <span style=\"color: #FF6347;\"></span></ion-label>\n                      <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"pulloutreason\">\n                        <ion-select-option value='none'>None</ion-select-option>\n                        <ion-select-option value='Return'>Return </ion-select-option>\n                            <ion-select-option value='Replacement'>Replacement</ion-select-option>\n                            <ion-select-option value='Ignore'>Ignore from pullout Month</ion-select-option>\n                          </ion-select>\n                    </ion-item>\n                </ion-col>\n                </ion-row>\n\n                  </div>\n                  </ion-col>\n              </ion-row>\n              </div>\n              <ion-row>\n                <ion-col size-sm=\"6\" offset-sm=\"3\">\n                  <ion-button (click)=\"addMachineDetails(form.get('dataEntry')['controls'][i])\" color=\"warning\"><ion-icon name=\"add\" slot=\"icon-only\"></ion-icon> Add Machine </ion-button>\n                </ion-col>\n              </ion-row>\n            </div>\n          </ion-col>\n        </ion-row>\n      </ion-card-content>\n      </ion-card>\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-button (click)=\"addLocations()\">  <ion-icon name=\"add\" slot=\"icon-only\"></ion-icon> Add Location</ion-button>\n        </ion-col>\n      </ion-row>\n\n    </ion-grid>\n</form>\n</ion-content>\n\n\n");

/***/ }),

/***/ "iofU":
/*!***************************************************************!*\
  !*** ./src/app/salespipeline/edit-sales/edit-sales.page.scss ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".componentWrapper {\n  border: solid cadetblue;\n  border-radius: 40px;\n  padding: 15px 10px 10px 10px;\n  margin-top: 20px;\n  width: 95%;\n}\n\n.componentWrapper .header {\n  position: absolute;\n  margin-top: -25px;\n  margin-left: 10px;\n  color: white;\n  background: cadetblue;\n  border-radius: 10px;\n  padding: 2px 10px;\n}\n\n.cardclose {\n  position: absolute;\n  margin-top: -5px;\n  margin-left: 250px;\n  background: white;\n  border-radius: 5px;\n  margin-bottom: 30px;\n}\n\n.close-icon-info {\n  display: block;\n  box-sizing: border-box;\n  width: 20px;\n  height: 20px;\n  border-width: 3px;\n  border-style: solid;\n  border-color: #3F51B5;\n  border-radius: 100%;\n  background: -webkit-linear-gradient(-45deg, transparent 0%, transparent 46%, white 46%, white 56%, transparent 56%, transparent 100%), -webkit-linear-gradient(45deg, transparent 0%, transparent 46%, white 46%, white 56%, transparent 56%, transparent 100%);\n  background-color: #3F51B5;\n  box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.5);\n  transition: all 0.3s ease;\n  margin: 8px;\n}\n\n.close-icon-accent {\n  display: block;\n  box-sizing: border-box;\n  width: 20px;\n  height: 20px;\n  border-width: 3px;\n  border-style: solid;\n  border-color: #e91e63;\n  border-radius: 100%;\n  background: -webkit-linear-gradient(-45deg, transparent 0%, transparent 46%, white 46%, white 56%, transparent 56%, transparent 100%), -webkit-linear-gradient(45deg, transparent 0%, transparent 46%, white 46%, white 56%, transparent 56%, transparent 100%);\n  background-color: #e91e63;\n  box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.5);\n  transition: all 0.3s ease;\n}\n\n.card-tab {\n  margin-inline: 0px;\n}\n\n.card-content {\n  padding: 0px;\n}\n\n.ionitem1 {\n  background: #3F51B5;\n}\n\n.error-label {\n  font-size: small;\n  color: #fff;\n}\n\n.container {\n  width: 100%;\n  text-align: center;\n}\n\n.left {\n  float: left;\n  height: 30px;\n  margin: 5px;\n}\n\n.center {\n  display: inline-block;\n  height: 30px;\n  margin: 5px;\n}\n\n.right {\n  float: right;\n  height: 30px;\n  margin: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxlZGl0LXNhbGVzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSw0QkFBQTtFQUNBLGdCQUFBO0VBQ0EsVUFBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUNBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBRUY7O0FBQUE7RUFFRSxjQUFBO0VBQ0Esc0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0EsK1BBQUE7RUFDQSx5QkFBQTtFQUNBLDhDQUFBO0VBQ0EseUJBQUE7RUFDQSxXQUFBO0FBRUY7O0FBQUE7RUFFRSxjQUFBO0VBQ0Esc0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0EsK1BBQUE7RUFDQSx5QkFBQTtFQUNBLDhDQUFBO0VBQ0EseUJBQUE7QUFFRjs7QUFFQztFQUNDLGtCQUFBO0FBQ0Y7O0FBQ0M7RUFDQyxZQUFBO0FBRUY7O0FBQUM7RUFDRCxtQkFBQTtBQUdBOztBQUFBO0VBQ0UsZ0JBQUE7RUFBaUIsV0FBQTtBQUluQjs7QUFEQTtFQUNFLFdBQUE7RUFDQSxrQkFBQTtBQUlGOztBQURBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBSUY7O0FBREE7RUFDRSxxQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBSUY7O0FBREE7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFJRiIsImZpbGUiOiJlZGl0LXNhbGVzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb21wb25lbnRXcmFwcGVyIHtcclxuICBib3JkZXI6IHNvbGlkIGNhZGV0Ymx1ZTtcclxuICBib3JkZXItcmFkaXVzOiA0MHB4O1xyXG4gIHBhZGRpbmc6IDE1cHggMTBweCAxMHB4IDEwcHg7XHJcbiAgbWFyZ2luLXRvcDogMjBweDtcclxuICB3aWR0aDogOTUlO1xyXG59XHJcblxyXG4uY29tcG9uZW50V3JhcHBlciAuaGVhZGVyIHtcclxuICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICBtYXJnaW4tdG9wOi0yNXB4O1xyXG4gIG1hcmdpbi1sZWZ0OjEwcHg7XHJcbiAgY29sb3I6d2hpdGU7XHJcbiAgYmFja2dyb3VuZDpjYWRldGJsdWU7XHJcbiAgYm9yZGVyLXJhZGl1czoxMHB4O1xyXG4gIHBhZGRpbmc6MnB4IDEwcHg7XHJcbn1cclxuLmNhcmRjbG9zZSB7XHJcbiAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgbWFyZ2luLXRvcDotNXB4O1xyXG4gIG1hcmdpbi1sZWZ0OjI1MHB4O1xyXG4gIGJhY2tncm91bmQ6d2hpdGU7XHJcbiAgYm9yZGVyLXJhZGl1czo1cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTozMHB4O1xyXG59XHJcbi5jbG9zZS1pY29uLWluZm9cclxue1xyXG4gIGRpc3BsYXk6YmxvY2s7XHJcbiAgYm94LXNpemluZzpib3JkZXItYm94O1xyXG4gIHdpZHRoOjIwcHg7XHJcbiAgaGVpZ2h0OjIwcHg7XHJcbiAgYm9yZGVyLXdpZHRoOjNweDtcclxuICBib3JkZXItc3R5bGU6IHNvbGlkO1xyXG4gIGJvcmRlci1jb2xvcjojM0Y1MUI1O1xyXG4gIGJvcmRlci1yYWRpdXM6MTAwJTtcclxuICBiYWNrZ3JvdW5kOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudCgtNDVkZWcsIHRyYW5zcGFyZW50IDAlLCB0cmFuc3BhcmVudCA0NiUsIHdoaXRlIDQ2JSwgIHdoaXRlIDU2JSx0cmFuc3BhcmVudCA1NiUsIHRyYW5zcGFyZW50IDEwMCUpLCAtd2Via2l0LWxpbmVhci1ncmFkaWVudCg0NWRlZywgdHJhbnNwYXJlbnQgMCUsIHRyYW5zcGFyZW50IDQ2JSwgd2hpdGUgNDYlLCAgd2hpdGUgNTYlLHRyYW5zcGFyZW50IDU2JSwgdHJhbnNwYXJlbnQgMTAwJSk7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjojM0Y1MUI1O1xyXG4gIGJveC1zaGFkb3c6MHB4IDBweCA1cHggMnB4IHJnYmEoMCwwLDAsMC41KTtcclxuICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlO1xyXG4gIG1hcmdpbjogOHB4O1xyXG59XHJcbi5jbG9zZS1pY29uLWFjY2VudFxyXG57XHJcbiAgZGlzcGxheTpibG9jaztcclxuICBib3gtc2l6aW5nOmJvcmRlci1ib3g7XHJcbiAgd2lkdGg6MjBweDtcclxuICBoZWlnaHQ6MjBweDtcclxuICBib3JkZXItd2lkdGg6M3B4O1xyXG4gIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgYm9yZGVyLWNvbG9yOiNlOTFlNjM7XHJcbiAgYm9yZGVyLXJhZGl1czoxMDAlO1xyXG4gIGJhY2tncm91bmQ6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KC00NWRlZywgdHJhbnNwYXJlbnQgMCUsIHRyYW5zcGFyZW50IDQ2JSwgd2hpdGUgNDYlLCAgd2hpdGUgNTYlLHRyYW5zcGFyZW50IDU2JSwgdHJhbnNwYXJlbnQgMTAwJSksIC13ZWJraXQtbGluZWFyLWdyYWRpZW50KDQ1ZGVnLCB0cmFuc3BhcmVudCAwJSwgdHJhbnNwYXJlbnQgNDYlLCB3aGl0ZSA0NiUsICB3aGl0ZSA1NiUsdHJhbnNwYXJlbnQgNTYlLCB0cmFuc3BhcmVudCAxMDAlKTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiNlOTFlNjM7XHJcbiAgYm94LXNoYWRvdzowcHggMHB4IDVweCAycHggcmdiYSgwLDAsMCwwLjUpO1xyXG4gIHRyYW5zaXRpb246IGFsbCAwLjNzIGVhc2U7XHJcbn1cclxuXHJcblxyXG4gLmNhcmQtdGFie1xyXG4gIG1hcmdpbi1pbmxpbmU6IDBweDtcclxuIH1cclxuIC5jYXJkLWNvbnRlbnR7XHJcbiAgcGFkZGluZzogMHB4O1xyXG4gfVxyXG4gLmlvbml0ZW0xe1xyXG5iYWNrZ3JvdW5kOiAjM0Y1MUI1O1xyXG4gfVxyXG5cclxuLmVycm9yLWxhYmVse1xyXG4gIGZvbnQtc2l6ZTogc21hbGw7Y29sb3I6I2ZmZlxyXG59XHJcblxyXG4uY29udGFpbmVyIHtcclxuICB3aWR0aDoxMDAlO1xyXG4gIHRleHQtYWxpZ246Y2VudGVyO1xyXG59XHJcblxyXG4ubGVmdCB7XHJcbiAgZmxvYXQ6bGVmdDtcclxuICBoZWlnaHQ6IDMwcHg7XHJcbiAgbWFyZ2luOiA1cHg7XHJcbn1cclxuXHJcbi5jZW50ZXIge1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICBoZWlnaHQ6IDMwcHg7XHJcbiAgbWFyZ2luOiA1cHg7XHJcbn1cclxuXHJcbi5yaWdodCB7XHJcbiAgZmxvYXQ6cmlnaHQ7XHJcbiAgaGVpZ2h0OiAzMHB4O1xyXG4gIG1hcmdpbjogNXB4O1xyXG59XHJcbiJdfQ== */");

/***/ })

}]);
//# sourceMappingURL=edit-sales-edit-sales-module.js.map