(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Code\Mobile\xtccafe\src\main.ts */"zUnb");


/***/ }),

/***/ "1+ET":
/*!*****************************************!*\
  !*** ./src/app/services/fcm.service.ts ***!
  \*****************************************/
/*! exports provided: FcmService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FcmService", function() { return FcmService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! firebase/firestore */ "5x/H");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/core */ "gcOT");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./user.service */ "qfBg");







const { PushNotifications, Modals } = _capacitor_core__WEBPACK_IMPORTED_MODULE_4__["Plugins"];
let FcmService = class FcmService {
    constructor(router, firebaseService, userService) {
        this.router = router;
        this.firebaseService = firebaseService;
        this.userService = userService;
    }
    initPush() {
        console.log(_capacitor_core__WEBPACK_IMPORTED_MODULE_4__["Capacitor"].platform);
        if (_capacitor_core__WEBPACK_IMPORTED_MODULE_4__["Capacitor"].platform !== 'web') {
            console.log('registerPush Called');
            this.registerPush();
        }
    }
    registerPush() {
        PushNotifications.requestPermission().then((permission) => {
            if (permission.granted) {
                PushNotifications.register();
            }
            else {
            }
        });
        PushNotifications.addListener('registration', (token) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log('My token:' + JSON.stringify(token));
            this.userService.setdeviceToken(token.value);
        }));
        PushNotifications.addListener('registrationError', (error) => {
            //console.log('Error:' + JSON.stringify(error));
        });
        PushNotifications.addListener('pushNotificationReceived', (notification) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            //console.log('Push Received' + JSON.stringify(notification));
            let alert = Modals.alert({
                title: notification.title,
                message: notification.body
            });
        }));
        PushNotifications.addListener('pushNotificationActionPerformed', (notification) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const data = notification.notification.data;
            console.log('Action performed:' + JSON.stringify(notification.notification));
            console.log(data);
            if (data.detailsId) {
                this.router.navigateByUrl(`notificationdetail/${data.detailsId}`);
            }
        }));
    }
};
FcmService.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"] },
    { type: _user_service__WEBPACK_IMPORTED_MODULE_6__["UserService"] }
];
FcmService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], FcmService);



/***/ }),

/***/ "AytR":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    firebaseAPIKey: 'AIzaSyDgCRLM4MnehywkTps-5WeVQeHQMKIRGrc',
    firebaseConfig: {
        apiKey: "AIzaSyDgCRLM4MnehywkTps-5WeVQeHQMKIRGrc",
        authDomain: "db-xtc-cafe-dev.firebaseapp.com",
        projectId: "db-xtc-cafe-dev",
        storageBucket: "db-xtc-cafe-dev.appspot.com",
        messagingSenderId: "678229863683",
        appId: "1:678229863683:web:cf91d1d003f1b448e1cd36",
        measurementId: "G-58CENDS2S6"
    },
    cloudFunctions: {
        createOrder: 'https://us-central1-db-xtc-cafe-dev.cloudfunctions.net/createOrder',
        capturePayment: 'https://us-central1-db-xtc-cafe-dev.cloudfunctions.net/capturePayments'
    },
    RAZORPAY_KEY_ID: 'rzp_test_a3qHM6OKjhZUGV'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "P+IX":
/*!************************************!*\
  !*** ./src/app/auth/auth.guard.ts ***!
  \************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./auth.service */ "qXBG");






let AuthGuard = class AuthGuard {
    constructor(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    canLoad(route, segments) {
        return this.authService.userIsAutheticated.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(isAuthenticated => {
            console.log(route.path);
            if (!isAuthenticated) {
                return this.authService.autoLogin();
            }
            else {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(isAuthenticated);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(isAuthenticated => {
            if (!isAuthenticated) {
                console.log('!isAuthenticated' + new Date());
                this.router.navigateByUrl("/auth");
            }
        }));
    }
};
AuthGuard.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
AuthGuard = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AuthGuard);



/***/ }),

/***/ "Sy1n":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./app.component.html */ "VzVu");
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component.scss */ "ynWL");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./auth/auth.service */ "qXBG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/fire/auth */ "UbJi");
/* harmony import */ var _services_fcm_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./services/fcm.service */ "1+ET");









let AppComponent = class AppComponent {
    constructor(authService, firebaseAuth, navCtrl, platform, router, fcmService) {
        this.authService = authService;
        this.firebaseAuth = firebaseAuth;
        this.navCtrl = navCtrl;
        this.platform = platform;
        this.router = router;
        this.fcmService = fcmService;
        this._previousAuthState = false;
        this.isadmin = false;
    }
    ngOnInit() {
        this.isadmin = false;
        this.authSub = this.authService.userdetail.subscribe(isAuth => {
            console.log(isAuth.isAutheticated);
            if (!isAuth.isAutheticated && this._previousAuthState !== isAuth.isAutheticated) {
                this.router.navigateByUrl('/auth');
            }
            else {
                this._previousAuthState = isAuth.isAutheticated;
                this.userName = isAuth.name;
                if (isAuth.roles && isAuth.roles.filter(u => u == "admin").length > 0) {
                    this.isadmin = true;
                }
            }
        });
        this.initializeApp();
    }
    initializeApp() {
        this.platform.ready().then(() => {
            this.fcmService.initPush();
        });
    }
    onLogout() {
        this.authService.logout();
        this.navCtrl.navigateBack('/auth');
    }
    ngOnDestroy() {
        if (this.authSub) {
            this.authSub.unsubscribe();
        }
    }
};
AppComponent.ctorParameters = () => [
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"] },
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_7__["AngularFireAuth"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _services_fcm_service__WEBPACK_IMPORTED_MODULE_8__["FcmService"] }
];
AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AppComponent);



/***/ }),

/***/ "VzVu":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n  <!-- <ion-menu side=\"start\">\n    <ion-header>\n      <ion-toolbar >\n        <ion-item>\n          <ion-thumbnail slot=\"start\">\n            <img src=\"../../assets/icon/xtclogo.png\">\n          </ion-thumbnail>\n          <ion-label>Welcome, {{userName|titlecase}}</ion-label>\n        </ion-item>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content>\n      <ion-list>\n        <ion-menu-toggle>\n          <ion-item lines=\"none\" routerLink=\"/home\" button>\n            <ion-icon name=\"home\" slot=\"start\" color=\"primary\"></ion-icon>\n            <ion-label>Home</ion-label>\n          </ion-item>\n        <ion-item lines=\"none\" routerLink=\"/clients\" button>\n          <ion-icon name=\"people\" slot=\"start\"  color=\"primary\"></ion-icon>\n          <ion-label>Clients</ion-label>\n        </ion-item>\n        <ion-item lines=\"none\"  routerLink=\"/salespipeline\"  button>\n          <ion-icon name=\"analytics\" slot=\"start\" color=\"primary\"></ion-icon>\n          <ion-label>Sales Pipeline</ion-label>\n        </ion-item>\n        <ion-item lines=\"none\"  routerLink=\"/settings\"  button>\n          <ion-icon name=\"build\" slot=\"start\" color=\"primary\"></ion-icon>\n          <ion-label>Settings</ion-label>\n        </ion-item>\n        <ion-item lines=\"none\"  routerLink=\"/about\"  button>\n          <ion-icon name=\"glasses\" slot=\"start\" color=\"primary\"></ion-icon>\n          <ion-label>About</ion-label>\n        </ion-item>\n        <ion-item lines=\"none\" (click)=\"onLogout()\"  button>\n          <ion-icon name=\"exit\" slot=\"start\"  color=\"primary\"></ion-icon>\n          <ion-label>Logout</ion-label>\n        </ion-item>\n      </ion-menu-toggle>\n      </ion-list>\n    </ion-content>\n  </ion-menu> -->\n\n\n<ion-menu>\n  <ion-content>\n<div class=\"menu-header-bg\"> </div>\n<div class=\"header-content\">\n  <img src=\"../../assets/icon/xtclogob.png\">\n<ion-label>\n  <h2>Welcome, {{userName|titlecase}}</h2>\n</ion-label>\n</div>\n<ion-list>\n  <ion-menu-toggle>\n    <ion-item lines=\"none\" routerLink=\"/home\" button>\n      <ion-icon name=\"home\" slot=\"start\" color=\"primary\"></ion-icon>\n      <ion-label>Home</ion-label>\n    </ion-item>\n  <ion-item lines=\"none\" routerLink=\"/clients\" button>\n    <ion-icon name=\"people\" slot=\"start\"  color=\"primary\"></ion-icon>\n    <ion-label>Clients</ion-label>\n  </ion-item>\n  <ion-item lines=\"none\"  routerLink=\"/salespipeline\"  button>\n    <ion-icon name=\"analytics\" slot=\"start\" color=\"primary\"></ion-icon>\n    <ion-label>Sales Pipeline</ion-label>\n  </ion-item>\n  <ion-item lines=\"none\"  routerLink=\"/salespipeline/deliverychallanlist\"  button>\n    <ion-icon name=\"document-text-outline\" slot=\"start\" color=\"primary\"></ion-icon>\n    <ion-label>DC's</ion-label>\n  </ion-item>\n  <ion-item lines=\"none\"  routerLink=\"/salespipeline/invoicelist\"  button>\n    <ion-icon name=\"newspaper-outline\" slot=\"start\" color=\"primary\"></ion-icon>\n    <ion-label>Consumable/Installation Invoices</ion-label>\n  </ion-item>\n  <ion-item lines=\"none\"  routerLink=\"/salespipeline/rentalinvoices\"  button>\n    <ion-icon name=\"newspaper-outline\" slot=\"start\" color=\"primary\"></ion-icon>\n    <ion-label>Rental Invoices</ion-label>\n  </ion-item>\n  <ion-item lines=\"none\"  routerLink=\"/salespipeline/demorequests\"  button>\n    <ion-icon name=\"walk-outline\" slot=\"start\" color=\"primary\"></ion-icon>\n    <ion-label>Demo Request</ion-label>\n  </ion-item>\n  <ion-item *ngIf=\"this.isadmin\" lines=\"none\"  button>\n    <ion-icon name=\"build\" slot=\"start\" color=\"primary\"></ion-icon>\n    <ion-label>Devices</ion-label>\n  </ion-item>\n  <ion-item *ngIf=\"this.isadmin\" lines=\"none\"  routerLink=\"/devices/bluetooth\"  button style=\"margin-left: 20px;\">\n    <ion-icon name=\"bluetooth\" color=\"primary\"></ion-icon>\n    <ion-label>Bluetooth</ion-label>\n  </ion-item>\n\n  <ion-item *ngIf=\"this.isadmin\" lines=\"none\"  button>\n    <ion-icon name=\"build\" slot=\"start\" color=\"primary\"></ion-icon>\n    <ion-label>Settings</ion-label>\n  </ion-item>\n  <ion-item *ngIf=\"this.isadmin\" lines=\"none\"  routerLink=\"/settings\"  button style=\"margin-left: 20px;\">\n    <ion-icon name=\"remove-circle-outline\" slot=\"start\" color=\"primary\"></ion-icon>\n    <ion-label>Client Access</ion-label>\n  </ion-item>\n  <ion-item lines=\"none\"  routerLink=\"/about\"  button>\n    <ion-icon name=\"glasses\" slot=\"start\" color=\"primary\"></ion-icon>\n    <ion-label>About</ion-label>\n  </ion-item>\n  <ion-item lines=\"none\" (click)=\"onLogout()\"  button>\n    <ion-icon name=\"exit\" slot=\"start\"  color=\"primary\"></ion-icon>\n    <ion-label>Logout</ion-label>\n  </ion-item>\n</ion-menu-toggle>\n</ion-list>\n  </ion-content>\n</ion-menu>\n\n\n<ion-router-outlet main></ion-router-outlet>\n</ion-app>\n");

/***/ }),

/***/ "ZAI4":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "Sy1n");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app-routing.module */ "vY5A");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/environments/environment */ "AytR");
/* harmony import */ var _angular_fire__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/fire */ "spgP");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/fire/auth */ "UbJi");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");
/* harmony import */ var _angular_fire_storage__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/fire/storage */ "Vaw3");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "te5A");
/* harmony import */ var _ionic_native_File_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic-native/File/ngx */ "B7Vy");
/* harmony import */ var _ionic_native_ble_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic-native/ble/ngx */ "zP/x");
/* harmony import */ var _manekinekko_angular_web_bluetooth__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @manekinekko/angular-web-bluetooth */ "WcP9");

















let AppModule = class AppModule {
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]],
        entryComponents: [],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_6__["AppRoutingModule"],
            _angular_fire__WEBPACK_IMPORTED_MODULE_9__["AngularFireModule"].initializeApp(src_environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].firebaseConfig),
            _angular_fire_auth__WEBPACK_IMPORTED_MODULE_10__["AngularFireAuthModule"],
            _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_11__["AngularFirestoreModule"],
            _angular_fire_storage__WEBPACK_IMPORTED_MODULE_12__["AngularFireStorageModule"],
            _manekinekko_angular_web_bluetooth__WEBPACK_IMPORTED_MODULE_16__["WebBluetoothModule"].forRoot({
                enableTracing: true // or false, this will enable logs in the browser's console
            })
        ],
        providers: [{ provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] }, _ionic_native_File_ngx__WEBPACK_IMPORTED_MODULE_14__["File"], _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_13__["FileOpener"], _ionic_native_ble_ngx__WEBPACK_IMPORTED_MODULE_15__["BLE"]],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]],
    })
], AppModule);



/***/ }),

/***/ "ZSGM":
/*!******************************************************!*\
  !*** ./src/app/salespipeline/salespipeline.model.ts ***!
  \******************************************************/
/*! exports provided: SalesPipeline, ClientSales, ClientComment, ClientCommentModel, User, ClientSalesPipeline, Location, BillingDetail, BillingRate, DCDetailModel, DCDetail, InstallDCDetail, DCMaterial, DCAddHocMaterial, Machine, InvoiceMonth, Invoice, RentalInvoice, ReceiptBook, InvoiceBank, InvoiceModel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalesPipeline", function() { return SalesPipeline; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientSales", function() { return ClientSales; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientComment", function() { return ClientComment; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientCommentModel", function() { return ClientCommentModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientSalesPipeline", function() { return ClientSalesPipeline; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Location", function() { return Location; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BillingDetail", function() { return BillingDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BillingRate", function() { return BillingRate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DCDetailModel", function() { return DCDetailModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DCDetail", function() { return DCDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InstallDCDetail", function() { return InstallDCDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DCMaterial", function() { return DCMaterial; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DCAddHocMaterial", function() { return DCAddHocMaterial; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Machine", function() { return Machine; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InvoiceMonth", function() { return InvoiceMonth; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Invoice", function() { return Invoice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RentalInvoice", function() { return RentalInvoice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReceiptBook", function() { return ReceiptBook; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InvoiceBank", function() { return InvoiceBank; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InvoiceModel", function() { return InvoiceModel; });
class SalesPipeline {
    constructor(id, group, clientId, client, comment, city, address, installAt, installAddress, currentStatus, closureDate, machineName, machineType, machineCategory, machineCount, machineSrNo, rate, mhamount, locamount, clientamount, userId, updatedOn, machineConflevel, machinehsncode) {
        this.id = id;
        this.group = group;
        this.clientId = clientId;
        this.client = client;
        this.comment = comment;
        this.city = city;
        this.address = address;
        this.installAt = installAt;
        this.installAddress = installAddress;
        this.currentStatus = currentStatus;
        this.closureDate = closureDate;
        this.machineName = machineName;
        this.machineType = machineType;
        this.machineCategory = machineCategory;
        this.machineCount = machineCount;
        this.machineSrNo = machineSrNo;
        this.rate = rate;
        this.mhamount = mhamount;
        this.locamount = locamount;
        this.clientamount = clientamount;
        this.userId = userId;
        this.updatedOn = updatedOn;
        this.machineConflevel = machineConflevel;
        this.machinehsncode = machinehsncode;
    }
}
class ClientSales {
    constructor(clientsale, client) {
        this.clientsale = clientsale;
        this.client = client;
    }
}
class ClientComment {
    constructor(saleId, comment, undatedOn, userId) {
        this.saleId = saleId;
        this.comment = comment;
        this.undatedOn = undatedOn;
        this.userId = userId;
    }
}
class ClientCommentModel {
    constructor(saleId, comment, undatedOn, userId, user) {
        this.saleId = saleId;
        this.comment = comment;
        this.undatedOn = undatedOn;
        this.userId = userId;
        this.user = user;
    }
}
class User {
    constructor(name, userId, role, isActive, deviceToken) {
        this.name = name;
        this.userId = userId;
        this.role = role;
        this.isActive = isActive;
        this.deviceToken = deviceToken;
    }
}
class ClientSalesPipeline {
    constructor(id, group, clientId, client, comment, userId, updatedOn, amount, locations, action, billingAmount, machineCount) {
        this.id = id;
        this.group = group;
        this.clientId = clientId;
        this.client = client;
        this.comment = comment;
        this.userId = userId;
        this.updatedOn = updatedOn;
        this.amount = amount;
        this.locations = locations;
        this.action = action;
        this.billingAmount = billingAmount;
        this.machineCount = machineCount;
    }
}
class Location {
    constructor(city, address, installAt, installAddress, currentStatus, closureDate, amount, machines, billingAmount, machineCount, id, branch, accowner, branchcity, isConsumable, isRental, renLimit) {
        this.city = city;
        this.address = address;
        this.installAt = installAt;
        this.installAddress = installAddress;
        this.currentStatus = currentStatus;
        this.closureDate = closureDate;
        this.amount = amount;
        this.machines = machines;
        this.billingAmount = billingAmount;
        this.machineCount = machineCount;
        this.id = id;
        this.branch = branch;
        this.accowner = accowner;
        this.branchcity = branchcity;
        this.isConsumable = isConsumable;
        this.isRental = isRental;
        this.renLimit = renLimit;
    }
}
class BillingDetail {
    constructor(id, clientId, salesId, locationId, billName, billAddress, location, installAt, installAddress, gstno, taxType, materialDetails, userId, createdOn, pincode, bank, branch) {
        this.id = id;
        this.clientId = clientId;
        this.salesId = salesId;
        this.locationId = locationId;
        this.billName = billName;
        this.billAddress = billAddress;
        this.location = location;
        this.installAt = installAt;
        this.installAddress = installAddress;
        this.gstno = gstno;
        this.taxType = taxType;
        this.materialDetails = materialDetails;
        this.userId = userId;
        this.createdOn = createdOn;
        this.pincode = pincode;
        this.bank = bank;
        this.branch = branch;
    }
}
class BillingRate {
    constructor(category, item, hsnNo, gst, uom, price) {
        this.category = category;
        this.item = item;
        this.hsnNo = hsnNo;
        this.gst = gst;
        this.uom = uom;
        this.price = price;
    }
}
class DCDetailModel {
    constructor(id, srNo, clientId, salesId, locationId, billName, billAddress, location, address, pincode, branch, gstno, date, materialDetails, materialAddhoc, userId, createdOn, type, isSelected = false, isUsed = false, site) {
        this.id = id;
        this.srNo = srNo;
        this.clientId = clientId;
        this.salesId = salesId;
        this.locationId = locationId;
        this.billName = billName;
        this.billAddress = billAddress;
        this.location = location;
        this.address = address;
        this.pincode = pincode;
        this.branch = branch;
        this.gstno = gstno;
        this.date = date;
        this.materialDetails = materialDetails;
        this.materialAddhoc = materialAddhoc;
        this.userId = userId;
        this.createdOn = createdOn;
        this.type = type;
        this.isSelected = isSelected;
        this.isUsed = isUsed;
        this.site = site;
    }
}
class DCDetail {
    constructor(id, srNo, clientId, salesId, locationId, billName, billAddress, location, installAt, address, pincode, branch, gstno, date, materialDetails, materialAddhoc, userId, createdOn, isUsed, isDelete, site) {
        this.id = id;
        this.srNo = srNo;
        this.clientId = clientId;
        this.salesId = salesId;
        this.locationId = locationId;
        this.billName = billName;
        this.billAddress = billAddress;
        this.location = location;
        this.installAt = installAt;
        this.address = address;
        this.pincode = pincode;
        this.branch = branch;
        this.gstno = gstno;
        this.date = date;
        this.materialDetails = materialDetails;
        this.materialAddhoc = materialAddhoc;
        this.userId = userId;
        this.createdOn = createdOn;
        this.isUsed = isUsed;
        this.isDelete = isDelete;
        this.site = site;
    }
}
class InstallDCDetail {
    constructor(id, type, srNo, clientId, salesId, locationId, billName, billAddress, location, installAt, address, pincode, branch, gstno, date, machineDetails, userId, createdOn, isUsed, isDelete, site) {
        this.id = id;
        this.type = type;
        this.srNo = srNo;
        this.clientId = clientId;
        this.salesId = salesId;
        this.locationId = locationId;
        this.billName = billName;
        this.billAddress = billAddress;
        this.location = location;
        this.installAt = installAt;
        this.address = address;
        this.pincode = pincode;
        this.branch = branch;
        this.gstno = gstno;
        this.date = date;
        this.machineDetails = machineDetails;
        this.userId = userId;
        this.createdOn = createdOn;
        this.isUsed = isUsed;
        this.isDelete = isDelete;
        this.site = site;
    }
}
class DCMaterial {
    constructor(category, item, hsnNo, gst, uom, qty, rate, amount, tax, totamount) {
        this.category = category;
        this.item = item;
        this.hsnNo = hsnNo;
        this.gst = gst;
        this.uom = uom;
        this.qty = qty;
        this.rate = rate;
        this.amount = amount;
        this.tax = tax;
        this.totamount = totamount;
    }
}
class DCAddHocMaterial {
    constructor(item, price) {
        this.item = item;
        this.price = price;
    }
}
class Machine {
    constructor(machineName, machineType, machineCategory, machineCount, machineSrNo, rate, amount, conflevel, billingAmount, mchRent, consumableCap, mchInstCharges, mchSecDeposite, isInstChargesConsider, machinehsncode, pulloutDate, pulloutreason) {
        this.machineName = machineName;
        this.machineType = machineType;
        this.machineCategory = machineCategory;
        this.machineCount = machineCount;
        this.machineSrNo = machineSrNo;
        this.rate = rate;
        this.amount = amount;
        this.conflevel = conflevel;
        this.billingAmount = billingAmount;
        this.mchRent = mchRent;
        this.consumableCap = consumableCap;
        this.mchInstCharges = mchInstCharges;
        this.mchSecDeposite = mchSecDeposite;
        this.isInstChargesConsider = isInstChargesConsider;
        this.machinehsncode = machinehsncode;
        this.pulloutDate = pulloutDate;
        this.pulloutreason = pulloutreason;
    }
}
class InvoiceMonth {
    constructor(id, month, displaymonth) {
        this.id = id;
        this.month = month;
        this.displaymonth = displaymonth;
    }
}
class Invoice {
    constructor(id, srNo, bank, branch, month, status, displaymonth, clientId, clientLocationId, clientName, clientLocation, taxType, amount, tax, totamount, dcIds, dc, machines, mchRent, mchdeposite, mchinstCharges, consumableCap, userId, ponumber, createdOn, billName, billAddress, installAt, installAddress, isDeleted, recAmount, modifiedOn, tranCharges, billbranch) {
        this.id = id;
        this.srNo = srNo;
        this.bank = bank;
        this.branch = branch;
        this.month = month;
        this.status = status;
        this.displaymonth = displaymonth;
        this.clientId = clientId;
        this.clientLocationId = clientLocationId;
        this.clientName = clientName;
        this.clientLocation = clientLocation;
        this.taxType = taxType;
        this.amount = amount;
        this.tax = tax;
        this.totamount = totamount;
        this.dcIds = dcIds;
        this.dc = dc;
        this.machines = machines;
        this.mchRent = mchRent;
        this.mchdeposite = mchdeposite;
        this.mchinstCharges = mchinstCharges;
        this.consumableCap = consumableCap;
        this.userId = userId;
        this.ponumber = ponumber;
        this.createdOn = createdOn;
        this.billName = billName;
        this.billAddress = billAddress;
        this.installAt = installAt;
        this.installAddress = installAddress;
        this.isDeleted = isDeleted;
        this.recAmount = recAmount;
        this.modifiedOn = modifiedOn;
        this.tranCharges = tranCharges;
        this.billbranch = billbranch;
    }
}
class RentalInvoice {
    constructor(id, srNo, bank, branch, month, status, displaymonth, clientId, clientLocationId, clientName, clientLocation, taxType, machines, mchRent, mchdeposite, mchinstCharges, consumableCap, userId, createdOn, billName, billAddress, installAt, installAddress, isDeleted, poNumber, billbranch) {
        this.id = id;
        this.srNo = srNo;
        this.bank = bank;
        this.branch = branch;
        this.month = month;
        this.status = status;
        this.displaymonth = displaymonth;
        this.clientId = clientId;
        this.clientLocationId = clientLocationId;
        this.clientName = clientName;
        this.clientLocation = clientLocation;
        this.taxType = taxType;
        this.machines = machines;
        this.mchRent = mchRent;
        this.mchdeposite = mchdeposite;
        this.mchinstCharges = mchinstCharges;
        this.consumableCap = consumableCap;
        this.userId = userId;
        this.createdOn = createdOn;
        this.billName = billName;
        this.billAddress = billAddress;
        this.installAt = installAt;
        this.installAddress = installAddress;
        this.isDeleted = isDeleted;
        this.poNumber = poNumber;
        this.billbranch = billbranch;
    }
}
class ReceiptBook {
    constructor(id, category, type, branch, year, srnumber, userId, createdOn) {
        this.id = id;
        this.category = category;
        this.type = type;
        this.branch = branch;
        this.year = year;
        this.srnumber = srnumber;
        this.userId = userId;
        this.createdOn = createdOn;
    }
}
class InvoiceBank {
    constructor(id, name, branch, address, ifsc, accno) {
        this.id = id;
        this.name = name;
        this.branch = branch;
        this.address = address;
        this.ifsc = ifsc;
        this.accno = accno;
    }
}
class InvoiceModel {
    constructor(ponumber, rent, billName, billAddress, installAt, installAddress, createdOn, status, recAmount, tranCharges) {
        this.ponumber = ponumber;
        this.rent = rent;
        this.billName = billName;
        this.billAddress = billAddress;
        this.installAt = installAt;
        this.installAddress = installAddress;
        this.createdOn = createdOn;
        this.status = status;
        this.recAmount = recAmount;
        this.tranCharges = tranCharges;
    }
}


/***/ }),

/***/ "ckZ1":
/*!************************************!*\
  !*** ./src/app/auth/user.model.ts ***!
  \************************************/
/*! exports provided: User, UserRole */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserRole", function() { return UserRole; });
class User {
    constructor(id, email, _token, tokenExpirationDate, roles, name, deviceToken) {
        this.id = id;
        this.email = email;
        this._token = _token;
        this.tokenExpirationDate = tokenExpirationDate;
        this.roles = roles;
        this.name = name;
        this.deviceToken = deviceToken;
    }
    get token() {
        if (!this.tokenExpirationDate || this.tokenExpirationDate <= new Date()) {
            return null;
        }
        return this._token;
    }
    get tokenDuration() {
        if (!this.token) {
            return 0;
        }
        return this.tokenExpirationDate.getTime() - new Date().getTime();
    }
}
class UserRole {
    constructor(userId, name, email, roles) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.roles = roles;
    }
}


/***/ }),

/***/ "kLfG":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet.entry.js": [
		"dUtr",
		"common",
		0
	],
	"./ion-alert.entry.js": [
		"Q8AI",
		"common",
		1
	],
	"./ion-app_8.entry.js": [
		"hgI1",
		"common",
		2
	],
	"./ion-avatar_3.entry.js": [
		"CfoV",
		"common",
		3
	],
	"./ion-back-button.entry.js": [
		"Nt02",
		"common",
		4
	],
	"./ion-backdrop.entry.js": [
		"Q2Bp",
		5
	],
	"./ion-button_2.entry.js": [
		"0Pbj",
		"common",
		6
	],
	"./ion-card_5.entry.js": [
		"ydQj",
		"common",
		7
	],
	"./ion-checkbox.entry.js": [
		"4fMi",
		"common",
		8
	],
	"./ion-chip.entry.js": [
		"czK9",
		"common",
		9
	],
	"./ion-col_3.entry.js": [
		"/CAe",
		10
	],
	"./ion-datetime_3.entry.js": [
		"WgF3",
		"common",
		11
	],
	"./ion-fab_3.entry.js": [
		"uQcF",
		"common",
		12
	],
	"./ion-img.entry.js": [
		"wHD8",
		13
	],
	"./ion-infinite-scroll_2.entry.js": [
		"2lz6",
		14
	],
	"./ion-input.entry.js": [
		"ercB",
		"common",
		15
	],
	"./ion-item-option_3.entry.js": [
		"MGMP",
		"common",
		16
	],
	"./ion-item_8.entry.js": [
		"9bur",
		"common",
		17
	],
	"./ion-loading.entry.js": [
		"cABk",
		"common",
		18
	],
	"./ion-menu_3.entry.js": [
		"kyFE",
		"common",
		19
	],
	"./ion-modal.entry.js": [
		"TvZU",
		"common",
		20
	],
	"./ion-nav_2.entry.js": [
		"vnES",
		"common",
		21
	],
	"./ion-popover.entry.js": [
		"qCuA",
		"common",
		22
	],
	"./ion-progress-bar.entry.js": [
		"0tOe",
		"common",
		23
	],
	"./ion-radio_2.entry.js": [
		"h11V",
		"common",
		24
	],
	"./ion-range.entry.js": [
		"XGij",
		"common",
		25
	],
	"./ion-refresher_2.entry.js": [
		"nYbb",
		"common",
		26
	],
	"./ion-reorder_2.entry.js": [
		"smMY",
		"common",
		27
	],
	"./ion-ripple-effect.entry.js": [
		"STjf",
		28
	],
	"./ion-route_4.entry.js": [
		"k5eQ",
		"common",
		29
	],
	"./ion-searchbar.entry.js": [
		"OR5t",
		"common",
		30
	],
	"./ion-segment_2.entry.js": [
		"fSgp",
		"common",
		31
	],
	"./ion-select_3.entry.js": [
		"lfGF",
		"common",
		32
	],
	"./ion-slide_2.entry.js": [
		"5xYT",
		33
	],
	"./ion-spinner.entry.js": [
		"nI0H",
		"common",
		34
	],
	"./ion-split-pane.entry.js": [
		"NAQR",
		35
	],
	"./ion-tab-bar_2.entry.js": [
		"knkW",
		"common",
		36
	],
	"./ion-tab_2.entry.js": [
		"TpdJ",
		"common",
		37
	],
	"./ion-text.entry.js": [
		"ISmu",
		"common",
		38
	],
	"./ion-textarea.entry.js": [
		"U7LX",
		"common",
		39
	],
	"./ion-toast.entry.js": [
		"L3sA",
		"common",
		40
	],
	"./ion-toggle.entry.js": [
		"IUOf",
		"common",
		41
	],
	"./ion-virtual-scroll.entry.js": [
		"8Mb5",
		42
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "kLfG";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "qXBG":
/*!**************************************!*\
  !*** ./src/app/auth/auth.service.ts ***!
  \**************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ "AytR");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _user_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./user.model */ "ckZ1");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @capacitor/core */ "gcOT");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/fire/auth */ "UbJi");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");










let AuthService = class AuthService {
    constructor(http, firebaseAuth, firebaseService) {
        this.http = http;
        this.firebaseAuth = firebaseAuth;
        this.firebaseService = firebaseService;
        this._user = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](null);
        this._appuser = new _user_model__WEBPACK_IMPORTED_MODULE_6__["User"](null, null, null, null, null, null);
    }
    autoLogin() {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["from"])(_capacitor_core__WEBPACK_IMPORTED_MODULE_7__["Plugins"].Storage.get({ key: 'authData' })).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((storedData) => {
            if (!storedData || !storedData.value) {
                return null;
            }
            const parsedData = JSON.parse(storedData.value);
            const expirationTime = new Date(parsedData.tokenExpirationDate);
            // if (expirationTime <= new Date()) {
            //   return null;
            // }
            const user = new _user_model__WEBPACK_IMPORTED_MODULE_6__["User"](parsedData.userId, parsedData.email, parsedData.token, expirationTime, parsedData.roles, parsedData.name);
            this._appuser.id = user.id;
            this._appuser.email = user.email;
            this._appuser.name = user.name;
            this._appuser.roles = user.roles;
            return user;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])((user) => {
            if (user) {
                this._user.next(user);
                this.autoLogout(user.tokenDuration);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((user) => {
            return !!user;
        }));
    }
    get userIsAutheticated() {
        return this._user.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((user) => {
            if (user) {
                return !!user.token;
            }
            else {
                return false;
            }
        }));
    }
    get userRoles() {
        return this._user.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((user) => {
            if (user) {
                return user.roles;
            }
            else {
                return null;
            }
        }));
    }
    get isAdmin() {
        return this._user.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((user) => {
            if (user) {
                if (user.roles && user.roles.filter((u) => u == 'admin').length > 0) {
                    return true;
                }
            }
            else {
                return false;
            }
        }));
    }
    get userdetail() {
        return this._user.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((user) => {
            if (user) {
                return {
                    isAutheticated: !!user.token,
                    name: user.name,
                    roles: user.roles,
                };
            }
            else {
                return { isAutheticated: false, name: '' };
            }
        }));
    }
    get userId() {
        return this._user.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((user) => {
            if (user) {
                return user.id;
            }
            else {
                return null;
            }
        }));
    }
    get userName() {
        return this._user.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((user) => {
            if (user) {
                return user.name;
            }
            else {
                return null;
            }
        }));
    }
    get token() {
        return this._user.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((user) => {
            if (user) {
                return user.token;
            }
            else {
                return null;
            }
        }));
    }
    get appuserId() {
        return this._appuser.id;
    }
    // login_old(email: string, password: string) {
    //   this.firebaseAuth.signInWithEmailAndPassword(email,password).then(value=>{}).catch(err=>{});
    //   return this.http
    //     .post<AuthResponseData>(
    //       `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${environment.firebaseAPIKey}`,
    //       { email: email, password: password, returnSecureToken: true }
    //     )
    //     .pipe(tap(this.setUserData.bind(this)));
    //   //this._userIsAutheticated = true;
    // }
    login_new(email, password) {
        console.log("********Auth start**********");
        var auth = this.firebaseAuth
            .signInWithEmailAndPassword(email, password).then(res => {
            console.log(res.user);
            return res.user;
        }).catch((err) => {
            throw err;
        });
        console.log("********Auth End**********");
    }
    login(email, password) {
        var userAuthData;
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["from"])(this.firebaseAuth
            .signInWithEmailAndPassword(email, password)
            .then((value) => {
            return value.user;
        })
            .catch((err) => {
            throw err;
        })).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])((user) => {
            userAuthData = user;
            return user;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])((user) => {
            return this.firebaseService
                .collection('user-roles', (ref) => ref.where('userId', '==', user.uid))
                .valueChanges();
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((userrole) => {
            userAuthData.roles = userrole[0]['roles'];
            userAuthData.name = userrole[0]['name'];
            this.setUserData(userAuthData);
            return userAuthData;
            //return this.setUserData.bind(userAuthData);
        }));
    }
    logout() {
        if (this._activeLogoutTime) {
            clearTimeout(this._activeLogoutTime);
        }
        this._appuser = new _user_model__WEBPACK_IMPORTED_MODULE_6__["User"](null, null, null, null, null, null);
        this._user.next(null);
        _capacitor_core__WEBPACK_IMPORTED_MODULE_7__["Plugins"].Storage.remove({ key: 'authData' });
        this.firebaseAuth.signOut();
    }
    autoLogout(duration) {
        return true;
        if (this._activeLogoutTime) {
            clearTimeout(this._activeLogoutTime);
        }
        this._activeLogoutTime = setTimeout(() => {
            this.logout();
        }, duration);
    }
    signup(email, password) {
        return this.http
            .post(`https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].firebaseAPIKey}`, { email: email, password: password, returnSecureToken: true })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])(this.setUserData.bind(this)));
    }
    setUserData(userData) {
        this._appuser.id = userData.uid;
        this._appuser.email = userData.email;
        this._appuser.name = userData.name;
        this._appuser.roles = userData.roles;
        /*const expirationTime = new Date(
          new Date().getTime() + +userData.expiresIn * 1000
        );
        const user = new User(
          userData.localId,
          userData.email,
          userData.idToken,
          expirationTime
        );
        */
        const expirationTime = new Date(new Date().getTime() + 9600 * 1000);
        const user = new _user_model__WEBPACK_IMPORTED_MODULE_6__["User"](userData.uid, userData.email, userData.refreshToken, expirationTime, userData.roles, userData.name);
        this._user.next(user);
        this.autoLogout(user.tokenDuration);
        this.storeAuthData(userData.uid, userData.refreshToken, expirationTime.toISOString(), userData.email, userData.roles, userData.name);
    }
    storeAuthData(userId, token, tokenExpirationDate, email, roles, name) {
        const data = JSON.stringify({
            userId: userId,
            token: token,
            tokenExpirationDate: tokenExpirationDate,
            email: email,
            roles: roles,
            name: name,
        });
        _capacitor_core__WEBPACK_IMPORTED_MODULE_7__["Plugins"].Storage.set({ key: 'authData', value: data });
        console.log('login called at' + new Date());
    }
    ngOnDestroy() {
        if (this._activeLogoutTime) {
            clearTimeout(this._activeLogoutTime);
        }
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_8__["AngularFireAuth"] },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_9__["AngularFirestore"] }
];
AuthService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], AuthService);



/***/ }),

/***/ "qfBg":
/*!******************************************!*\
  !*** ./src/app/services/user.service.ts ***!
  \******************************************/
/*! exports provided: UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return UserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! firebase/firestore */ "5x/H");
/* harmony import */ var _salespipeline_salespipeline_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../salespipeline/salespipeline.model */ "ZSGM");






let UserService = class UserService {
    constructor(firebaseService) {
        this.firebaseService = firebaseService;
        this._appuser = new _salespipeline_salespipeline_model__WEBPACK_IMPORTED_MODULE_5__["User"](null, null, null, null, null);
    }
    getusers() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const users = yield this.firebaseService.collection('user-roles')
                .valueChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["first"])()).toPromise();
            return users;
        });
    }
    getclientusers() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const users = yield this.firebaseService.collection('client-user-access')
                .valueChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["first"])()).toPromise();
            return users;
        });
    }
    addclientUser(clientUser) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.firebaseService.collection('client-user-access').add(Object.assign({}, clientUser)).then((doc) => doc);
        });
    }
    deleteclientUser(clientUser) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            var users = yield this.firebaseService
                .collection('client-user-access', ref => ref
                .where("clientId", "==", clientUser.clientId)
                .where("userId", "==", clientUser.userId))
                .get();
            users.forEach(docs => {
                docs.forEach(doc => {
                    this.firebaseService
                        .collection('client-user-access').doc(doc.id).delete();
                });
            });
        });
    }
    get deviceToken() {
        return this._appuser.deviceToken;
    }
    setdeviceToken(token) {
        this._appuser.deviceToken = token;
    }
};
UserService.ctorParameters = () => [
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_3__["AngularFirestore"] }
];
UserService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], UserService);



/***/ }),

/***/ "vY5A":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _auth_auth_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth/auth.guard */ "P+IX");




const routes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    {
        path: 'auth',
        loadChildren: () => __webpack_require__.e(/*! import() | auth-auth-module */ "auth-auth-module").then(__webpack_require__.bind(null, /*! ./auth/auth.module */ "Yj9t")).then(m => m.AuthPageModule)
    },
    {
        path: 'home',
        loadChildren: () => __webpack_require__.e(/*! import() | home-home-module */ "home-home-module").then(__webpack_require__.bind(null, /*! ./home/home.module */ "ct+p")).then(m => m.HomePageModule),
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
    },
    {
        path: 'clients',
        loadChildren: () => Promise.all(/*! import() | clients-clients-module */[__webpack_require__.e("default~add-sales-add-sales-module~clients-clients-module~edit-sales-edit-sales-module~settings-clie~97d3b640"), __webpack_require__.e("clients-clients-module")]).then(__webpack_require__.bind(null, /*! ./clients/clients.module */ "9iw0")).then(m => m.ClientsPageModule),
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
    },
    {
        path: 'salespipeline',
        loadChildren: () => Promise.all(/*! import() | salespipeline-salespipeline-module */[__webpack_require__.e("common"), __webpack_require__.e("salespipeline-salespipeline-module")]).then(__webpack_require__.bind(null, /*! ./salespipeline/salespipeline.module */ "TEjI")).then(m => m.SalespipelinePageModule),
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
    },
    // {
    //   path: 'settings',
    //   loadChildren: () => import('./settings/settings.module').then( m => m.SettingsPageModule),
    //   canLoad:[AuthGuard]
    // },
    {
        path: 'settings',
        loadChildren: () => Promise.all(/*! import() | settings-client-access-client-access-module */[__webpack_require__.e("default~add-sales-add-sales-module~clients-clients-module~edit-sales-edit-sales-module~settings-clie~97d3b640"), __webpack_require__.e("settings-client-access-client-access-module")]).then(__webpack_require__.bind(null, /*! ./settings/client-access/client-access.module */ "i05m")).then(m => m.ClientAccessPageModule),
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
    },
    {
        path: 'about',
        loadChildren: () => __webpack_require__.e(/*! import() | about-about-module */ "about-about-module").then(__webpack_require__.bind(null, /*! ./about/about.module */ "FQ1g")).then(m => m.AboutPageModule),
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
    },
    {
        path: 'notificationdetail/:id',
        loadChildren: () => __webpack_require__.e(/*! import() | notification-detail-notification-detail-module */ "notification-detail-notification-detail-module").then(__webpack_require__.bind(null, /*! ./notification-detail/notification-detail.module */ "Kvdg")).then(m => m.NotificationDetailPageModule)
    },
    {
        path: 'devices/bluetooth',
        loadChildren: () => __webpack_require__.e(/*! import() | devices-bluetooth-bluetooth-module */ "devices-bluetooth-bluetooth-module").then(__webpack_require__.bind(null, /*! ./devices/bluetooth/bluetooth.module */ "tShh")).then(m => m.BluetoothPageModule)
    },
    {
        path: 'menu-card',
        loadChildren: () => __webpack_require__.e(/*! import() | menu-card-menu-card-module */ "menu-card-menu-card-module").then(__webpack_require__.bind(null, /*! ./menu-card/menu-card.module */ "IecN")).then(m => m.MenuCardPageModule)
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "ynWL":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".menu-header-bg {\n  height: 140px;\n  width: 350px;\n  background: #FC5C7D;\n  /* fallback for old browsers */\n  /* Chrome 10-25, Safari 5.1-6 */\n  background: linear-gradient(to right, #6A82FB, #FC5C7D);\n  /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */\n  box-shadow: 0px 1px 10px rgba(98, 140, 255, 0.5);\n  transform: rotate(-15deg);\n  border-radius: 10px 10px 10px 50px;\n  margin-left: -18px;\n  margin-top: -50px;\n  margin-bottom: 60px;\n}\n\n.header-content {\n  position: absolute;\n  top: 10px;\n  left: 15px;\n  display: flex;\n  align-items: center;\n  color: #fff;\n}\n\n.header-content img {\n  width: 70px;\n  height: 70px;\n  border-radius: 50%;\n  border: 7px solid #5e7ccc;\n}\n\nion-label {\n  white-space: normal !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUFzQiw4QkFBQTtFQUM0QywrQkFBQTtFQUNsRSx1REFBQTtFQUF5RCxxRUFBQTtFQUN6RCxnREFBQTtFQUNBLHlCQUFBO0VBQ0Esa0NBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFJRjs7QUFGQTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FBS0Y7O0FBSEU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7QUFLSjs7QUFGQTtFQUNFLDhCQUFBO0FBS0YiLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1lbnUtaGVhZGVyLWJne1xyXG4gIGhlaWdodDogMTQwcHg7XHJcbiAgd2lkdGg6IDM1MHB4O1xyXG4gIGJhY2tncm91bmQ6ICNGQzVDN0Q7ICAvKiBmYWxsYmFjayBmb3Igb2xkIGJyb3dzZXJzICovXHJcbiAgYmFja2dyb3VuZDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM2QTgyRkIsICNGQzVDN0QpOyAgLyogQ2hyb21lIDEwLTI1LCBTYWZhcmkgNS4xLTYgKi9cclxuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM2QTgyRkIsICNGQzVDN0QpOyAvKiBXM0MsIElFIDEwKy8gRWRnZSwgRmlyZWZveCAxNissIENocm9tZSAyNissIE9wZXJhIDEyKywgU2FmYXJpIDcrICovXHJcbiAgYm94LXNoYWRvdzogMHB4IDFweCAxMHB4IHJnYmEoOTgsMTQwLDI1NSwwLjUpO1xyXG4gIHRyYW5zZm9ybTogcm90YXRlKC0xNWRlZyk7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweCAxMHB4IDEwcHggNTBweDtcclxuICBtYXJnaW4tbGVmdDogLTE4cHg7XHJcbiAgbWFyZ2luLXRvcDogLTUwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogNjBweDtcclxufVxyXG4uaGVhZGVyLWNvbnRlbnR7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDoxMHB4O1xyXG4gIGxlZnQ6MTVweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgY29sb3I6ICNmZmY7XHJcblxyXG4gIGltZyB7XHJcbiAgICB3aWR0aDogNzBweDtcclxuICAgIGhlaWdodDogNzBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIGJvcmRlcjo3cHggc29saWQgIzVlN2NjY1xyXG4gIH1cclxufVxyXG5pb24tbGFiZWwge1xyXG4gIHdoaXRlLXNwYWNlOiBub3JtYWwgIWltcG9ydGFudDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "zUnb":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "a3Wg");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "ZAI4");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "AytR");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));


/***/ }),

/***/ "zn8P":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "zn8P";

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map