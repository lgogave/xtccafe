(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["menu-card-menu-card-module"],{

/***/ "5wiT":
/*!*****************************************************************!*\
  !*** ./src/app/services/web-bluetooth/web-bluetooth.service.ts ***!
  \*****************************************************************/
/*! exports provided: WebBluetoothService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WebBluetoothService", function() { return WebBluetoothService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _manekinekko_angular_web_bluetooth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @manekinekko/angular-web-bluetooth */ "WcP9");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "kU1M");




let WebBluetoothService = class WebBluetoothService {
    constructor(ble) {
        this.ble = ble;
        this.GATT_CHARACTERISTIC_BATTERY_LEVEL = '0000ffe1-0000-1000-8000-00805f9b34fb';
        this.GATT_PRIMARY_SERVICE = '0000ffe0-0000-1000-8000-00805f9b34fb';
        this._characteristic = null;
    }
    getDevice() {
        // call this method to get the connected device
        return this.ble.getDevice$();
    }
    stream() {
        // call this method to get a stream of values emitted by the device
        return this.ble.streamValues$().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])((value) => value.getUint8(0)));
    }
    disconnectDevice() {
        this._characteristic = null;
        this.ble.disconnectDevice();
    }
    /**
     * Get Battery Level GATT Characteristic value.
     * This logic is specific to this service, this is why we can't abstract it elsewhere.
     * The developer is free to provide any service, and characteristics they want.
     *
     * @return Emites the value of the requested service read from the device
     */
    updatevalue() {
        console.log('Getting Battery level...');
        return this.ble
            // 1) call the discover method will trigger the discovery process (by the browser)
            .discover$({
            filters: [{
                    services: ['0000ffe0-0000-1000-8000-00805f9b34fb'],
                }],
        }).toPromise()
            .then(res => {
            let gatt = res;
            return gatt;
        })
            .then(gatt => {
            return this.ble.getPrimaryService$(gatt, this.GATT_PRIMARY_SERVICE).toPromise().then(res => {
                let primaryService = res;
                return primaryService;
            })
                .then(primaryService => {
                return this.ble.getCharacteristic$(primaryService, this.GATT_CHARACTERISTIC_BATTERY_LEVEL).toPromise().then(res => {
                    let characteristic = res;
                    return characteristic;
                })
                    .then(characteristic => {
                    let encoder = new TextEncoder();
                    let value = 'A#1007';
                    return this.ble.writeValue$(characteristic, encoder.encode(value)).toPromise().then(res => {
                        return res;
                    });
                });
            });
            /*
            .pipe(
              // 2) get that service
              mergeMap((gatt: BluetoothRemoteGATTServer) => {
                return this.ble.getPrimaryService$(gatt,this.GATT_PRIMARY_SERVICE);
              }),
              // 3) get a specific characteristic on that service
              mergeMap((primaryService: BluetoothRemoteGATTService) => {
                return this.ble.getCharacteristic$(primaryService, this.GATT_CHARACTERISTIC_BATTERY_LEVEL);
              }),
    
              // 4) ask for the value of that characteristic (will return a DataView)
              mergeMap((characteristic: BluetoothRemoteGATTCharacteristic) => {
                return this.ble.readValue$(characteristic);
              }),
              // 5) on that DataView, get the right value
              map((value: DataView) => value.getUint8(0))
            )
            */
        });
    }
    discoverbledevice() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.ble
                // 1) call the discover method will trigger the discovery process (by the browser)
                .discover$({
                filters: [{
                        services: ['0000ffe0-0000-1000-8000-00805f9b34fb'],
                    }],
            }).toPromise()
                .then(res => {
                let gatt = res;
                return gatt;
            })
                .then(gatt => {
                return this.ble.getPrimaryService$(gatt, this.GATT_PRIMARY_SERVICE).toPromise().then(res => {
                    let primaryService = res;
                    return primaryService;
                })
                    .then(primaryService => {
                    return this.ble.getCharacteristic$(primaryService, this.GATT_CHARACTERISTIC_BATTERY_LEVEL).toPromise().then(res => {
                        let characteristic = res;
                        this._characteristic = characteristic;
                        return characteristic;
                    });
                });
            });
        });
    }
    writeValue(strvalue) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let encoder = new TextEncoder();
            let value = strvalue;
            return this.ble.writeValue$(this._characteristic, encoder.encode(value)).toPromise().then(res => {
                console.log(res);
                return res;
            });
        });
    }
    ispaired() {
        if (this._characteristic) {
            return true;
        }
        return false;
    }
};
WebBluetoothService.ctorParameters = () => [
    { type: _manekinekko_angular_web_bluetooth__WEBPACK_IMPORTED_MODULE_2__["BluetoothCore"] }
];
WebBluetoothService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], WebBluetoothService);



/***/ }),

/***/ "Fwp0":
/*!*******************************************************!*\
  !*** ./src/app/menu-card/menu-card-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: MenuCardPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuCardPageRoutingModule", function() { return MenuCardPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _menu_card_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./menu-card.page */ "Jjpl");




const routes = [
    {
        path: '',
        component: _menu_card_page__WEBPACK_IMPORTED_MODULE_3__["MenuCardPage"]
    }
];
let MenuCardPageRoutingModule = class MenuCardPageRoutingModule {
};
MenuCardPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MenuCardPageRoutingModule);



/***/ }),

/***/ "IecN":
/*!***********************************************!*\
  !*** ./src/app/menu-card/menu-card.module.ts ***!
  \***********************************************/
/*! exports provided: MenuCardPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuCardPageModule", function() { return MenuCardPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _menu_card_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./menu-card-routing.module */ "Fwp0");
/* harmony import */ var _menu_card_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./menu-card.page */ "Jjpl");
/* harmony import */ var _manekinekko_angular_web_bluetooth__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @manekinekko/angular-web-bluetooth */ "WcP9");








let MenuCardPageModule = class MenuCardPageModule {
};
MenuCardPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _menu_card_routing_module__WEBPACK_IMPORTED_MODULE_5__["MenuCardPageRoutingModule"],
            _manekinekko_angular_web_bluetooth__WEBPACK_IMPORTED_MODULE_7__["WebBluetoothModule"].forRoot({
                enableTracing: true // or false, this will enable logs in the browser's console
            })
        ],
        providers: [
            _manekinekko_angular_web_bluetooth__WEBPACK_IMPORTED_MODULE_7__["BrowserWebBluetooth"]
        ],
        declarations: [_menu_card_page__WEBPACK_IMPORTED_MODULE_6__["MenuCardPage"]],
    })
], MenuCardPageModule);



/***/ }),

/***/ "Jjpl":
/*!*********************************************!*\
  !*** ./src/app/menu-card/menu-card.page.ts ***!
  \*********************************************/
/*! exports provided: MenuCardPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuCardPage", function() { return MenuCardPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_menu_card_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./menu-card.page.html */ "d4d/");
/* harmony import */ var _menu_card_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./menu-card.page.scss */ "Vhnj");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../environments/environment */ "AytR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _services_web_bluetooth_web_bluetooth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/web-bluetooth/web-bluetooth.service */ "5wiT");
/* harmony import */ var _services_cart_payment_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/cart/payment.service */ "cN/K");







let MenuCardPage = class MenuCardPage {
    constructor(ble, paymentService, changeRef) {
        this.ble = ble;
        this.paymentService = paymentService;
        this.changeRef = changeRef;
        this.products = [];
        this.objectKeys = Object.keys;
        this.totalPrice = 0;
        this.quantity = 0;
        this.payableAmount = 0;
        this.paymentResponse = {};
    }
    ngOnInit() {
        // this.cartService.getCartItems()
        // .subscribe(cartItems => {
        //   this.products = cartItems;
        //   this.calculatePrice();
        // });
        this.WindowRef = this.paymentService.WindowRef;
    }
    getValue(object) {
        const key = this.objectKeys(object);
        return object[key.toString()];
    }
    increaseProductQuantity(product) {
        product.quantity++;
        this.quantity += 1;
        this.totalPrice += product.price;
    }
    decreaseProductQuantity(product) {
        product.quantity--;
        this.quantity -= 1;
        this.totalPrice -= product.price;
    }
    calculatePrice() {
        this.totalPrice = 0;
        this.quantity = 0;
        for (let i = 0; i < this.products.length; i++) {
            this.totalPrice += this.products[i].quantity * this.products[i].price;
            this.quantity += this.products[i].quantity;
        }
    }
    proceedToPay($event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!this.ble.ispaired())
                yield this.ble.discoverbledevice();
            this.processingPayment = true;
            this.payableAmount = this.totalPrice * 100;
            this.initiatePaymentModal($event);
        });
    }
    initiatePaymentModal(event) {
        let receiptNumber = `Receipt#${Math.floor(Math.random() * 5123 * 43) + 10}`;
        let orderDetails = {
            //amount: this.payableAmount,
            amount: 100,
            receipt: receiptNumber
        };
        this.paymentService.createOrder(orderDetails)
            .subscribe(order => {
            console.log("TCL: CheckoutComponent -> initiatePaymentModal -> order", order);
            var rzp1 = new this.WindowRef.Razorpay(this.preparePaymentDetails(order));
            this.processingPayment = false;
            rzp1.open();
            event.preventDefault();
        }, error => {
            console.log("TCL: CheckoutComponent -> initiatePaymentModal -> error", error);
        });
    }
    preparePaymentDetails(order) {
        console.log(order);
        var ref = this;
        return {
            "key": _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].RAZORPAY_KEY_ID,
            "amount": 100,
            "name": 'Pay',
            "currency": order.currency,
            "order_id": order.id,
            "image": 'https://angular.io/assets/images/logos/angular/angular.png',
            "handler": function (response) {
                ref.handlePayment(response);
            },
            "prefill": {
                "name": `Angular Geeks`
            },
            "theme": {
                "color": "#2874f0"
            }
        };
    }
    handlePayment(response) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.paymentService.capturePayment({
                amount: this.payableAmount,
                payment_id: response.razorpay_payment_id
            })
                .subscribe((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                this.paymentResponse = res;
                yield this.ble.writeValue("A#1001");
                this.ble.disconnectDevice();
                this.changeRef.detectChanges();
            }), error => {
                this.paymentResponse = error;
            });
        });
    }
    getDevice() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.ble.writeValue("A#1001");
        });
    }
};
MenuCardPage.ctorParameters = () => [
    { type: _services_web_bluetooth_web_bluetooth_service__WEBPACK_IMPORTED_MODULE_5__["WebBluetoothService"] },
    { type: _services_cart_payment_service__WEBPACK_IMPORTED_MODULE_6__["PaymentService"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ChangeDetectorRef"] }
];
MenuCardPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-menu-card',
        template: _raw_loader_menu_card_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_menu_card_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MenuCardPage);



/***/ }),

/***/ "Vhnj":
/*!***********************************************!*\
  !*** ./src/app/menu-card/menu-card.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".menu-background-color {\n  --background: #003049;\n  --color:#fff;\n}\n\nion-input .text-input {\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXG1lbnUtY2FyZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQkFBQTtFQUNBLFlBQUE7QUFDRjs7QUFJRTtFQUFhLGtCQUFBO0FBQWYiLCJmaWxlIjoibWVudS1jYXJkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tZW51LWJhY2tncm91bmQtY29sb3J7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjMDAzMDQ5O1xyXG4gIC0tY29sb3I6I2ZmZjtcclxufVxyXG5cclxuXHJcbmlvbi1pbnB1dHtcclxuICAudGV4dC1pbnB1dHsgdGV4dC1hbGlnbjogY2VudGVyOyB9XHJcbn1cclxuXHJcbiJdfQ== */");

/***/ }),

/***/ "cN/K":
/*!**************************************************!*\
  !*** ./src/app/services/cart/payment.service.ts ***!
  \**************************************************/
/*! exports provided: PaymentService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentService", function() { return PaymentService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "AytR");




let PaymentService = class PaymentService {
    constructor(http) {
        this.http = http;
    }
    get WindowRef() {
        return window;
    }
    createOrder(orderDetails) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].cloudFunctions.createOrder, orderDetails);
    }
    capturePayment(paymemntDetails) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].cloudFunctions.capturePayment, paymemntDetails);
    }
};
PaymentService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
];
PaymentService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], PaymentService);



/***/ }),

/***/ "d4d/":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/menu-card/menu-card.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"menu-background-color\">\n    <ion-title>Manu Card</ion-title>\n  </ion-toolbar>\n<ion-card style=\"max-height: 300px;align-items: center;\">\n<img src=\"../../assets/icon/resize-16355102131825455945topimg2.png\" style=\"width: 100%;\"/>\n</ion-card>\n</ion-header>\n<ion-content>\n<ion-grid>\n  <ion-row>\n    <ion-col size=\"2\" size-md=\"1\" class=\"ion-text-center\">\n      <img src=\"../../assets/icon/coffee 64x64.png\" style=\"width: 100%;\"/>\n    </ion-col>\n    <ion-col size=\"10\" size-md=\"3\">\n     <h6 style=\"font-weight: 700 !important;\">$25.00</h6>\n     <div><span style=\"font-size:12px;\">Excel Matic Top Load Detergent Powder (Carton)</span></div>\n     <div>\n\n      <ion-item class=\"ion-no-lines\">\n        <ion-label style=\"font-size: 12px;font-weight: 700;\">Quantity</ion-label>\n        <ion-button>-</ion-button>\n        <ion-input type=\"number\" text-center value='1' style=\"width:100px;\" class=\"ion-text-center\" ></ion-input>\n        <ion-button>+</ion-button >\n        <ion-button color=\"warning\" (click)=\"proceedToPay($event)\">Buy Now</ion-button>\n     </ion-item>\n\n\n     </div>\n    </ion-col>\n    <ion-col size=\"2\" size-md=\"1\">\n      <img src=\"../../assets/icon/favicon.png\" style=\"width: 100%;\"/>\n    </ion-col>\n    <ion-col size=\"10\" size-md=\"3\">\n     <h6 style=\"font-weight: 700 !important;\">$30.00</h6>\n     <div><span style=\"font-size:12px;\">Excel Matic Top Load Detergent Powder (Carton)</span></div>\n     <div>\n      <ion-item class=\"ion-no-lines\">\n        <ion-label style=\"font-size: 12px;font-weight: 700;\">Quantity</ion-label>\n        <ion-button>-</ion-button>\n        <ion-input type=\"number\" text-center value='1' style=\"width:100px;\" class=\"ion-text-center\" ></ion-input>\n        <ion-button>+</ion-button >\n        <ion-button color=\"warning\">Buy Now</ion-button>\n     </ion-item>\n     </div>\n    </ion-col>\n    <ion-col size=\"2\" size-md=\"1\">\n      <img src=\"../../assets/icon/favicon.png\" style=\"width: 100%;\"/>\n    </ion-col>\n    <ion-col size=\"10\" size-md=\"3\">\n     <h6 style=\"font-weight: 700 !important;\">$50.00</h6>\n     <div><span style=\"font-size:12px;\">Excel Matic Top Load Detergent Powder (Carton)</span></div>\n     <div>\n      <ion-item class=\"ion-no-lines\">\n        <ion-label style=\"font-size: 12px;font-weight: 700;\">Quantity</ion-label>\n        <ion-button>-</ion-button>\n        <ion-input type=\"number\" text-center value='1' style=\"width:100px;\" class=\"ion-text-center\" ></ion-input>\n        <ion-button>+</ion-button >\n        <ion-button color=\"warning\">Buy Now</ion-button>\n     </ion-item>\n     </div>\n    </ion-col>\n\n    <ion-row>\n      <ion-col>\n        <div class=\"row payment-response\" *ngIf=\"paymentResponse.body\">\n          <div class=\"col-sm-12\">\n               <div class=\"alert alert-success\" role=\"alert\" color=\"success\">\n                  Payment successfull, With payment id {{paymentResponse.req.payment_id}} Below are the deatails\n                </div>\n              <prettyjson [obj]=\"paymentResponse.body\"></prettyjson>\n          </div>\n        </div>\n      </ion-col>\n    </ion-row>\n\n\n  </ion-row>\n</ion-grid>\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=menu-card-menu-card-module.js.map