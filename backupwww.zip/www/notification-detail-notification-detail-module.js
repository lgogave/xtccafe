(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["notification-detail-notification-detail-module"],{

/***/ "2jbC":
/*!***************************************************************************!*\
  !*** ./src/app/notification-detail/notification-detail-routing.module.ts ***!
  \***************************************************************************/
/*! exports provided: NotificationDetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationDetailPageRoutingModule", function() { return NotificationDetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _notification_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./notification-detail.page */ "7ldG");




const routes = [
    {
        path: '',
        component: _notification_detail_page__WEBPACK_IMPORTED_MODULE_3__["NotificationDetailPage"]
    }
];
let NotificationDetailPageRoutingModule = class NotificationDetailPageRoutingModule {
};
NotificationDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], NotificationDetailPageRoutingModule);



/***/ }),

/***/ "7ldG":
/*!*****************************************************************!*\
  !*** ./src/app/notification-detail/notification-detail.page.ts ***!
  \*****************************************************************/
/*! exports provided: NotificationDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationDetailPage", function() { return NotificationDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_notification_detail_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./notification-detail.page.html */ "msqq");
/* harmony import */ var _notification_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./notification-detail.page.scss */ "c+Qn");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/core */ "gcOT");






const { PushNotifications } = _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Plugins"];
let NotificationDetailPage = class NotificationDetailPage {
    constructor(route) {
        this.route = route;
        this.id = null;
    }
    ngOnInit() {
        this.route.paramMap.subscribe(params => {
            this.id = params.get('id');
        });
    }
    removeBadgeCount() {
        PushNotifications.removeAllDeliveredNotifications();
    }
};
NotificationDetailPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] }
];
NotificationDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-notification-detail',
        template: _raw_loader_notification_detail_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_notification_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], NotificationDetailPage);



/***/ }),

/***/ "Kvdg":
/*!*******************************************************************!*\
  !*** ./src/app/notification-detail/notification-detail.module.ts ***!
  \*******************************************************************/
/*! exports provided: NotificationDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationDetailPageModule", function() { return NotificationDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _notification_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./notification-detail-routing.module */ "2jbC");
/* harmony import */ var _notification_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./notification-detail.page */ "7ldG");







let NotificationDetailPageModule = class NotificationDetailPageModule {
};
NotificationDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _notification_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["NotificationDetailPageRoutingModule"]
        ],
        declarations: [_notification_detail_page__WEBPACK_IMPORTED_MODULE_6__["NotificationDetailPage"]]
    })
], NotificationDetailPageModule);



/***/ }),

/***/ "c+Qn":
/*!*******************************************************************!*\
  !*** ./src/app/notification-detail/notification-detail.page.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJub3RpZmljYXRpb24tZGV0YWlsLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "msqq":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/notification-detail/notification-detail.page.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>notification-detail</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\nMy Id from Push: {{id}}\n<ion-button (click)=\"removeBadgeCount()\" expand=\"block\"></ion-button>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=notification-detail-notification-detail-module.js.map