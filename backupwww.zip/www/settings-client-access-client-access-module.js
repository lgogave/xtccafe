(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["settings-client-access-client-access-module"],{

/***/ "2KrJ":
/*!****************************************************************!*\
  !*** ./src/app/settings/client-access/client-access.page.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjbGllbnQtYWNjZXNzLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "4HQw":
/*!**************************************************************!*\
  !*** ./src/app/settings/client-access/client-access.page.ts ***!
  \**************************************************************/
/*! exports provided: ClientAccessPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientAccessPage", function() { return ClientAccessPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_client_access_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./client-access.page.html */ "CN+Y");
/* harmony import */ var _client_access_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./client-access.page.scss */ "2KrJ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_clients_client_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/clients/client.service */ "+RYs");
/* harmony import */ var _models_client_user_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../models/client-user.model */ "6/l8");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/user.service */ "qfBg");









let ClientAccessPage = class ClientAccessPage {
    constructor(clientService, userService, loadingCtrl) {
        this.clientService = clientService;
        this.userService = userService;
        this.loadingCtrl = loadingCtrl;
        this.loadedUsers = [];
        this.isLoading = false;
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.doRefresh();
            this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
                client: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: "blur",
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                }),
                users: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](null, {
                    updateOn: "blur",
                    validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
                })
            });
        });
    }
    onClientChange(event) {
        let clientId = event.target.value;
        this.loadedUsers = [];
        this.selusers = [];
        this.form.controls['users'].reset();
        this.users.forEach(user => {
            if (this.clientUsers.filter(u => u.userId == user.userId && u.clientId == clientId).length > 0) {
                user.isActive = true;
                this.selusers.push(user.userId);
            }
            else {
                user.isActive = false;
            }
            this.loadedUsers.push(user);
        });
        this.form.controls['users'].patchValue(this.selusers, { emitEvent: false });
    }
    mapClientUsers() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!this.form.valid) {
                return;
            }
            let fusers = this.form.value.users;
            let clientId = this.form.value.client;
            console.log(fusers);
            this.loadingCtrl.create({ keyboardClose: true }).then((loadingEl) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                loadingEl.present();
                let fclientUsers = [];
                //Addtion
                fusers.forEach(user => {
                    if (this.clientUsers.filter(u => u.clientId == clientId).filter(u => u.userId === user).length <= 0) {
                        fclientUsers.push(new _models_client_user_model__WEBPACK_IMPORTED_MODULE_7__["ClientUserAccess"](clientId, true, new Date(), user));
                    }
                });
                //Deletion
                this.clientUsers.filter(u => u.clientId == clientId).forEach(client => {
                    if (fusers.filter(u => u == client.userId).length <= 0) {
                        fclientUsers.push(new _models_client_user_model__WEBPACK_IMPORTED_MODULE_7__["ClientUserAccess"](clientId, false, new Date(), client.userId));
                    }
                });
                fclientUsers.forEach((user) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    if (user.isActive) {
                        yield this.userService.addclientUser(user);
                    }
                    else {
                        yield this.userService.deleteclientUser(user);
                    }
                }));
                yield this.doRefresh();
                loadingEl.dismiss();
            }));
        });
    }
    doRefresh() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = true;
            this.clients = yield this.clientService.getClientList();
            this.users = yield this.userService.getusers();
            this.clientUsers = yield this.userService.getclientusers();
            this.isLoading = false;
        });
    }
};
ClientAccessPage.ctorParameters = () => [
    { type: src_app_clients_client_service__WEBPACK_IMPORTED_MODULE_6__["ClientService"] },
    { type: _services_user_service__WEBPACK_IMPORTED_MODULE_8__["UserService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] }
];
ClientAccessPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-client-access',
        template: _raw_loader_client_access_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_client_access_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ClientAccessPage);



/***/ }),

/***/ "6/l8":
/*!*********************************************!*\
  !*** ./src/app/models/client-user.model.ts ***!
  \*********************************************/
/*! exports provided: ClientUser, ClientUserAccess */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientUser", function() { return ClientUser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientUserAccess", function() { return ClientUserAccess; });
class ClientUser {
    constructor(id, name) {
        this.id = id;
        this.name = name;
    }
}
class ClientUserAccess {
    constructor(clientId, isActive, updatedOn, userId) {
        this.clientId = clientId;
        this.isActive = isActive;
        this.updatedOn = updatedOn;
        this.userId = userId;
    }
}


/***/ }),

/***/ "CN+Y":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/settings/client-access/client-access.page.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar  color=\"primary\">\n    <ion-buttons>\n      <ion-back-button defaultHref=\"/home\">\n      </ion-back-button>\n      <ion-title>Client User Access</ion-title>\n      <ion-button (click)=\"mapClientUsers()\" [disabled]=\"!isLoading && !form.valid\">\n        <ion-icon name=\"checkmark\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <form  [formGroup]=\"form\" *ngIf=\"!isLoading\">\n    <ion-grid>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n\n          <ion-item>\n            <ion-label>Client <span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-label></ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"client\" (ionChange)=\"onClientChange($event)\">\n              <ion-select-option *ngFor=\"let client of clients\" [value]=\"client.id\">\n                {{client.name}}\n              </ion-select-option>\n            </ion-select>\n          </ion-item>\n\n\n          <ion-item>\n            <ion-label>Users <span style=\"color: #FF6347;\">*</span></ion-label>\n            <ion-label></ion-label>\n            <ion-select placeholder=\"Select One\"  interface=\"popover\" formControlName=\"users\" multiple>\n              <ion-select-option *ngFor=\"let user of loadedUsers\" [value]=\"user.userId\">\n                {{user.name}}\n              </ion-select-option>\n            </ion-select>\n          </ion-item>\n        </ion-col>\n        </ion-row>\n        </ion-grid>\n  </form>\n</ion-content>\n");

/***/ }),

/***/ "i05m":
/*!****************************************************************!*\
  !*** ./src/app/settings/client-access/client-access.module.ts ***!
  \****************************************************************/
/*! exports provided: ClientAccessPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientAccessPageModule", function() { return ClientAccessPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _client_access_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./client-access-routing.module */ "i6WA");
/* harmony import */ var _client_access_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./client-access.page */ "4HQw");







let ClientAccessPageModule = class ClientAccessPageModule {
};
ClientAccessPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _client_access_routing_module__WEBPACK_IMPORTED_MODULE_5__["ClientAccessPageRoutingModule"]
        ],
        declarations: [_client_access_page__WEBPACK_IMPORTED_MODULE_6__["ClientAccessPage"]]
    })
], ClientAccessPageModule);



/***/ }),

/***/ "i6WA":
/*!************************************************************************!*\
  !*** ./src/app/settings/client-access/client-access-routing.module.ts ***!
  \************************************************************************/
/*! exports provided: ClientAccessPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientAccessPageRoutingModule", function() { return ClientAccessPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _client_access_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./client-access.page */ "4HQw");




const routes = [
    {
        path: '',
        component: _client_access_page__WEBPACK_IMPORTED_MODULE_3__["ClientAccessPage"]
    },
    {
        path: 'add-client-access',
        loadChildren: () => __webpack_require__.e(/*! import() | add-client-access-add-client-access-module */ "add-client-access-add-client-access-module").then(__webpack_require__.bind(null, /*! ./add-client-access/add-client-access.module */ "SYN4")).then(m => m.AddClientAccessPageModule)
    },
    {
        path: 'edit-client-access',
        loadChildren: () => __webpack_require__.e(/*! import() | edit-client-access-edit-client-access-module */ "edit-client-access-edit-client-access-module").then(__webpack_require__.bind(null, /*! ./edit-client-access/edit-client-access.module */ "FoZd")).then(m => m.EditClientAccessPageModule)
    }
];
let ClientAccessPageRoutingModule = class ClientAccessPageRoutingModule {
};
ClientAccessPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ClientAccessPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=settings-client-access-client-access-module.js.map